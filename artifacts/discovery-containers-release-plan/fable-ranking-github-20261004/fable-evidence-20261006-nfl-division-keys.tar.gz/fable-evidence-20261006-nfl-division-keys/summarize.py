# Prints one line per NFL division page from the saved public API responses in this folder.
import json
ids=[53671,53672,53673,53674,53675,53676,53677,53678,2248388,2248389,2248391,2248392,2248395,2279147,2279151,2279152]
keys={}
for i in ids:
    d=json.load(open(f'{i}.json')); o=d.get('outcomes') or []
    keys.setdefault((d.get('source'),d.get('canonical_market_key')),[]).append(i)
    print(i,d.get('source'),'|',(d.get('name') or '').strip(),'|',d.get('canonical_market_key'),'|',d.get('group_id'),'|',d.get('market_type'),'| outcomes',len(o),'| no price',sum(1 for x in o if x.get('probability') is None),'|',', '.join(f"{x.get('name')} {x.get('probability')}" for x in o))
print()
for k,v in sorted(keys.items()): print(k,len(v),'pages')
