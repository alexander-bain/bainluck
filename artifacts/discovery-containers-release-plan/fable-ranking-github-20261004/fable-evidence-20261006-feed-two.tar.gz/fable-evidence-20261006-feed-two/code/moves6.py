import json,collections
M={q['id']:q for q in json.load(open('table.json'))}
H=json.load(open('hist5.json')); meta=json.load(open('hist5_ids.json')); NOW=meta['now']
SPANS={'d1':(86400,20*3600,28*3600,3*86400),'w1':(7*86400,6.5*86400,7.5*86400,10*86400),'m1':(30*86400,28.5*86400,31.5*86400,33*86400)}
out={}; why=collections.Counter()
def near(series,target,lo,hi):
    c=[x for x in series if lo<=NOW-x[0]<=hi]
    return min(c,key=lambda x:abs((NOW-x[0])-target)) if c else None
for i,r in H.items():
    q=M[i]; ven=[v for v in ('k','p') if v.upper() in q['venues']]
    if 'err' in r or any(not r.get(v) for v in ven): why['no history']+=1; continue
    # the latest history point must agree with the listing we pulled (same quantity check)
    ok=True
    for v in ven:
        last=r[v][-1]; pv=q['pK'] if v=='k' else q['pP']
        if NOW-last[0]>6*3600 or abs(last[1]-pv)>0.03: ok=False
    if not ok: why['history does not match the pulled price']+=1; continue
    res={}
    for f,(span,lo,hi,age) in SPANS.items():
        pts=[]
        for v in ven:
            if NOW-r[v][0][0]<age: pts=None; why[f+': market younger than the span plus 3 days']+=1; break
            x=near(r[v],span,lo,hi)
            if not x: pts=None; why[f+': no observation in the window']+=1; break
            pts.append((v,x[0],x[1]))
        if not pts: continue
        then=sum(p[2] for p in pts)/len(pts)
        res[f]=dict(then=round(then,4),move=round(q['p']-then,4),obs=[dict(venue={'k':'Kalshi','p':'Polymarket'}[v],ts=t,value=round(val,4)) for v,t,val in pts])
    if res: out[i]=res
json.dump({'now':NOW,'moves':out},open('moves.json','w'))
print(len(H),'fetched;',len(out),'with at least one verified span'); print(dict(why))
for f,t in (('d1',.05),('w1',.08),('m1',.15)):
    big=[(abs(v[f]['move']),i) for i,v in out.items() if f in v and abs(v[f]['move'])>=t]
    print(f,'verified moves over bar:',len(big),'| merged claims among them:',sum(1 for _,i in big if len(M[i]['venues'])>1),'| Kalshi-only:',sum(1 for _,i in big if M[i]['venues']==['K']))
    for a,i in sorted(big,reverse=True)[:6]: print('   %+.0f  now %.0f  %s %s'%(out[i][f]['move']*100,M[i]['p']*100,M[i]['venues'],M[i]['plain'][:60]))
