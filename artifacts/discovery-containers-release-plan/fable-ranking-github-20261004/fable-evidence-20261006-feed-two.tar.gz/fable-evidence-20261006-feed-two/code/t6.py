import json,re,collections,datetime,sys
sys.path.insert(0,'..')
from props import toks
A=json.load(open('../pull5/props_all.json'))
W=json.load(open('../props_wide_labeled.json'))
key=lambda r:(r['src'],r['ev'],r['name'])
lab={key(r):r for r in W}
T=[]
for a in A:
    l=lab.get(key(a))
    if not l: continue
    r=dict(a); 
    for k in ('plain','gotcha','subject','domain','recog','appeal','weight','tone','naive'): r[k]=l[k]
    r['p_old']=l['p']; r['wid']=l['id']; r['plain']=r['plain'].strip().rstrip('.')
    T.append(r)
print('wide rows',len(W),'still listed',len(T))
def issport(p): return 'Sports' in (p['cat'] or '')
def liquid(p):
    sp=p['spread']
    if p['kind']=='date':
        return p['evvol']>=(300000 if issport(p) else 75000) and p['vol']>=10000 and (sp is None or sp<=0.08)
    mv,ev=(50000,300000) if issport(p) else (20000,75000)
    if p['vol']<mv or p['evvol']<ev: return False
    if sp is not None and sp>0.06: return False
    if sp is None and (p['v24'] or 0)<=0: return False
    return True
for r in T: r['liquid']=liquid(r)
L=[r for r in T if r['liquid']]
print('liquid',len(L),collections.Counter(r['kind'] for r in L))
# cross-venue twins
SCOPE=set('us usa global world women womens men mens nfc afc al nl east west eastern western house senate party football basketball baseball hockey republican democratic run primary'.split())
def nm(s):
    s=re.sub(r'\((d|r|i)\)','',(s or '').lower()).replace('j.d.','jd').replace('u.s.','us'); return toks(s)
def jac(a,b): return len(a&b)/max(1,len(a|b))
def days(a,b):
    try: return abs((datetime.date.fromisoformat(a)-datetime.date.fromisoformat(b)).days)
    except: return 9999
for i,p in enumerate(L): p['tt']=nm(p['title']); p['nt']=nm(p['name']); p['i']=i
ks=[p for p in L if p['src']=='K']; ps=[p for p in L if p['src']=='P']; pairs=[]
for a in ks:
    best=None
    for b in ps:
        if a['kind']!=b['kind'] and not ({a['kind'],b['kind']}<={'binary','date'}): continue
        tj=jac(a['tt'],b['tt'])
        if tj<0.6 or (a['tt']^b['tt'])&SCOPE: continue
        if a['kind']=='named' and b['kind']=='named':
            if not a['nt'] or not b['nt']: continue
            if not (a['nt']<=b['nt'] or b['nt']<=a['nt'] or jac(a['nt'],b['nt'])>=0.6): continue
            sc=tj+0.5
        else:
            d=days(a['deadline'],b['deadline'])
            lim=45 if (a['kind']=='binary' and b['kind']=='binary') else 3
            if d>lim: continue
            sc=tj+0.5-d/1000
        if best is None or sc>best[0]: best=(sc,b)
    if best: pairs.append((a,best[1],best[0]))
used=set(); ok=[]; dis=[]
for a,b,sc in sorted(pairs,key=lambda x:-x[2]):
    if a['i'] in used or b['i'] in used: continue
    used.add(a['i']); used.add(b['i']); (ok if abs(a['p']-b['p'])<=0.06 else dis).append((a,b))
print('twins agree',len(ok),'disagree',len(dis))
drop=set(); 
for a,b in ok:
    a['venues']=['K','P']; a['pK']=a['p']; a['pP']=b['p']; a['p_ev']=b['ev']; a['p_name']=b['name']; a['p']=(a['p']+b['p'])/2; a['p_old']=(a['p_old']+b['p_old'])/2; a['chg']=b.get('chg'); drop.add(b['i'])
for a,b in dis: drop.add(a['i']); drop.add(b['i'])
M=[]
for p in L:
    if p['i'] in drop: continue
    p.setdefault('venues',[p['src']]); p.setdefault('pK',p['p'] if p['src']=='K' else None); p.setdefault('pP',p['p'] if p['src']=='P' else None)
    q={k:v for k,v in p.items() if k not in('tt','nt','i')}; q['id']='t%04d'%len(M); q['fam']=q['src']+':'+q['ev']; M.append(q)
json.dump(M,open('table.json','w'))
print('table',len(M),collections.Counter(q['kind'] for q in M),collections.Counter(q['domain'] for q in M).most_common(6))
mv=sorted(M,key=lambda q:-abs(q['p']-q['p_old']))[:8]
for q in mv: print('  overnight %+.0f -> %d  %s'%((q['p']-q['p_old'])*100,q['p']*100,q['plain'][:70]))
for a,b in dis[:3]: print('  DIS %d/%d %s'%(a['p']*100,b['p']*100,a['plain'][:60]))
