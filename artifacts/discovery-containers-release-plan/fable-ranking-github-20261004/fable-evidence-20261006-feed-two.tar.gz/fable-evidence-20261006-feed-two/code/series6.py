import json,urllib.request,time,os,re
NOW=json.load(open('hist5_ids.json'))['now']
def get(u,tries=6):
    for a in range(tries):
        try: return json.loads(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0','Accept':'application/json'}),timeout=30).read())
        except Exception as ex: err=str(ex); time.sleep(2*(a+1))
    raise RuntimeError(err)
f=lambda x:(float(x) if x not in (None,'') else None)
ev=[]
for l in open('../pull5/k.jsonl'):
    e=json.loads(l)
    if e['t'].startswith('KXMLBSERIES-26') or e['t'].startswith('KXMLBSERIESSCORE-26'): ev.append(e)
out=[]
for e in ev:
    d=get('https://api.elections.kalshi.com/trade-api/v2/markets?event_ticker='+e['t'])
    for m in d['markets']:
        b,a,lp=f(m.get('yes_bid_dollars')),f(m.get('yes_ask_dollars')),f(m.get('last_price_dollars'))
        mid=(a+b)/2 if (a is not None and b is not None and a-b<=0.10) else None
        c=get(f"https://api.elections.kalshi.com/trade-api/v2/series/{e['s']}/markets/{m['ticker']}/candlesticks?start_ts={NOW-4*86400}&end_ts={NOW+3600}&period_interval=60").get('candlesticks') or []
        hist=[]
        for x in c:
            hb,ha=f((x.get('yes_bid') or {}).get('close_dollars')),f((x.get('yes_ask') or {}).get('close_dollars'))
            if hb is not None and ha is not None and ha-hb<=0.10 and not (hb==0 and ha>=0.99): hist.append([x['end_period_ts'],(ha+hb)/2])
        out.append(dict(event=e['t'],series=e['s'],title=e['title'],sub=e.get('sub'),ticker=m['ticker'],name=m.get('yes_sub_title'),bid=b,ask=a,last=lp,mid=mid,status=m.get('status'),volume=f(m.get('volume_fp')),rules=(m.get('rules_primary') or '')[:500],close=(m.get('close_time') or '')[:10],fetched=int(time.time()),hist=hist))
        time.sleep(0.15)
json.dump(out,open('series5.json','w'))
for o in out:
    w=[x for x in o['hist'] if 20*3600<=NOW-x[0]<=28*3600]; th=min(w,key=lambda x:abs(NOW-x[0]-86400))[1] if w else None
    print(o['event'][-12:],'|',o['name'],'| mid',o['mid'],'last',o['last'],'| 24h ago',th,'| pts',len(o['hist']),'| vol',int(o['volume'] or 0))
print(out[0]['rules']); print([o['rules'] for o in out if 'SCORE' in o['event']][0])
