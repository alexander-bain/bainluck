import json,re,collections,datetime
MON={m:i+1 for i,m in enumerate(['jan','feb','mar','apr','may','jun','jul','aug','sep','oct','nov','dec'])}
TODAY=datetime.date(2026,10,5)
THR=re.compile(r'^\s*(above|below|at least|at most|more than|less than|fewer than|exactly|over|under|between|↑|↓|<|>|≥|≤|\+|-)\b|^\s*[\$€£]?\d[\d,\.]*\s*(%|k|m|b|bn|t|°|bps|m\+|k\+|\+|to|-|–|or)|\d\s*(-|–|to)\s*[\$€£]?\d|^\s*[\$€£]\d|^\d+(\.\d+)?%?$|\b(bps|or more|or fewer|or less|or above|or below|or higher|or lower)\b',re.I)
def parse_deadline(name, close):
    """Return ISO date if `name` is a deadline phrase, else None."""
    s=(name or '').strip().lower().replace(',',' ')
    s=re.sub(r'\s+',' ',s)
    m=re.match(r'^(before|by|until|prior to)?\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec)\.? (\d{1,2}) ?(\d{4})?$',s)
    if m:
        mo=MON[m.group(2)[:3]]; d=int(m.group(3)); y=int(m.group(4)) if m.group(4) else None
        if y is None:
            y=TODAY.year
            try:
                if datetime.date(y,mo,d)<TODAY: y+=1
            except: pass
        try: return datetime.date(y,mo,d).isoformat()
        except: return None
    m=re.match(r'^(before|by|in|during|until)?\s*(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\.? (\d{4})$',s)
    if m:
        mo=MON[m.group(2)[:3]]; y=int(m.group(3))
        if m.group(1) in ('before',None,'until','prior to'): return datetime.date(y,mo,1).isoformat()
        ny,nm=(y+1,1) if mo==12 else (y,mo+1); return datetime.date(ny,nm,1).isoformat()
    m=re.match(r'^(before|by|in|during)?\s*(\d{4})$',s)
    if m:
        y=int(m.group(2))
        return datetime.date(y,1,1).isoformat() if m.group(1)=='before' else datetime.date(y+1,1,1).isoformat()
    if re.search(r"before (his|trump'?s?) term ends|during trump'?s? term",s): return '2029-01-20'
    return None
def toks(s):
    s=re.sub(r"[^a-z0-9 ]"," ",(s or '').lower())
    stop=set('the a an will who what which be to of in on by for and or is are at this that with as before after than from winner win wins won year'.split())
    return set(w for w in s.split() if len(w)>1 and w not in stop)
def kprice(lp,b,a):
    if b is not None and a is not None and a>0 and a-b<=0.10 and not (b==0 and a>=0.99): return (a+b)/2
    return lp
KSKIP_CAT={'Financials','Crypto','Commodities','Mentions'}
GAME=re.compile(r' vs\.? | at |: (Total|Spread)|\bPoints\b|\bYards\b|Rebounds|Assists|Strikeouts|\bHits\b|Touchdown|\bGoals\b|Combo|parlay|First (Half|Quarter|Inning)|Moneyline|\bMap \d|\bSet \d|Game \d',re.I)
DAILY=re.compile(r'(highest|lowest) temperature|where will it rain|rain in .* on |snow in .* on |gas prices? (this week|on )|price on .* at \d|this week\b|on (jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]* \d{1,2} 2026\?|# tweets|\btweets\b|daily|hourly|\b(5|15)M\b',re.I)
PSKIP_TAG={'Games','Up or Down','Crypto Prices','Daily Temperature','Crypto','Hide From New','Esports','Mentions','Recurring','Weather'}
def build():
    global props,stats
    props=[];stats=collections.Counter()
    def add(src,ev,evtitle,cat,name,q,p,vol,v24,spread,close,evvol,single,rules,chg=None):
        kind='binary' if single else 'named'
        text=evtitle if single else f'{evtitle} — {name}'
        dl=None
        if not single:
            dl=parse_deadline(name,close)
            if dl: kind='date'
            elif THR.search(name or ''): kind='threshold'
        else:
            if THR.search((q or '').split('?')[0][-25:]) : pass
        if dl is None: dl=close or None
        props.append(dict(src=src,ev=str(ev),title=evtitle,cat=cat,name=name,text=text,kind=kind,p=p,vol=vol,v24=v24,spread=spread,deadline=dl,evvol=evvol,rules=rules,chg=chg))
    for l in open('k.jsonl'):
        e=json.loads(l); stats['k_events']+=1
        if e['cat'] in KSKIP_CAT: stats['k_skip_cat']+=1; continue
        t=e['title'] or ''
        if e['cat']=='Sports' and GAME.search(t): stats['k_skip_game']+=1; continue
        if DAILY.search(t): stats['k_skip_daily']+=1; continue
        ms=[]
        for m in e['m']:
            p=kprice(m[3],m[4],m[5])
            if p is None: continue
            sp=(m[5]-m[4]) if (m[4] is not None and m[5] is not None) else None
            ms.append((m,p,sp))
        evvol=sum((m[0][6] or 0) for m in ms)
        for m,p,sp in ms:
            add('K',e['t'],t,e['cat'],m[1] or m[2],m[2],p,m[6] or 0,m[7] or 0,sp,m[9],evvol,len(e['m'])==1,m[11],None)
    for l in open('p.jsonl'):
        e=json.loads(l); stats['p_events']+=1
        if any(t in PSKIP_TAG for t in e['tags']): stats['p_skip_tag']+=1; continue
        t=e['title'] or ''
        if ('Sports' in e['tags'] and GAME.search(t)) or DAILY.search(t): stats['p_skip_game_daily']+=1; continue
        live=[m for m in e['m'] if (m[5] or 0)>0 and m[3] and m[3][0] is not None]
        for m in live:
            p=m[3][0]; sp=None
            if m[9] is not None and m[10] is not None:
                sp=m[10]-m[9]
                if 0<sp<=0.10: p=(m[9]+m[10])/2
            add('P',e['id'],t,'|'.join(e['tags'][:4]),m[1] or m[2],m[2],p,m[5] or 0,m[6] or 0,sp,m[8],e['vol'] or 0,len(live)==1 and len(e['m'])==1,m[14],{'d1':m[11],'w1':m[12],'m1':m[13]})
    if __name__=="__main__": pass
    stats["all_props"]=len(props)
    json.dump(props,open('props_all.json','w'))
    print(dict(stats)); print(collections.Counter(p['kind'] for p in props))
    
if __name__=='__main__':
    build()
