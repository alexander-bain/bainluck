import json,urllib.request,time,collections,re,sys,os,concurrent.futures as cf
sys.path.insert(0,'..'); from props import kprice
M=json.load(open('table.json'))
OKT=lambda q:q['tone'] in('light','neutral')
E_=[q for q in M if q['recog']>=2 and OKT(q)]
# identifiers
kt={}
for l in open('../pull5/k.jsonl'):
    e=json.loads(l)
    for m in e['m']: kt[(e['t'],m[1])]=(e['s'],m[0],m[3],m[10])
pk={}
for l in open('../pull5/p.jsonl'):
    e=json.loads(l)
    for m in e['m']: pk[(str(e['id']),m[1])]=m[0]
want={}
for q in E_:
    k=p=None
    if 'K' in q['venues']: k=kt.get((q['ev'],q['name'])) if q['src']=='K' else None
    if 'P' in q['venues']: p=pk.get((q['ev'],q['name'])) if q['src']=='P' else pk.get((q.get('p_ev'),q.get('p_name')))
    if ('K' in q['venues'] and not k) or ('P' in q['venues'] and not p): continue
    c=q.get('chg') or {}
    big=any(c.get(f) is not None and abs(c[f])>=t for f,t in (('d1',.035),('w1',.06),('m1',.12)))
    if 'P' in q['venues'] and not big: continue          # Polymarket's own change fields are the prefilter where it lists the claim
    want[q['id']]=dict(k=k,p=p)
print('eligible',len(E_),'to fetch',len(want),'K-only',sum(1 for v in want.values() if not v['p']),'P-only',sum(1 for v in want.values() if not v['k']),'both',sum(1 for v in want.values() if v['k'] and v['p']))
def get(u,tries=5):
    for a in range(tries):
        try: return json.loads(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0','Accept':'application/json'}),timeout=30).read())
        except Exception as ex:
            err=str(ex); time.sleep(1.5*(a+1) if '429' in err else 0.5)
    raise RuntimeError(err)
NOW=int(os.path.getmtime('../pull5/p_state.json'))
def kser(series,ticker):
    out=[]
    for per,span in ((60,4*86400),(1440,40*86400)):
        d=get(f'https://api.elections.kalshi.com/trade-api/v2/series/{series}/markets/{ticker}/candlesticks?start_ts={NOW-span}&end_ts={NOW+3600}&period_interval={per}')
        for c in d.get('candlesticks') or []:
            f=lambda x:(float(x) if x not in (None,'') else None)
            v=kprice(f((c.get('price') or {}).get('close_dollars')),f((c.get('yes_bid') or {}).get('close_dollars')),f((c.get('yes_ask') or {}).get('close_dollars')))
            if v is not None: out.append([c['end_period_ts'],v,per])
        time.sleep(0.12)
    return sorted(out)
def pser(mid):
    g=get(f'https://gamma-api.polymarket.com/markets/{mid}'); tok=json.loads(g['clobTokenIds'])[0]; out=[]
    for iv,fd,per in (('1w',60,60),('max',720,720)):
        h=get(f'https://clob.polymarket.com/prices-history?market={tok}&interval={iv}&fidelity={fd}')['history']
        out+= [[x['t'],x['p'],per] for x in h]
    return sorted(out)
try: H=json.load(open('hist5.json'))
except Exception: H={}
def one(it):
    i,v=it; r={}
    try:
        if v['k']: r['k']=kser(v['k'][0],v['k'][1])
        if v['p']: r['p']=pser(v['p'])
    except Exception as ex: r['err']=str(ex)[:120]
    return i,r
todo=[(i,v) for i,v in want.items() if i not in H or 'err' in H[i]]
with cf.ThreadPoolExecutor(4) as ex:
    for n,(i,r) in enumerate(ex.map(one,todo)):
        H[i]=r
        if n%100==99: json.dump(H,open('hist5.json','w')); print(n+1,flush=True)
json.dump(H,open('hist5.json','w')); json.dump({'now':NOW,'ids':want},open('hist5_ids.json','w'))
print('done',len(H),'errors',sum('err' in r for r in H.values()))
