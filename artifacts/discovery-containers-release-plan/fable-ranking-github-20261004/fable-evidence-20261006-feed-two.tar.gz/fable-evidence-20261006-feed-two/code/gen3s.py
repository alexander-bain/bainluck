import json,re,collections,datetime,itertools,statistics as st
M=json.load(open('table.json'))
def d(s):
    try: return datetime.date.fromisoformat(s)
    except: return None
def pct(p):
    x=round(p*1000); return (x+5)//10
EXC={}
for l in open('../pull5/k.jsonl'):
    e=json.loads(l); EXC['K:'+str(e['t'])]=bool(e.get('mx'))
for l in open('../pull5/p.jsonl'):
    e=json.loads(l); EXC['P:'+str(e['id'])]=bool(e.get('neg'))
def nsubj(s):
    s=(s or '').lower().strip(); s=re.sub(r"^(the|president|us|u\.s\.) ",'',s)
    return {'trump':'donald trump','fed':'federal reserve','the fed':'federal reserve','gta 6':'gta vi','grand theft auto vi':'gta vi'}.get(s,s)
for q in M:
    q['pp']=pct(q['p']); q['dl']=d(q['deadline']) if q['deadline'] else None
    q['rn']=q['recog']/3; q['an']=q['appeal']/3; q['wn']=q['weight']/3
    q['Q']=q['rn']*(0.5*q['an']+0.3*q['wn']+0.2); q['subj']=nsubj(q['subject'])
OK=lambda q: q['tone'] in('light','neutral')
def foreign_election(q): return q['domain']=='world_politics' and re.search(r'election|ballot|referendum',q['plain']+' '+q['text'],re.I) is not None
E=[q for q in M if q['recog']>=2 and OK(q) and not foreign_election(q)]
key=lambda q:(q['src'],q['ev'],q['name'])
T5={q['id']:q for q in json.load(open('../v5/table.json'))}
for q in json.load(open('../v5/extra_claims.json')): T5[q['id']]=q
SEEN5={key(T5[i]) for c in json.load(open('../v5/final5.json')) for i in c['ids']}
E=[q for q in E if key(q) not in SEEN5]
print('excluded as shown in feed trial one:',len(SEEN5))
BUCK=(('By the end of October','2026-10-28','2026-11-01'),('By the end of November','2026-11-28','2026-12-01'),('By the end of 2026','2026-12-25','2027-01-05'),('By spring 2027','2027-03-28','2027-04-02'),('By mid-2027','2027-06-25','2027-07-05'),('By the end of 2027','2027-12-25','2028-01-05'),("Before Trump's term ends",'2029-01-15','2029-01-25'),('By 2030','2029-12-25','2030-01-05'))
def bucket(q):
    x=q['dl']
    if not x: return None
    for name,lo,hi in BUCK:
        if d(lo)<=x<=d(hi): return name
C=[]
def add(t,members,score,**kw): C.append(dict(type=t,ids=[m['id'] for m in members],score=round(score,4),**kw))
# ---------- boards
byb=collections.defaultdict(list)
for q in E:
    if q['kind'] in('date','binary') and 2<=q['pp']<=98 and bucket(q): byb[bucket(q)].append(q)
def pick(pool,maxdom,n=5,gap=4,ban=()):
    out=[]
    for q in pool:
        if q['id'] in ban or any(q['subj']==o['subj'] or q['fam']==o['fam'] for o in out): continue
        if sum(1 for o in out if o['domain']==q['domain'])>=maxdom: continue
        if any(abs(q['pp']-o['pp'])<gap for o in out): continue
        out.append(q)
        if len(out)==n: break
    return sorted(out,key=lambda q:-q['p'])
for b,pool in byb.items():
    pool=sorted(pool,key=lambda q:-q['Q']); ban=set()
    for k in range(6):
        mem=pick(pool,2,ban=ban)
        if len(mem)<5: break
        add('board',mem,st.mean(q['Q'] for q in mem)-0.05*k,title=b); ban|={q['id'] for q in mem[:5]}
# ---------- same-odds groups
BANDS=((0.05,'About 1 in 20'),(0.10,'About 1 in 10'),(0.20,'About 1 in 5'),(0.25,'About 1 in 4'),(0.33,'About 1 in 3'),(0.50,'A coin flip'),(0.67,'About 2 in 3'),(0.75,'About 3 in 4'),(0.90,'About 9 in 10'))
def anchored(q): return q['kind']!='date' or bucket(q) is not None
for c,name in BANDS:
    pool=sorted([q for q in E if abs(q['p']-c)<=0.016 and anchored(q) and q['appeal']>=2],key=lambda q:-q['Q']); out=[]
    for q in pool:
        if any(q['subj']==o['subj'] or q['fam']==o['fam'] for o in out) or sum(1 for o in out if o['domain']==q['domain'])>=2: continue
        out.append(q)
        if len(out)==4: break
    if len(out)==4 and any(o['tone']=='light' for o in out) and any(o['weight']>=2 for o in out):
        add('band',sorted(out,key=lambda q:-q['p']),st.mean(q['Q'] for q in out),title=name)
# ---------- dead heats
fam=collections.defaultdict(list)
for q in M:
    if q['kind']=='named': fam[q['fam']].append(q)
def common_suffix(a,b):
    A,B=a.split(),b.split(); k=0
    while k<min(len(A),len(B)) and A[-1-k]==B[-1-k]: k+=1
    return ' '.join(A[len(A)-k:]),' '.join(A[:len(A)-k]),' '.join(B[:len(B)-k])
for f,ms in fam.items():
    if not EXC.get(f): continue
    ms=sorted(ms,key=lambda q:-q['p'])
    if len(ms)<2: continue
    a,b=ms[0],ms[1]
    if a['p']-b['p']>0.035 or b['p']<0.2 or not(OK(a) and OK(b)) or min(a['recog'],b['recog'])<2 or foreign_election(a): continue
    suf,na,nb=common_suffix(a['plain'],b['plain'])
    if len(suf.split())<3 or not na or not nb or len(na.split())>4 or len(nb.split())>4 or any(c['type']=='deadheat' and c['title']=='____ '+suf for c in C): continue
    add('deadheat',[a,b],(a['Q']+b['Q'])/2*(1.1 if a['appeal']>=2 else 1),title='____ '+suf,names=[na,nb],rest=pct(max(0,1-a['p']-b['p'])))
# ---------- peer tables and head-to-heads (events whose venue titles differ only in one short span)
def ttoks(t): return re.sub(r"[^A-Za-z0-9&'.\- ]"," ",t).split()
evs={}
for q in M:
    if q['kind']!='named' and OK(q): evs.setdefault(q['fam'],[]).append(q)
keys=collections.defaultdict(dict)
for f,ms in evs.items():
    tk=ttoks(ms[0]['title'])
    for i in range(len(tk)):
        for L in (1,2,3):
            if i+L>len(tk) or len(tk)-L<2: continue
            keys[(tuple(x.lower() for x in tk[:i]),tuple(x.lower() for x in tk[i+L:]))].setdefault(' '.join(tk[i:i+L]),f)
groups={}
for k,spans in keys.items():
    if len(spans)<2: continue
    fs=frozenset(spans.values())
    if len(fs)<2: continue
    if fs not in groups or len(k[0])+len(k[1])>groups[fs][0]: groups[fs]=(len(k[0])+len(k[1]),spans)
def blank(q,name):
    pl=re.sub(r"^[A-Z][\w-]+ maker ","",q['plain']); pl=re.sub(r", the [^,]+ maker,","",pl)
    for cand in (q['subject'].strip(),name):
        i=pl.lower().find(cand.lower())
        if cand and i>=0: return (pl[:i]+'____'+pl[i+len(cand):]).strip()
    return None
pair=collections.defaultdict(list)
for fs,(n,spans) in groups.items():
    bydl=collections.defaultdict(dict)
    for name,f in spans.items():
        for q in evs[f]: bydl[q['deadline'] if q['kind']=='date' else 'x'][name]=q
    best=None
    for dl,mm in bydl.items():
        ms=sorted(mm.items(),key=lambda kv:-kv[1]['p'])
        if len(ms)>=2:
            for (na,a),(nb,b2) in itertools.combinations(ms,2): pair[tuple(sorted((na,nb)))].append((a if na<nb else b2,b2 if na<nb else a,dl))
        if len(ms)<3 or max(q['recog'] for _,q in ms)<2 or ms[0][1]['p']-ms[-1][1]['p']<0.05 or ms[0][1]['p']<0.08: continue
        mid=sum(1 for _,q in ms if 0.05<=q['p']<=0.95)
        sc=st.mean(sorted([q['Q'] for _,q in ms],reverse=True)[:3])*(0.6+0.1*min(len(ms),5))*(0.5+0.1*min(mid,5))
        bl=collections.Counter(blank(q,n) for n,q in ms if blank(q,n)); 
        if not bl: continue
        t,cnt=bl.most_common(1)[0]; ms=[(n,q) for n,q in ms if blank(q,n)==t]
        if len(ms)<3 or ms[0][1]['p']-ms[-1][1]['p']<0.05: continue
        if best is None or sc>best[0]: best=(sc,ms[:5],t)
    if best: add('peer',[q for _,q in best[1]],best[0],title=best[2],names=[n for n,_ in best[1]])
for (na,nb),lst in pair.items():
    seen=set(); rows=[]
    for a,b2,dl in sorted(lst,key=lambda x:-(x[0]['Q']+x[1]['Q'])*(1-abs(x[0]['p']+x[1]['p']-1)*0.3)):
        if a['fam'] in seen: continue
        seen.add(a['fam']); t=blank(a,na)
        if t: rows.append((t,a,b2))
    if len(rows)>=2 and min(rows[0][1]['recog'],rows[0][2]['recog'])>=2:
        rows=rows[:4]; mem=[x for r in rows for x in r[1:]]
        add('h2h',mem,st.mean(q['Q'] for q in mem)*(1+0.1*len(rows)),title=na+' vs '+nb,labels=[r[0].replace('____','').strip() for r in rows],names=[na,nb])
# ---------- funnels
STAGE=((1,r'\b(make|makes|reach|reaches|qualif\w+ for) the (\w+ )*playoffs?\b'),(2,r'\bwins? the (\w+ )*(division|AL East|AL West|AL Central|NL East|NL West|NL Central|(AFC|NFC) (North|South|East|West))\b'),(3,r'\bwins? the (\w+ )*(AFC|NFC|American League|National League|Eastern Conference|Western Conference)( Championship| pennant| title)?\b|\b(reach|reaches|plays? in|makes?) the (\w+ )*(Super Bowl|World Series|NBA Finals|Stanley Cup Final|national championship|championship game)'),(4,r'\bwins? the (\w+ )*(Super Bowl|World Series|NBA Finals|NBA championship|Stanley Cup|national championship|College Football Playoff)\b'))
def stage(q):
    best=None
    for k,rx in STAGE:
        if re.search(rx,q['plain'],re.I): best=k
    return best
bys=collections.defaultdict(dict)
for q in M:
    if q['domain']!='sports' or q['kind']!='named': continue
    s=stage(q)
    if s and (s not in bys[q['subj']] or q['vol']>bys[q['subj']][s]['vol']): bys[q['subj']][s]=q
for s,stg in bys.items():
    ks=sorted(stg)
    if len(ks)<3: continue
    mem=[stg[k] for k in ks]
    if any(mem[i+1]['p']>mem[i]['p']+0.02 for i in range(len(mem)-1)) or mem[0]['p']<0.25 or mem[-1]['p']<0.03: continue
    add('funnel',mem,max(q['rn'] for q in mem)*(0.5+mem[0]['p'])*(len(mem)/4),title=mem[0]['subject'])
# ---------- movers (Polymarket's one-week change)
mv=[q for q in E if q.get('chg') and q['chg'].get('w1') is not None and abs(q['chg']['w1'])>=0.08 and 3<=q['pp']<=97 and 0<=q['p']-q['chg']['w1']<=1 and anchored(q)]
THEMES={'':None,'Washington':('us_politics',),'Tech and business':('tech_ai','business','economy'),'The world':('world_politics','war_security'),'Culture and sport':('entertainment','celebrity','sports')}
for th,doms in THEMES.items():
    pool=sorted([q for q in mv if doms is None or q['domain'] in doms],key=lambda q:-abs(q['chg']['w1'])*q['Q']); out=[]
    for q in pool:
        if any(q['subj']==o['subj'] or q['fam']==o['fam'] for o in out): continue
        if doms is None and sum(1 for o in out if o['domain']==q['domain'])>=2: continue
        out.append(q)
        if len(out)==4: break
    if len(out)>=3: add('movers',sorted(out,key=lambda q:-abs(q['chg']['w1'])),st.mean(abs(q['chg']['w1'])*q['Q'] for q in out)*(1.1 if doms is None else 1),title='Biggest moves this week',tag=th or None,prev=[pct(q['p']-q['chg']['w1']) for q in sorted(out,key=lambda q:-abs(q['chg']['w1']))])
# ---------- coin-flip date
lad=collections.defaultdict(list)
for q in M:
    if q['kind']=='date' and q['dl'] and OK(q): lad[q['fam']].append(q)
for f,ms in lad.items():
    ms=sorted({q['deadline']:q for q in ms}.values(),key=lambda q:q['dl'])
    if len(ms)<3 or max(q['recog'] for q in ms)<2: continue
    ps=[q['p'] for q in ms]
    if any(ps[i+1]<ps[i]-0.03 for i in range(len(ps)-1)): continue
    k=next((i for i,p in enumerate(ps) if p>=0.5),None)
    if k is None or k==0 or ps[k-1]>0.45 or ps[k]>0.80: continue
    if len(ms)>5: 
        keep=sorted(set([0,k-1,k,len(ms)-1]+[min(len(ms)-1,k+1)])); ms2=[ms[i] for i in keep]; k=[m['id'] for m in ms2].index(ms[k]['id']); ms=ms2
    add('when',ms,max(q['Q'] for q in ms)*(1-abs(ms[k]['p']-0.55)),title=ms[k]['title'],flip=k)
bt=collections.defaultdict(list)
for c in C: bt[c['type']].append(c)
R={q['id']:q for q in M}
for t,l in bt.items():
    l.sort(key=lambda c:-c['score'])
    for r,c in enumerate(l): c['rank']=r+1
    print('=====',t,len(l))
    for c in l[:9]: print('  %.2f %s | %s | %s'%(c['score'],c['title'],c.get('tag') or '',' / '.join('%d %s'%(R[i]['pp'],(R[i]['plain'])[:38]) for i in c['ids'])), c.get('prev') or c.get('names') or c.get('labels') or '')
json.dump(C,open('cands3.json','w'))
