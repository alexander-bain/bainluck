import json,os,time,urllib.request,urllib.parse,sys
def f(x):
    try: return float(x)
    except: return None
def get(u):
    r=urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0','Accept':'application/json'})
    return json.load(urllib.request.urlopen(r,timeout=60))
def kalshi():
    st=json.load(open('k_state.json')) if os.path.exists('k_state.json') else {'cursor':'','done':False,'pages':0}
    out=open('k.jsonl','a'); errs=0
    while not st['done'] and errs<8:
        q={'status':'open','limit':200,'with_nested_markets':'true'}
        if st['cursor']: q['cursor']=st['cursor']
        try: d=get('https://api.elections.kalshi.com/trade-api/v2/events?'+urllib.parse.urlencode(q))
        except Exception as e: errs+=1; time.sleep(2); continue
        for e in d.get('events',[]):
            ms=[[m.get('ticker'),m.get('yes_sub_title'),m.get('title'),f(m.get('last_price_dollars')),f(m.get('yes_bid_dollars')),f(m.get('yes_ask_dollars')),f(m.get('volume_fp')),f(m.get('volume_24h_fp')),f(m.get('open_interest_fp')),(m.get('close_time') or '')[:10],f(m.get('previous_price_dollars')),(m.get('rules_primary') or '')[:400]] for m in (e.get('markets') or [])]
            out.write(json.dumps({'t':e.get('event_ticker'),'s':e.get('series_ticker'),'title':e.get('title'),'sub':e.get('sub_title'),'cat':e.get('category'),'mx':e.get('mutually_exclusive'),'m':ms})+'\n')
        st['pages']+=1; st['cursor']=d.get('cursor') or ''
        if not st['cursor'] or not d.get('events'): st['done']=True
        json.dump(st,open('k_state.json','w'))
    print('kalshi pages',st['pages'],st['done'],errs)
def poly():
    st=json.load(open('p_state.json')) if os.path.exists('p_state.json') else {'cursor':'','done':False,'n':0}
    out=open('p.jsonl','a'); errs=0
    while not st['done'] and errs<8:
        q={'closed':'false','active':'true','limit':200}
        if st['cursor']: q['after_cursor']=st['cursor']
        try: d=get('https://gamma-api.polymarket.com/events/keyset?'+urllib.parse.urlencode(q))
        except Exception as e: errs+=1; time.sleep(2); continue
        ev=d.get('events') or []
        for e in ev:
            ms=[]
            for m in e.get('markets') or []:
                if m.get('closed'): continue
                try: op=json.loads(m.get('outcomePrices') or '[]'); oc=json.loads(m.get('outcomes') or '[]')
                except: op=[];oc=[]
                ms.append([m.get('id'),m.get('groupItemTitle') or '',m.get('question'),[f(x) for x in op][:2],oc[:2],f(m.get('volume')),f(m.get('volume24hr')),f(m.get('liquidity')),(m.get('endDate') or '')[:10],f(m.get('bestBid')),f(m.get('bestAsk')),f(m.get('oneDayPriceChange')),f(m.get('oneWeekPriceChange')),f(m.get('oneMonthPriceChange')),(m.get('description') or '')[:400]])
            out.write(json.dumps({'id':e.get('id'),'slug':e.get('slug'),'title':e.get('title'),'tags':[t.get('label') for t in (e.get('tags') or [])],'vol':f(e.get('volume')),'v24':f(e.get('volume24hr')),'liq':f(e.get('liquidity')),'end':(e.get('endDate') or '')[:10],'neg':e.get('negRisk'),'m':ms})+'\n')
        st['n']+=len(ev); nc=d.get('next_cursor') or ''
        if not ev or not nc or nc==st['cursor']: st['done']=True
        st['cursor']=nc; json.dump(st,open('p_state.json','w'))
    print('poly events',st['n'],st['done'],errs)
{'k':kalshi,'p':poly}[sys.argv[1]]()
