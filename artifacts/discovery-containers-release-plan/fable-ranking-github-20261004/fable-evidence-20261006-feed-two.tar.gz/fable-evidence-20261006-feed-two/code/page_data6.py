import json,re,collections,datetime
M={q['id']:q for q in json.load(open('table.json'))}
for q in json.load(open('extra_claims.json')): M[q['id']]=q
F=json.load(open('final5.json'))
MON='January|February|March|April|May|June|July|August|September|October|November|December'
DATE=re.compile(r'\s+((?:before|by)\s+(?:the end of\s+)?(?:(?:%s)\.?\s+)?(?:\d{1,2},\s+)?\d{4})$'%MON)
def split(s):
    m=DATE.search(s); return (s[:m.start()].rstrip(' ,'),m.group(1)) if m else (s,None)
def pct(p):
    x=round(p*1000); return (x+5)//10
def frame(plains):
    A=[p.split() for p in plains]; n=min(map(len,A)); i=0
    while i<n and len({a[i] for a in A})==1: i+=1
    j=0
    while j<n-i and len({a[-1-j] for a in A})==1: j+=1
    pre=' '.join(A[0][:i]); suf=' '.join(A[0][len(A[0])-j:]) if j else ''
    return (pre+' ____ '+suf).strip(), [' '.join(a[i:len(a)-j] if j else a[i:]) for a in A]
import os
FX=collections.defaultdict(collections.Counter)
for f in sorted(os.listdir('.')):
    if re.match(r'check_out_\d+\.json',f):
        for v in json.load(open(f)):
            for x in v.get('fixes') or []: FX[x['id']][x['plain'].strip().rstrip('.')]+=1
FX={i:c.most_common(1)[0][0] for i,c in FX.items()}
HIST=json.load(open('hist5.json')); NOW=json.load(open('hist5_ids.json'))['now']
WIN={'since yesterday':28*3600,'a week':7.5*86400,'a month':31.5*86400}
def series(i,span):
    q=M[i]; r=HIST.get(i) or {}
    if len(q['venues'])!=1: return None
    pts=r.get(q['venues'][0].lower())
    if not pts: return None
    w=[[x[0],round(x[1],4)] for x in pts if NOW-x[0]<=WIN[span]]
    if len(w)<6: return None
    return w+[[NOW,round(q['p'],4)]]
VIZN=0
KICK={'movers':'Movers','roundup':'Round-up','swing':'The swing','newfav':'New favorite','checklist':'Checklist','band':'Same odds','board':'Same deadline','peer':'Same question','deadheat':'Dead heat','when':'The tipping point','h2h':'Head to head'}
VEN={'K':'Kalshi','P':'Polymarket'}
SPAN={'a week':'in a week','a month':'in a month','since yesterday':'since yesterday'}
PT=datetime.timezone(datetime.timedelta(hours=-7))
def when(ts): return datetime.datetime.fromtimestamp(ts,PT).strftime('%a %b %-d, %-I:%M%p PT').replace('AM','am').replace('PM','pm')
out=[]
for c in F:
    t=c['type']; ids=c['ids']; plains=[FX.get(i,M[i]['plain']) for i in ids]
    title=c.get('title'); names=c.get('names'); tag=c.get('tag')
    ck=c.get('check') or {}
    if ck.get('headline_fix'): title=ck['headline_fix']
    if names and ck.get('name_fixes'):
        nf={x['id']:x['name'] for x in ck['name_fixes']}; names=[nf.get(i,n) for i,n in zip(ids,names)]
    if t in('swing','newfav','checklist'): title,names=frame(plains)
    if t=='when' and ck.get('headline_fix'): pass
    d=dict(cid=c['vid'],type=t,kicker=KICK[t],n=c['n'],headline=title,tag=tag,notes=c['check'].get('reasons') or [],span=SPAN.get(c.get('span')),conn={'newfav':'has overtaken'}.get(t))
    rows=[]
    for k,i in enumerate(ids):
        q=M[i]; s=plains[k]; r=dict(text=s)
        if t=='board': r['text']=split(s)[0]
        if names and len(names)==len(ids): r['text']=re.sub(r'^The ','',names[k])
        if t=='when': r['text']=split(s)[1] or q['name']
        if c.get('prev'): r['prev']=c['prev'][k]; r['delta']=pct(q['p'])-c['prev'][k]
        if c.get('notes'): r['note']=c['notes'][k]
        o=(c.get('obs') or [None]*len(ids))[k]
        if o: r['earlier']='; '.join(f"{x['venue']} {round(x['value']*100,1)}% at {when(x['ts'])}" for x in o['obs'])
        r.update(id=i,num='<1' if q['p']<0.005 else str(pct(q['p'])),p=round(q['p'],4),deadline=q['deadline'],venues=[VEN[v] for v in q['venues']],
                 pK=None if q.get('pK') is None else round(q['pK']*100,1),pP=None if q.get('pP') is None else round(q['pP']*100,1),raw=q['text'].strip(),plain=s,gotcha=q.get('gotcha') or '')
        rows.append(r)
    if t=='when':
        stem,dt=split(M[ids[c['flip']]]['plain']); d['headline']=stem; d['flip']=c['flip']; d['callout']='Likelier than not '+(dt or '')
    if t=='deadheat': d['rest']=c['rest']
    if t in('swing','newfav'):
        ss=[series(i,c['span']) for i in ids]
        if all(ss):
            VIZN+=1
            if VIZN%2==1: d['series']=ss; d['t0']=min(x[0][0] for x in ss); d['t1']=NOW
            d['viz_eligible']=True
    d['viz']=bool(d.get('series'))
    d['rows']=rows; d['nrows']=len(rows); d['chars']=len(d['headline'] or '')+sum(len(r['text']) for r in rows)
    d['venues']=sorted({v for r in rows for v in r['venues']}); out.append(d)
json.dump(out,open('cards5.json','w'))
for c in out: print(c['n'],c['type'],'|',c['headline'],'|',c.get('tag') or '','|',[(r['text'][:30],r['num'],r.get('prev')) for r in c['rows']][:5])
print(out[0]['rows'][0].get('earlier'))
