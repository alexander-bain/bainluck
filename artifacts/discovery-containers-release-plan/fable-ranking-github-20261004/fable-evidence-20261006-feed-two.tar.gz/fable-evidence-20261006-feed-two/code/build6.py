import json,re
s=open('../v3/comparison-slate-v3.html').read()
a=s.index('<style>'); b=s.index('</style>'); css=s[a+7:b]
j=s.index('function el('); k=s.index('function buildItem'); fn=s[j:k]
cards=json.load(open('cards5.json'))
def rep(a,b):
    global fn
    assert a in fn,a[:70]; fn=fn.replace(a,b)
rep("""function moverRows(c){
  const box = el('div', 'rows');
  c.rows.forEach(r => {""","""function duelChart(c){
  // two lines on a fixed 0 to 100 scale; no smoothing: each point is one observation from the venue's own price history
  const W = 320, H = 132, L = 26, R = 34, T = 8, B = 20, pw = W-L-R, ph = H-T-B;
  const x = t => L + (t - c.t0) / (c.t1 - c.t0) * pw, y = v => T + (1 - v) * ph;
  const s = svg('svg', {viewBox:`0 0 ${W} ${H}`, class:'chart duel', role:'img'});
  s.setAttribute('aria-label', c.rows.map((r, i) => r.text + ': ' + r.prev + '% to ' + r.num + '% ' + c.span).join('; '));
  [0,50,100].forEach(v => {
    s.append(svg('line', {x1:L, x2:W-R, y1:y(v/100), y2:y(v/100), class:'grid'}));
    const t = svg('text', {x:L-6, y:y(v/100)+3.5, 'text-anchor':'end', class:'ax'}); t.textContent = v; s.append(t);
  });
  const ends = [];
  c.series.forEach((pts, i) => {
    const d = pts.map((p, k) => (k ? 'L' : 'M') + x(p[0]).toFixed(1) + ',' + y(p[1]).toFixed(1)).join(' ');
    s.append(svg('path', {d, class:'ln' + (i ? ' b' : '')}));
    const last = pts[pts.length-1]; ends.push({i, x: x(last[0]), y: y(last[1]), num: c.rows[i].num});
  });
  if(ends.length === 2 && Math.abs(ends[0].y - ends[1].y) < 12){ const up = ends[0].y < ends[1].y ? 0 : 1; const mid = (ends[0].y + ends[1].y) / 2; ends[up].ly = mid - 6; ends[1-up].ly = mid + 6; }
  ends.forEach(e => {
    s.append(svg('circle', {cx:e.x, cy:e.y, r:3.5, class:'dot' + (e.i ? ' b' : '')}));
    const t = svg('text', {x:e.x + 7, y:(e.ly == null ? e.y : e.ly) + 4, 'text-anchor':'start', class:'val'}); t.textContent = e.num + '%'; s.append(t);
  });
  const a = svg('text', {x:L, y:H-5, 'text-anchor':'start', class:'ax'}); a.textContent = fmtDate(c.t0*1000, true); s.append(a);
  const z = svg('text', {x:W-R, y:H-5, 'text-anchor':'end', class:'ax'}); z.textContent = 'now'; s.append(z);
  return s;
}
function moverRows(c){
  const box = el('div', 'rows');
  c.rows.forEach((r, idx) => {
    if(idx === 1 && c.conn) box.append(el('div', 'conn', c.conn));""")
rep("const row = el('div', 'row'); const tx = el('div', 't', cap(r.text));","const row = el('div', 'row'); const tx = el('div', 't'); if(c.series){ tx.append(el('i', idx ? 'sw b' : 'sw')); tx.append(' '); } tx.append(cap(r.text));")
rep("(r.delta > 0 ? 'Up ' : 'Down ') + Math.abs(r.delta) + ' in a week, from ' + r.prev + '%'","(r.delta === 0 ? 'Unchanged ' : (r.delta > 0 ? 'Up ' : 'Down ') + Math.abs(r.delta) + ' ') + (c.span || 'in a week') + (r.delta === 0 ? '' : ', from ' + r.prev + '%') + (r.note ? '. ' + r.note : '')")
rep("const m = el('div', 'meter mv');","const m = el('div', 'meter mv' + (c.series && idx ? ' b' : ''));")
rep("if(c.type === 'board' || c.type === 'band' || c.type === 'peer' || c.type === 'funnel') card.append(rowList(c));","if(c.type === 'board' || c.type === 'band' || c.type === 'peer' || c.type === 'checklist' || (c.type === 'roundup' && c.rows[0].prev == null)) card.append(rowList(c));")
rep("else if(c.type === 'movers') card.append(moverRows(c));","else if(c.type === 'movers' || c.type === 'roundup' || c.type === 'swing' || c.type === 'newfav'){ if(c.series) card.append(duelChart(c)); card.append(moverRows(c)); }")
rep("li.append(el('div', 'v', 'Venue wording: “' + r.raw.trim() + '”. ' + parts.join(', ') + (parts.length > 1 ? ' (shown: the average)' : '') + '. Ref ' + r.id + '.'));","li.append(el('div', 'v', 'Venue wording: “' + r.raw.trim() + '”. ' + parts.join(', ') + (parts.length > 1 ? ' (shown: the average)' : '') + '.' + (r.earlier ? ' Earlier value observed: ' + r.earlier + (parts.length > 1 ? ' (shown: the average)' : '') + '.' : '') + ' Ref ' + r.id + '.'));")
rep("  fp.append(el('div', 'v', 'Card ' + c.cid + '.'));","  if(c.series) fp.append(el('div', 'v', 'Chart: every point is one observation from the venue\\'s own price history, drawn on a fixed 0 to 100 scale with no smoothing.'));\n  fp.append(el('div', 'v', 'Card ' + c.cid + '.'));")
extra_css='''
/* feed actions */
.acts{display:flex;gap:6px;align-items:center;padding-inline:2px;flex-wrap:wrap}
.acts button{font:inherit;font-size:13px;font-weight:600;color:var(--ink2);background:var(--card);border:1px solid var(--line);border-radius:999px;padding:8px 11px;min-height:40px;display:inline-flex;align-items:center;gap:6px;cursor:pointer;transition:background .15s,border-color .15s,color .15s;white-space:nowrap}
.acts button svg{width:16px;height:16px;flex:none;stroke:currentColor;fill:none;stroke-width:1.8;stroke-linecap:round;stroke-linejoin:round}
.acts button:hover{border-color:var(--ink3)}
.acts button:focus-visible{outline:2px solid var(--a);outline-offset:2px}
.acts button[aria-pressed="true"]{background:var(--brand-soft);border-color:var(--brand);color:var(--brand-ink)}
.acts button[data-k="notforme"][aria-pressed="true"]{background:var(--mid-soft);border-color:var(--ink3);color:var(--ink)}
.acts button[aria-pressed="true"] svg.fillable{fill:currentColor}
.acts .more{margin-left:auto;border-color:transparent;background:transparent;padding-inline:6px}
.item details>summary{display:none}
.endfeed{margin-top:40px;padding:18px;border:1px dashed var(--line);border-radius:14px;color:var(--ink2);font-size:14px;text-align:center}
.chart .ln.b{stroke:var(--b)} .chart .dot.b{fill:var(--b)}
.chart.duel{margin-top:-4px}
.row .t .sw{vertical-align:baseline;margin-right:2px;border-radius:50%}
'''
html_top='''<title>Comparison Feed Two</title>
<style>'''+css+extra_css+'''</style>

<div class="wrap">
  <header class="intro">
    <h1>Comparison Feed Two</h1>
    <p>'''+str(len(cards))+''' cards in one feed. Scroll it the way you would scroll the app.</p>
    <p>React as you go: <b>Like</b> a card you enjoy, <b>Share</b> one you would send to someone, <b>Not for me</b> on one you would rather not see. <b>Details</b> shows what is behind a card. There is nothing to grade at the end.</p>
    <p>Each question appears once. Every question was checked today against the news for whether it has already happened.</p>
    <div class="asof">Prices pulled Tue Oct 6, 2026, 2:41 to 2:44pm PT. These are venue prices, not the Bain Luck blend. Every "from" value was observed in the same venue's own price history. The page records how long each card is on screen and what you tap.</div>
  </header>

  <div class="bar" id="bar">
    <div class="barrow">
      <span class="count" id="count">'''+str(len(cards))+''' cards</span>
      <button class="status" id="status" type="button" disabled>Connecting</button>
    </div>
    <div class="prog"><i id="prog"></i></div>
  </div>
  <div class="banner" id="banner" hidden></div>

  <main class="feed" id="feed"></main>
  <div class="endfeed" id="endfeed">That is the last card. Nothing else to do here. Tell Fable what you thought.</div>
</div>

<script>
const CARDS = '''+json.dumps(cards,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')+''';
const ASOF = Date.UTC(2026, 9, 6, 21, 44);
const TYPE_NAME = {movers:'Movers', roundup:'Round-up', swing:'The swing', newfav:'New favorite', checklist:'Checklist', band:'Same odds', board:'Same deadline', peer:'Same question', deadheat:'Dead heat', when:'The tipping point', h2h:'Head to head'};
const LS_KEY = 'comparison-feed-two-1';
'''
js=open('feed6.js').read()
open('comparison-feed-two.html','w').write(html_top+fn+js+'\n</script>\n'); print(len(html_top+fn+js))
