import json,collections,re,sys,os,random,statistics as st
M={q['id']:q for q in json.load(open('table.json'))}
MVD=json.load(open('moves.json')); MV=MVD['moves']; NOW=MVD['now']
def pct(p):
    x=round(p*1000); return (x+5)//10
def nsubj(s):
    s=(s or '').lower().strip(); s=re.sub(r"^(the|president|us|u\.s\.) ",'',s); return {'trump':'donald trump'}.get(s,s)
FINAL=len(sys.argv)>1
# ---------- series round-up (Kalshi series-winner questions, hourly history)
TEAM={'Tampa Bay':'Tampa Bay Rays','New York Y':'New York Yankees','Los Angeles D':'Los Angeles Dodgers','Chicago WS':'Chicago White Sox','San Diego':'San Diego Padres','Milwaukee':'Milwaukee Brewers','Atlanta':'Atlanta Braves','Cleveland':'Cleveland Guardians'}
S=[o for o in json.load(open('series5.json')) if o['event'].startswith('KXMLBSERIES-26')]
extra=[]; rows=[]
by=collections.defaultdict(list)
for o in S: by[o['event']].append(o)
for ev,ms in by.items():
    if len(ms)!=2 or any(m['mid'] is None for m in ms): continue
    lead=max(ms,key=lambda m:m['mid']); other=min(ms,key=lambda m:m['mid'])
    w=[x for x in lead['hist'] if 20*3600<=NOW-x[0]<=28*3600]
    if not w: continue
    th=min(w,key=lambda x:abs(NOW-x[0]-86400))
    lg='American' if 'ALDS' in ev else 'National'
    i='s%d'%len(extra)
    q=dict(id=i,src='K',ev=ev,name=lead['name'],title=lead['title'],text=lead['title']+' — '+lead['name'],kind='named',p=lead['mid'],pK=lead['mid'],pP=None,venues=['K'],deadline=lead['close'],rules=lead['rules'],vol=lead['volume'],evvol=sum(m['volume'] or 0 for m in ms),
           plain=f"The {TEAM[lead['name']]} win their 2026 {lg} League Division Series against the {TEAM[other['name']]}",gotcha='This is the best-of-five Division Series only, not the pennant or the World Series.',subject=TEAM[lead['name']],domain='sports',recog=3,appeal=3,weight=1,tone='light',fam='K:'+ev,
           rowname=f"{TEAM[lead['name']].split()[-1] if TEAM[lead['name']]!='Chicago White Sox' else 'White Sox'} over the {TEAM[other['name']].split()[-1] if TEAM[other['name']]!='Chicago White Sox' else 'White Sox'}")
    extra.append(q); rows.append((q,pct(th[1]),dict(then=th[1],obs=[dict(venue='Kalshi',ts=th[0],value=th[1])])))
for q in extra: M[q['id']]=q
C=[]
if len(rows)>=3:
    rows.sort(key=lambda r:-abs(r[0]['p']-r[2]['then']))
    C.append(dict(type='roundup',ids=[r[0]['id'] for r in rows],score=9,title='Division Series: who is likely to advance',tag='MLB playoffs',prev=[r[1] for r in rows],names=[r[0]['rowname'] for r in rows],span='since yesterday',field='d1',obsx={r[0]['id']:r[2] for r in rows}))
# ---------- round-ups of contest leaders
for c in json.load(open('cands6r.json')): C.append(c)
# ---------- candidates from the generators
for c in json.load(open('cands3.json')):
    if c['type'] in('board','band','deadheat','peer','h2h','when'): C.append(c)
for c in json.load(open('cands5m.json')):
    if c['type'] in('movers','swing','newfav','checklist'): C.append(c)
# ---------- do not repeat single-question cards he has already graded; tidy movers
GRP={'swing':'duel','newfav':'duel','deadheat':'duel','checklist':'list','peer':'peer','when':'when','h2h':'h2h'}
seen=set()
for vv,ff in (('../v3','final3.json'),('../v4','final4.json'),('../v5','final5.json')):
    T={q['id']:q for q in json.load(open(vv+'/table.json'))}
    for c in json.load(open(vv+'/'+ff)):
        if c['type'] in GRP:
            for i in c['ids']: seen.add((GRP[c['type']],T[i]['src'],T[i]['ev']))
C=[c for c in C if not (c['type'] in GRP and sum((GRP[c['type']],M[i]['src'],M[i]['ev']) in seen for i in c['ids'])>=2)]
def caps(i): return set(re.findall(r'\b[A-Z][a-z]+',M[i]['plain']))-{'The','A','An','US','United','States','In','No'}
for c in C:
    if c['type']=='movers':
        keep=[]
        for k,i in enumerate(c['ids']):
            if all(len(caps(i)&caps(c['ids'][j]))<3 for j in keep): keep.append(k)
        if len(keep)<len(c['ids']): c['ids']=[c['ids'][k] for k in keep]; c['prev']=[c['prev'][k] for k in keep]
C=[c for c in C if len(c['ids'])>=(3 if c['type']=='movers' else 2)]
for k,c in enumerate(C): c['key']=k
BLOCKV=set(); BLOCKT=set(); DUP=set(); V={}
if FINAL:
    prev={c['key']:c['vid'] for c in json.load(open('cand_slate5.json'))}
    for f in sorted(os.listdir('.')):
        if re.match(r'check_out_\d+\.json',f):
            for v in json.load(open(f)): V[v['vid']]=v
    BLOCKV={k for k,v in V.items() if v['verdict']=='fail'}
    sc=json.load(open('slatecheck_out.json'))
    for x in sc['contradictions']:
        ids=[i for i in x['ids'] if i in M]
        if len(ids)>=2: BLOCKT.add(sorted(ids,key=lambda i:(M[i]['vol'] or 0,M[i]['evvol'] or 0))[0])
    DUP={frozenset((x['first'],x['second'])) for x in sc['duplicates']}; BLOCKV|={x['jid'] for x in sc['misleading']}
    Q=json.load(open('quality5.json')) if os.path.exists('quality5.json') else {}
    HAP={}
    for f in sorted(os.listdir('.')):
        if re.match(r'happened_out_\d+\.json',f):
            for v in json.load(open(f)): HAP[v['id']]=v
    GONE={i for i,v in HAP.items() if v.get('status') in('happened','decided','unsure')}
    UNCHECKED=set()
    C2=[]; DROPS=[]
    for c in C:
        if c['key'] not in prev: continue
        c['vid']=prev[c['key']]
        if c['vid'] in BLOCKV or c['vid'] not in V: DROPS.append((c['vid'],'card','checker fail or unchecked')); continue
        drop=set(V[c['vid']].get('drop_members') or [])|{i for i in c['ids'] if i in BLOCKT}|{i for i in c['ids'] if i in GONE}|{i for i in c['ids'] if i not in HAP}
        UNCHECKED|={i for i in c['ids'] if i not in HAP}
        if c.get('field'): drop|={i for i in c['ids'] if Q.get(i+':'+c['field'])=='bad'}
        keep=[k for k,i in enumerate(c['ids']) if i not in drop]
        need={'movers':3,'band':3,'checklist':3,'board':3,'peer':3,'roundup':3,'when':99,'h2h':99}.get(c['type'],2)
        if len(keep)<len(c['ids']) and (len(keep)<need or c['type'] in('swing','newfav','deadheat','when','h2h')): DROPS.append((c['vid'],'card','member removed: '+','.join(sorted(drop&set(c['ids']))))); continue
        for f in ('ids','prev','names','notes'):
            if c.get(f): c[f]=[c[f][k] for k in keep]
        C2.append(c)
    C=C2; json.dump(DROPS,open('drops5.json','w'),indent=1); print('drops',DROPS); print('already happened or decided:',sorted(GONE),'| not checked (dropped):',sorted(UNCHECKED))
WANT=collections.OrderedDict(roundup=7,movers=5,newfav=3,swing=3,deadheat=2,peer=2,checklist=2,when=2,board=2,band=2,h2h=1)
MOVE=('swing','newfav')
subj=collections.Counter(); chosen=[]; reserve=[]
used_ids=set(); used_fams=set(); used_plain=[]; used_tags=collections.Counter()
ptok=lambda i:set(re.findall(r'[a-z0-9]+',M[i]['plain'].lower()))
_T5={q['id']:q for q in json.load(open('../v5/table.json'))}
for _q in json.load(open('../v5/extra_claims.json')): _T5[_q['id']]=_q
SEEN5={(_T5[i]['src'],_T5[i]['ev'],_T5[i]['name']) for c in json.load(open('../v5/final5.json')) for i in c['ids']}
STOPC={'The','A','An','US','United','States','In','No','January','February','March','April','May','June','July','August','September','October','November','December','President','Day'}
pcap=lambda i:set(re.findall(r"\b[A-Z][A-Za-z0-9'\-]+",M[i]['plain']))-STOPC
used_caps=[]
def shown_before(i): return (M[i]['src'],M[i]['ev'],M[i]['name']) in SEEN5
def tmpl(c): return re.sub(r'\b(AFC|NFC|AL|NL) (East|West|North|South|Central)\b','DIV',c.get('title') or '')
def conflict(i):
    """a question already used by an earlier card in this feed: same claim, same venue event, or a near-identical sentence"""
    if i in used_ids or M[i]['fam'] in used_fams: return True
    t=ptok(i)
    if any(len(t&u)/max(1,len(t|u))>=0.6 for u in used_plain): return True
    k=pcap(i); return any(len(k&u)>=2 and len(k&u)/len(k|u)>=0.6 for u in used_caps)
LIST={'movers':3,'board':4,'band':3,'checklist':3,'peer':3,'roundup':3}
def ok(c):
    t=c['type']; same=[x for x in chosen if x['type']==t]
    bad=[k for k,i in enumerate(c['ids']) if conflict(i) or (t!='roundup' and shown_before(i)) or (t in LIST and t!='roundup' and subj[nsubj(M[i]['subject'])]>=1)]
    if bad:
        if t not in LIST or len(c['ids'])-len(bad)<LIST[t]: return False
        n0=len(c['ids']); keep=[k for k in range(n0) if k not in bad]
        for f in ('ids','prev','names','notes'):
            if c.get(f) and len(c[f])==n0: c[f]=[c[f][k] for k in keep]
    qs=[M[i] for i in c['ids']]
    if FINAL and any(frozenset((c['vid'],x['vid'])) in DUP for x in chosen): return False
    if t!='roundup' and any(subj[s]>=1 for s in {nsubj(q['subject']) for q in qs}): return False
    if t in('board','band') and any(x['title']==c['title'] for x in same): return False
    if t=='roundup' and used_tags[c.get('tag')]>=1: return False
    if t=='roundup' and c.get('rkey')=='titles' and len(c['ids'])<4: return False
    if t in MOVE or t=='deadheat':
        duel=[x for x in chosen if x['type'] in MOVE or x['type']=='deadheat']
        if any(tmpl(x)==tmpl(c) for x in duel): return False
        if t in MOVE and qs[0]['domain']=='sports' and sum(1 for x in duel if x['type'] in MOVE and M[x['ids'][0]]['domain']=='sports')>=2: return False
    if t=='movers':
        if sum(1 for x in same if x.get('field')==c.get('field'))>=2: return False
        if sum(1 for x in same if x['title']==c['title'] and x.get('tag')==c.get('tag')): return False
    if t=='checklist' and qs[0]['domain']=='sports' and any(M[x['ids'][0]]['domain']=='sports' for x in same): return False
    return True
def take(c):
    chosen.append(c)
    for i in c['ids']: used_ids.add(i); used_fams.add(M[i]['fam']); used_plain.append(ptok(i)); used_caps.append(pcap(i))
    for s_ in {nsubj(M[i]['subject']) for i in c['ids']}: subj[s_]+=1
    if c['type']=='roundup': used_tags[c.get('tag')]+=1
for t in WANT:
    n=0
    for c in sorted([c for c in C if c['type']==t],key=lambda c:-c['score']):
        if n<WANT[t] and ok(c): take(c); n+=1
        elif not FINAL and len([r for r in reserve if r['type']==t])<{'movers':5,'board':2,'roundup':3}.get(t,2): reserve.append(c)
    print(t,n,'of',WANT[t])
json.dump(extra,open('extra_claims.json','w'))
def obs(c,k,i):
    if c.get('obsx'): return c['obsx'][i]
    if c.get('field') and i in MV and c['field'] in MV[i]: return MV[i][c['field']]
if not FINAL:
    allc=chosen+reserve
    for k,c in enumerate(allc): c['vid']='y%02d'%k
    json.dump(allc,open('cand_slate5.json','w'),indent=1)
    SP={'since yesterday':'yesterday','a week':'a week ago','a month':'a month ago'}
    def block(c,rules=True):
        s=f"\n## {c['vid']} — type: {c['type']} — headline: {c.get('title') or '(none)'}"+(f" — tag: {c['tag']}" if c.get('tag') else '')+"\n"
        for k,i in enumerate(c['ids']):
            q=M[i]; x=''
            if c.get('prev'): x+=f" | shown as: was {c['prev'][k]}% {SP[c['span']]}"
            if c.get('names') and len(c['names'])==len(c['ids']): x+=f" | row name: {c['names'][k]}"
            if c.get('notes'): x+=f" | row note: {c['notes'][k]}"
            if c.get('labels'): x+=f" | row label: {c['labels'][k//2]} | side: {c['names'][k%2]}"
            if c['type']=='when' and c.get('flip')==k: x+=" | marked: first date likelier than not"
            s+=f"- id {i} | {pct(q['p'])}% | kind {q['kind']} | deadline {q['deadline']} | venue {'/'.join(q['venues'])}{x}\n  SENTENCE: {q['plain']}\n  VENUE WORDING: {q['text'].strip()}\n"+(f"  RULES EXCERPT: {(q.get('rules') or '')[:300]}\n" if rules else '')
        return s
    nb=3; per=-(-len(allc)//nb)
    for b in range(nb): open(f'check_in_{b}.md','w').write(''.join(block(c) for c in allc[b*per:(b+1)*per]))
    open('slatecheck_in.md','w').write('# Cards that may be shown together in one feed\n'+''.join(block(c,False) for c in allc))
    print(len(chosen),len(reserve))
else:
    random.seed(11); bt=collections.defaultdict(list)
    for c in chosen: bt[c['type']].append(c)
    order=[]; last=None
    while any(bt.values()):
        opts=[t for t in bt if bt[t] and t!=last] or [t for t in bt if bt[t]]
        t=max(opts,key=lambda t:(len(bt[t])+random.random()*0.5)); order.append(bt[t].pop(0)); last=t
    for n,c in enumerate(order):
        c['n']=n+1; c['check']=V[c['vid']]; c['obs']=[obs(c,k,i) for k,i in enumerate(c['ids'])]
    json.dump(order,open('final5.json','w'),indent=1); print(len(order),collections.Counter(c['type'] for c in order))
for c in chosen: print(c.get('vid'),c['type'],c.get('title'),'|',c.get('tag') or '','|',' / '.join('%d %s'%(pct(M[i]['p']),(c['names'][k] if c.get('names') and c['type']!='h2h' else M[i]['plain'])[:28]) for k,i in enumerate(c['ids'])),c.get('prev') or '')
