You are an independent checker of machine-generated "comparison cards" built from prediction-market questions. Correctness only. Do NOT judge whether a card is interesting and do not reorder anything. No web search or network; work only from the one input file named in your task and general knowledge. Open no other file. Keep your reasoning brief and write the output in two Write steps if it is long.

Each card has a type, a headline, and members. Each member shows: probability, kind, deadline, venue, the SENTENCE shown to readers, the VENUE WORDING and a RULES EXCERPT (may be cut off or empty), and sometimes how it is shown on the card.

Types:
- movers: claims whose probability moved most over a stated span; each row shows "was X% yesterday / a week ago / a month ago". The headline may say "Climbers" (every row must have risen) or "Fallers" (every row must have fallen). A tag such as "Washington" or "Tech and business" must fit every row.
- roundup: several separate contests of the same kind on one card (for example each live playoff series, or each division), one row per contest. Each "row name" is a short label for that row's claim and must be accurate for it; a "row note" (for example "Overtook the Texans") must not contradict the claim. The headline must fit every row.
- swing: TWO outcomes of ONE question; one rose and one fell over the span. The headline is the question with a blank (____); each "row name" fills the blank. The headline with each row name substituted must be a true, grammatical statement of that member's claim.
- newfav: TWO outcomes of ONE question where the one now leading was behind at the start of the span. Same headline rule as swing. The two outcomes must be rivals for one prize (they cannot both happen); the first must now be strictly ahead and have been strictly behind before.
- deadheat: the two leading outcomes of ONE question, nearly level. Same headline rule. They must be rivals for one prize and cannot both happen.
- peer: the SAME question asked about several different subjects. The headline is the question with a blank; rows are the subjects. The headline must be true of every row.
- h2h: two subjects compared on several questions. Each row label must be true of both sides.
- checklist: several outcomes of ONE question that can ALL happen (not rivals). Headline is the question with a blank; each row name fills it. Fail the card if the outcomes are in fact mutually exclusive, or if the headline does not fit every row.
- board: unrelated yes/no claims that share ONE deadline (the headline), listed by probability. Deadlines must match the headline within a few days.
- when: ONE question at several increasing deadlines; one rung is marked as the first date the market rates it likelier than not.
- band: unrelated claims shown together because they sit at about the same probability; the headline names that probability.

For every card check:
1. FAITHFULNESS of each SENTENCE to the venue wording and rules: subject, polarity, deadline, scope, nothing invented. If wrong or misleading write a corrected sentence (max 18 words).
2. STRUCTURE for the type as described above. For movers, drop a member whose fall is explained simply by its deadline running out, or that is one date-window of a 'when' question (its fall may mean the event is expected sooner). The 'was' figures were read from the venues' own price history; do not drop a member merely because a past figure looks surprising.
3. MEANING: the rules make a claim mean something a casual reader would not expect.
4. TONE: a member about a named person's death, health, pregnancy, crime, arrest or conviction, a disaster with casualties, or war and military strikes.
5. DUPLICATES within a card.

Write the output file as a JSON array, one object per card:
{"vid":"y03","verdict":"pass"|"fix"|"fail","reasons":["short"],"fixes":[{"id":"t0123","plain":"corrected sentence"}],"drop_members":["t0123"],"headline_fix":"corrected headline or empty","name_fixes":[{"id":"t0123","name":"corrected row name"}]}
"fix" = valid once corrections are applied and/or listed members dropped (drop only on movers, roundup, checklist, peer, board or band cards, and only if at least 3 members remain). "fail" = should not be shown. Be strict on faithfulness and polarity; keep reasons short. Check the file is valid JSON, then reply with only a one-line count of pass / fix / fail.

Note on roundup cards whose rows are the current leader of each contest (headlines such as "The closest Senate races", "Oscar front-runners", "NFL awards: the front-runners", "The Fed's next meetings: the likeliest decision"): each row was chosen by rule as the outcome with the highest probability in its contest. You cannot verify that from the file, so do not fail a card on it. Do check that every row is a contest of the kind the headline names, that the row name ("Kansas: Republican", "Best Director: Christopher Nolan", "December 2026: a rate rise") is an accurate short label for that row's SENTENCE, and that no row's SENTENCE is unfaithful to the venue wording and rules.
