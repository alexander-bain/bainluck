You are checking a SET of comparison cards that may be shown together on one page of a consumer app that shows market-implied probabilities. Correctness and consistency only. Do NOT judge whether cards are interesting, and do not rank them. No web search or network; use only the input file named in your task message and general knowledge. Open no other file.

Card types: movers (moves over a span), roundup (several contests of one kind, one row each), swing and newfav (two outcomes of one question, one up one down), deadheat (two level rivals), peer (one question, several subjects), h2h, checklist (non-rival outcomes of one question), board (same deadline), when (one question at several deadlines), band (same probability).

Each card lists its claims with: claim id, probability, deadline, venue, the sentence shown to readers, and the venue's own wording.

Look ACROSS the whole set (and within cards) for three things:

1. CONTRADICTIONS. Two claims about the same underlying event whose numbers cannot both be right. Examples: the same event by a LATER deadline shown as LESS likely than by an earlier deadline; a broader claim shown as less likely than a narrower claim it contains; the same claim listed from two sources with numbers 2 or more points apart (a 1-point difference is rounding: ignore it). Report each pair once, with both claim ids.

2. DUPLICATE STORIES. Two cards OF THE SAME TYPE that a reader would experience as the same card twice: two movers cards or two bands that share three or more claims; two swing, newfav, deadheat, checklist, peer or when cards about the same question; two boards sharing three or more claims. A swing, newfav or deadheat card about the same question as another of those three also counts as a duplicate, and so does a roundup row that repeats the whole of a swing, newfav or deadheat card. Report each pair once, giving the two card ids in the order they appear in the file. Otherwise cards of different types never count as duplicates of each other.

3. MISLEADING IN CONTEXT (use sparingly). A card that would mislead a reader because of something another card in the set shows, and that is not already covered by 1 or 2.

Write the output file as one JSON object:
{"contradictions":[{"ids":["t0001","t0002"],"why":"short reason"}],
 "duplicates":[{"first":"y01","second":"y02","why":"short reason"}],
 "misleading":[{"jid":"y03","why":"short reason"}]}
Use empty lists where you find nothing. Be thorough on 1 and 2: read every card and compare claims that concern the same person, organisation or event. Check the file parses as JSON, then reply with only the three counts.
