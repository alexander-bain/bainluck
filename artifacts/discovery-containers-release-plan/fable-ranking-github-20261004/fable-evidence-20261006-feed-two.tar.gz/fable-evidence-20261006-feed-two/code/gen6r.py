# Round-up cards: several contests of one kind, one row per contest, each row is that contest's current leader.
import json,re,collections
M=json.load(open('table.json'))
A=json.load(open('../pull5/props_all.json'))
raw=collections.defaultdict(list)
for a in A: raw[(a['src'],a['ev'])].append((a['p'],a['name']))
OKT=lambda q:q['tone'] in('light','neutral')
def pct(p):
    x=round(p*1000); return (x+5)//10
fam=collections.defaultdict(list)
for q in M:
    if q['kind']=='named': fam[q['fam']].append(q)
def leader(ms):
    """the table row that is the true leader of its venue event, with its margin over the runner-up in the raw listing"""
    top=max(ms,key=lambda q:q['p']); r=sorted(raw[(top['src'],top['ev'])],reverse=True)
    if not r or r[0][1]!=top['name']: return None,None
    return top,(r[0][0]-r[1][0]) if len(r)>1 else None
NICK=lambda s:{'San Francisco 49ers':'49ers','Chicago White Sox':'White Sox','Boston Red Sox':'Red Sox','Toronto Blue Jays':'Blue Jays','Toronto Maple Leafs':'Maple Leafs','Vegas Golden Knights':'Golden Knights','Columbus Blue Jackets':'Blue Jackets','Detroit Red Wings':'Red Wings','Portland Trail Blazers':'Trail Blazers'}.get(s,s.split()[-1] if re.match(r'^[A-Z]',s) and len(s.split())>1 and not re.search(r'\b(State|Tech|College|University|United|City|FC|CF|SC)\b',s) else s)
def clean(s): return re.sub(r"^(The film |The |Christopher Nolan's )",'',s).strip()
FEDACT=lambda s:'no change' if 'unchanged' in s else ('a rate rise' if 'raises' in s else 'a rate cut')
TITLE={'World Series':'World Series','NBA Finals':'NBA Finals','Stanley Cup':'Stanley Cup','Super Bowl':'Super Bowl','College Football Playoff national championship game':'College football title','MLS Cup':'MLS Cup','UEFA Champions League':'Champions League'}
SPECS=[
 dict(key='senate',title='The closest Senate races',tag='Midterms',rx=r'^A (Democrat|Republican) is sworn in as US Senator from (.+?) for the term starting in 2027$',lab=lambda m:m.group(2),who=lambda m:m.group(1),pick='closest',n=4,maxlead=0.78),
 dict(key='governor',title='The closest governor races',tag='Midterms',rx=r'^A (Democrat|Republican) is inaugurated as (?:governor of (.+?)|(.+?) governor) (?:following|after) the 2026 election$',lab=lambda m:re.sub(r"'s$",'',m.group(2) or m.group(3)),who=lambda m:m.group(1),pick='closest',n=4,maxlead=0.72),
 dict(key='oscars',title='Oscar front-runners',tag='Oscars 2027',rx=r'^(.+?) wins (Best [A-Za-z ]+?) at the 2027 Oscars$',lab=lambda m:m.group(2),who=lambda m:clean(m.group(1)),pick='order',order=['Best Picture','Best Director','Best Actor','Best Actress','Best Supporting Actor','Best Supporting Actress'],n=5,margin=0.03),
 dict(key='fed',title="The Fed's next meetings: the likeliest decision",tag='Interest rates',rx=r'^The Federal Reserve (leaves interest rates unchanged|raises interest rates.*?|cuts interest rates.*?) (?:at its|on) ((?:January|February|March|April|May|June|July|August|September|October|November|December) (?:\d{1,2}, )?\d{4})(?: meeting)?$',lab=lambda m:re.sub(r' \d{1,2}, ',' ',m.group(2)),who=lambda m:FEDACT(m.group(1)),pick='chron',n=3,margin=0.03),
 dict(key='titles',title='The favorite for each title',tag='Sports',rx=r'^(?:The )?(.+?) wins? (?:the )?(?:\d{4}(?:-\d\d)? )?(World Series|NBA Finals|Stanley Cup|Super Bowl|College Football Playoff national championship game|MLS Cup|UEFA Champions League)\b.*$',lab=lambda m:TITLE[m.group(2)],who=lambda m:NICK(m.group(1)),pick='order',order=['World Series','Super Bowl','NBA Finals','Stanley Cup','College football title','Champions League','MLS Cup'],n=5,margin=0.02),
 dict(key='nflawards',title='NFL awards: the front-runners',tag='NFL',rx=r'^(.+?) wins (?:the )?NFL (?:regular-season )?(.+?)(?: award)? (?:for|in) the 2026(?:-27)? season$',lab=lambda m:{'Most Valuable Player':'MVP'}.get(m.group(2),m.group(2)),who=lambda m:m.group(1),pick='order',order=['MVP','Offensive Player of the Year','Defensive Player of the Year','Comeback Player of the Year','Coach of the Year','Offensive Rookie of the Year','Defensive Rookie of the Year'],n=5,margin=0.03),
 dict(key='nfldiv',title='The tightest NFL division races',tag='NFL',rx=r'^The (.+) win the ((?:AFC|NFC) (?:East|West|North|South)) division in the 2026 NFL season$',lab=lambda m:m.group(2),who=lambda m:NICK(m.group(1)),pick='closest',n=4,maxlead=0.6,margin=0.02),
 dict(key='2028',title='2028: the early leaders',tag='2028 election',rx=r'^(.+?) wins the 2028 (Democratic nomination for president|Republican nomination for president|US presidential election)$',lab=lambda m:{'Democratic nomination for president':'Democratic nomination','Republican nomination for president':'Republican nomination','US presidential election':'The presidency'}[m.group(2)],who=lambda m:m.group(1),pick='order',order=['Democratic nomination','Republican nomination','The presidency'],n=3,margin=0.02),
]
C=[]
for s in SPECS:
    rows={}
    for f,ms in fam.items():
        ms=[q for q in ms if OKT(q)]
        if not ms: continue
        top,mg=leader(ms)
        if top is None: continue
        m=re.match(s['rx'],top['plain'])
        if not m: continue
        if mg is not None and mg<s.get('margin',0.0): continue
        if 'maxlead' in s and top['p']>s['maxlead']: continue
        lab=s['lab'](m)
        if lab not in rows or top['vol']>rows[lab][0]['vol']: rows[lab]=(top,s['who'](m),mg)
    if s['pick']=='closest': items=sorted(rows.items(),key=lambda kv:kv[1][0]['p'])[:s['n']]; items=sorted(items,key=lambda kv:-kv[1][0]['p'])
    elif s['pick']=='order': items=[(l,rows[l]) for l in s['order'] if l in rows][:s['n']]
    else:
        MO='January February March April May June July August September October November December'.split()
        items=sorted(rows.items(),key=lambda kv:(int(kv[0].split()[-1]),MO.index(kv[0].split()[0])))[:s['n']]
    print('==',s['key'],len(rows),'contests ->',[(l,w,pct(q['p']),None if mg is None else round(mg*100)) for l,(q,w,mg) in items])
    if len(items)>=3:
        C.append(dict(type='roundup',ids=[q['id'] for _,(q,_,_) in items],score=7-0.1*len(C),title=s['title'],tag=s['tag'],names=[f"{l}: {w}" for l,(_,w,_) in items],rkey=s['key']))
json.dump(C,open('cands6r.json','w'),indent=1)
