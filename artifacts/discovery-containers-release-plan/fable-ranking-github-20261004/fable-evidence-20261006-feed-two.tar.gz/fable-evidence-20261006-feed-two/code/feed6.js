
// ---------- state
const S = {};                 // cid -> signals
CARDS.forEach(c => S[c.cid] = {impressions:0, dwell_ms:0, first_visit_ms:null, visits:0, liked:false, shared:false, notforme:false, details_opens:0, first_seen_order:null});
let seenCount = 0, store = null, storeState = 'connecting', failed = false;
const dirtyS = {}, busy = {};
const meta = {started_at: new Date().toISOString(), viewport: [window.innerWidth, window.innerHeight], touch: ('ontouchstart' in window)};
let dirtyMeta = true;

function persistLocal(){ try{ localStorage.setItem(LS_KEY, JSON.stringify({S, seenCount, meta})); }catch(e){} }
try{
  const o = JSON.parse(localStorage.getItem(LS_KEY) || 'null');
  if(o){ Object.keys(o.S || {}).forEach(k => { if(S[k]) Object.assign(S[k], o.S[k]); }); seenCount = o.seenCount || 0; if(o.meta && o.meta.started_at) meta.started_at = o.meta.started_at; }
}catch(e){}

function status(){
  const s = document.getElementById('status'); if(!s) return; s.classList.remove('err'); s.disabled = true;
  if(storeState === 'connecting'){ s.textContent = 'Connecting'; return; }
  if(storeState === 'local'){ s.textContent = 'This device only'; return; }
  if(failed){ s.textContent = 'Not saved. Tap to retry'; s.classList.add('err'); s.disabled = false; return; }
  const pending = Object.keys(dirtyS).some(k => dirtyS[k]) || Object.keys(busy).some(k => busy[k]);
  s.textContent = pending ? 'Saving' : 'Saved';
}
function count(){
  const seen = CARDS.filter(c => S[c.cid].impressions > 0).length;
  const el_ = document.getElementById('count'); if(el_) el_.textContent = seen + ' of ' + CARDS.length + ' seen';
  const p = document.getElementById('prog'); if(p) p.style.width = (seen / CARDS.length * 100) + '%';
}
async function write(key, path, data, clear, redo){
  if(busy[key] || !store) return; busy[key] = true;
  try{ clear(); await store.doc(path).set(data()); }
  catch(e){ failed = true; redo(); }
  busy[key] = false; status();
}
function flush(){
  if(!store) return;
  Object.keys(dirtyS).forEach(cid => { if(dirtyS[cid]){ const c = CARDS.find(x => x.cid === cid);
    write('s:' + cid, 'signals/' + cid, () => { const s = S[cid]; return {n: c.n, type: c.type, rows: c.nrows, chars: c.chars, viz: !!c.viz, viz_eligible: !!c.viz_eligible, at: new Date().toISOString(),
      impressions: s.impressions, dwell_ms: Math.round(s.dwell_ms), first_visit_ms: s.first_visit_ms == null ? null : Math.round(s.first_visit_ms), visits: s.visits, liked: s.liked, shared: s.shared, notforme: s.notforme, details_opens: s.details_opens, first_seen_order: s.first_seen_order}; },
      () => { dirtyS[cid] = false; }, () => { dirtyS[cid] = true; }); } });
  if(dirtyMeta) write('m:run', 'meta/run', () => Object.assign({cards: CARDS.length, at: new Date().toISOString()}, meta), () => { dirtyMeta = false; }, () => { dirtyMeta = true; });
  status();
}
function markS(cid){ dirtyS[cid] = true; persistLocal(); status(); }
document.getElementById('status').addEventListener('click', () => { failed = false; flush(); });
setInterval(flush, 4000);
document.addEventListener('visibilitychange', () => { if(document.visibilityState === 'hidden'){ endAll(); flush(); } });
window.addEventListener('pagehide', () => { endAll(); flush(); });

// ---------- feed
const ICON = {
  like: '<svg class="fillable" viewBox="0 0 24 24" aria-hidden="true"><path d="M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z"/></svg>',
  share: '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 15V4M8 8l4-4 4 4M5 13v5a2 2 0 0 0 2 2h10a2 2 0 0 0 2-2v-5"/></svg>',
  no: '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M6.5 17.5l11-11"/></svg>'
};
function shareText(c){ return (c.headline ? c.headline + ': ' : '') + c.rows.map(r => r.text + ' ' + r.num + '%').join('; '); }
function buildFeedItem(c){
  const item = el('section', 'item'); item.id = 'card-' + c.n; item.dataset.cid = c.cid;
  const card = buildCard(c); item.append(card);
  const acts = el('div', 'acts'); const s = S[c.cid];
  const mk = (icon, label, key) => { const b = el('button'); b.type = 'button'; b.dataset.k = key; b.innerHTML = icon; b.append(el('span', '', label)); b.setAttribute('aria-pressed', String(!!s[key])); return b; };
  const like = mk(ICON.like, 'Like', 'liked'), share = mk(ICON.share, 'Share', 'shared'), no = mk(ICON.no, 'Not for me', 'notforme');
  const paint = () => { like.setAttribute('aria-pressed', String(s.liked)); share.setAttribute('aria-pressed', String(s.shared)); no.setAttribute('aria-pressed', String(s.notforme)); };
  like.addEventListener('click', () => { s.liked = !s.liked; if(s.liked) s.notforme = false; paint(); markS(c.cid); });
  no.addEventListener('click', () => { s.notforme = !s.notforme; if(s.notforme){ s.liked = false; s.shared = false; } paint(); markS(c.cid); });
  share.addEventListener('click', () => { s.shared = !s.shared; if(s.shared){ s.notforme = false; try{ navigator.clipboard.writeText(shareText(c)).catch(() => {}); }catch(e){} } paint(); markS(c.cid); });
  const fp = finePrint(c);
  const more = el('button', 'more', 'Details'); more.type = 'button'; more.setAttribute('aria-expanded', 'false');
  more.addEventListener('click', () => { fp.open = !fp.open; more.setAttribute('aria-expanded', String(fp.open)); more.textContent = fp.open ? 'Hide' : 'Details'; if(fp.open){ s.details_opens++; markS(c.cid); } });
  acts.append(like, share, no, more);
  item.append(acts, fp);
  return item;
}
const feed = document.getElementById('feed'); CARDS.forEach(c => feed.append(buildFeedItem(c)));

// ---------- reading time
// A card is on screen when half of it is visible, or when it fills most of the screen.
// Each quarter second is split among the on-screen cards in proportion to the pixels each is showing, so a short card beside a tall one still earns its share.
const view = {};              // cid -> {t: wall ms on screen this visit, w: weighted ms this visit}
let lastAct = Date.now();
['scroll','pointerdown','touchstart','touchmove','keydown','wheel'].forEach(ev => window.addEventListener(ev, () => { lastAct = Date.now(); }, {passive: true}));
function visPx(node){
  const r = node.getBoundingClientRect(), vh = window.innerHeight || 1;
  return {vis: Math.max(0, Math.min(r.bottom, vh) - Math.max(r.top, 0)), h: r.height, vh};
}
function onScreen(v){ return v.h > 0 && (v.vis / v.h >= 0.5 || v.vis / v.vh >= 0.6); }
function endView(cid){
  const v = view[cid]; if(!v) return;
  if(v.t >= 1000){ const s = S[cid]; s.visits++; if(s.first_visit_ms == null) s.first_visit_ms = v.w; markS(cid); }
  delete view[cid];
}
function endAll(){ Object.keys(view).forEach(endView); }
const cardNodes = CARDS.map(c => [c.cid, document.querySelector('#card-' + c.n + ' .card')]);
const TICK = 250, IDLE = 30000;
setInterval(() => {
  if(document.visibilityState !== 'visible' || Date.now() - lastAct > IDLE){ endAll(); return; }
  const vs = cardNodes.map(([cid, node]) => [cid, visPx(node)]);
  const on = vs.filter(([cid, v]) => onScreen(v)); const total = on.reduce((a, x) => a + x[1].vis, 0) || 1;
  vs.forEach(([cid, v]) => {
    if(onScreen(v)){
      const o = view[cid] || (view[cid] = {t: 0, w: 0}); const before = o.t; const share = TICK * v.vis / total;
      o.t += TICK; o.w += share; S[cid].dwell_ms += share;
      if(before < 1000 && o.t >= 1000){ S[cid].impressions++; if(S[cid].first_seen_order == null){ seenCount++; S[cid].first_seen_order = seenCount; } count(); }
      if(o.t === 1000 || o.t % 2000 === 0) markS(cid);
    } else endView(cid);
  });
}, TICK);
count(); status();

// ---------- shared store
function goLocal(){ storeState = 'local'; status(); const b = document.getElementById('banner'); b.hidden = false; b.textContent = 'This is being kept on this device only, so Fable cannot read it. Open this page signed in to claude.ai to save it.'; }
(async () => {
  let db = null;
  try{ db = window.claude && window.claude.use ? await window.claude.use('db') : null; }catch(e){ db = null; }
  if(!db){ goLocal(); return; }
  let first = true;
  try{
    db.collection('signals').onSnapshot(snap => { if(!first) return; first = false;
      snap.docs.forEach(d => { const v = d.data() || {}, s = S[d.id]; if(!s) return;
        ['impressions','dwell_ms','visits','details_opens'].forEach(k => { s[k] = Math.max(s[k] || 0, v[k] || 0); });
        if(s.first_visit_ms == null && v.first_visit_ms != null) s.first_visit_ms = v.first_visit_ms;
        if(!s.liked && !s.notforme && !s.shared){ s.liked = !!v.liked; s.shared = !!v.shared; s.notforme = !!v.notforme; }
        if(s.first_seen_order == null && v.first_seen_order != null){ s.first_seen_order = v.first_seen_order; seenCount = Math.max(seenCount, v.first_seen_order); } });
      document.querySelectorAll('.item').forEach(it => { const s = S[it.dataset.cid]; if(!s) return; it.querySelectorAll('.acts button[data-k]').forEach(b => b.setAttribute('aria-pressed', String(!!s[b.dataset.k]))); });
      store = db; storeState = 'ready'; CARDS.forEach(c => { const s = S[c.cid]; if(s.impressions || s.liked || s.shared || s.notforme || s.details_opens) dirtyS[c.cid] = true; }); count(); flush(); status();
    }, () => { goLocal(); });
  }catch(e){ goLocal(); }
})();
