import asyncio,json,collections
from playwright.async_api import async_playwright
FAKE="""window.__w={};window.__n=0;window.claude={use:async n=>({doc:p=>({set:async d=>{window.__n++;window.__w[p]=d}}),collection:c=>({onSnapshot:(f)=>{setTimeout(()=>f({docs:[],metadata:{fromCache:false}}),60)}})})}"""
async def main():
    async with async_playwright() as p:
        b=await p.chromium.launch()
        html=open('comparison-feed-two.html').read()
        open('preview.html','w').write('<!doctype html><html><head><meta charset=utf8><meta name=viewport content="width=device-width,initial-scale=1"><style>body{margin:0}[hidden]{display:none!important}</style></head><body>'+html+'</body></html>')
        for scheme,vp in (('light',{'width':390,'height':800}),('dark',{'width':390,'height':800}),('desk',{'width':950,'height':1028})):
            ctx=await b.new_context(viewport=vp,device_scale_factor=2,color_scheme='dark' if scheme=='dark' else 'light')
            pg=await ctx.new_page(); errs=[]
            pg.on('pageerror',lambda e: errs.append(str(e)))
            await pg.add_init_script(FAKE)
            await pg.goto('file:///home/claude/slate/v6/preview.html'); await pg.wait_for_timeout(500)
            print(scheme,'scrollWidth',await pg.evaluate('document.documentElement.scrollWidth'),'height',await pg.evaluate('document.documentElement.scrollHeight'),'acts rows wrap?',await pg.evaluate("[...document.querySelectorAll('.acts')].filter(a=>a.getBoundingClientRect().height>50).length"))
            if scheme=='dark':
                await pg.screenshot(path='shot6_D.png',full_page=True); await ctx.close(); continue
            n=await pg.evaluate('CARDS.length')
            for i in range(1,n+1):
                await pg.evaluate(f"document.querySelector('#card-{i} .card').scrollIntoView({{block:'center'}}); window.dispatchEvent(new Event('scroll'))")
                await pg.wait_for_timeout(1400 if i%3 else 2600)
                if i%4==0: await pg.click(f'#card-{i} .acts button[data-k=liked]')
                if i%7==0: await pg.click(f'#card-{i} .acts button[data-k=shared]')
                if i%6==0: await pg.click(f'#card-{i} .acts button[data-k=notforme]')
                if i%5==0: await pg.click(f'#card-{i} .acts .more')
            await pg.evaluate("document.getElementById('endfeed').scrollIntoView({block:'center'}); window.dispatchEvent(new Event('scroll'))")
            await pg.wait_for_timeout(4800)
            w=await pg.evaluate('window.__w'); sig={k:v for k,v in w.items() if k.startswith('signals/')}
            print(' signal docs',len(sig),'of',n,'| meta',bool(w.get('meta/run')),'| writes',await pg.evaluate('window.__n'),'| status:',await pg.inner_text('#status'),'|',await pg.inner_text('#count'))
            print(' types',sorted({v['type'] for v in sig.values()}),'viz cards',sorted(v['n'] for v in sig.values() if v['viz']))
            dw=[v['dwell_ms'] for v in sig.values()]; fv=[v['first_visit_ms'] for v in sig.values()]
            print(' impressions min/max',min(v['impressions'] for v in sig.values()),max(v['impressions'] for v in sig.values()),'| dwell ms min/median/max',min(dw),sorted(dw)[len(dw)//2],max(dw),'| zero-dwell cards',sum(1 for x in dw if x==0),'| first_visit null',sum(1 for x in fv if x is None))
            print(' liked',sum(v['liked'] for v in sig.values()),'shared',sum(v['shared'] for v in sig.values()),'notforme',sum(v['notforme'] for v in sig.values()),'details',sum(v['details_opens'] for v in sig.values()),'| like+notforme both',sum(1 for v in sig.values() if v['liked'] and v['notforme']),'| order ok',sorted(v['first_seen_order'] for v in sig.values())==list(range(1,n+1)))
            print(' total dwell s',round(sum(dw)/1000,1),'| longer-pause cards',[(v['n'],v['dwell_ms']) for v in sig.values() if v['n']%3==0][:4],'others',[(v['n'],v['dwell_ms']) for v in sig.values() if v['n']%3][:4])
            print(' errors',errs)
            await pg.screenshot(path=f'shot6_{scheme}.png',full_page=True)
            await ctx.close()
        await b.close()
asyncio.run(main())
