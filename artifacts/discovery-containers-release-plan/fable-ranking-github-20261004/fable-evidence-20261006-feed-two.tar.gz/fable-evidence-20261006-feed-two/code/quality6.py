import json,urllib.request,time
ids=json.load(open('hist5_ids.json')); NOW=ids['now']; W=ids['ids']; MV=json.load(open('moves.json'))['moves']
C=json.load(open('cand_slate5.json'))
def get(u,tries=6):
    for a in range(tries):
        try: return json.loads(urllib.request.urlopen(urllib.request.Request(u,headers={'User-Agent':'Mozilla/5.0','Accept':'application/json'}),timeout=30).read())
        except Exception as ex: err=str(ex); time.sleep(1.5*(a+1))
    raise RuntimeError(err)
f=lambda x:(float(x) if x not in (None,'') else None)
need={(i,c['field']) for c in C if c.get('field') and not c.get('obsx') for i in c['ids']}
Q={}; detail={}
for i,fld in sorted(need):
    m=MV.get(i,{}).get(fld); k=W.get(i,{}).get('k')
    if not m: Q[i+':'+fld]='bad'; detail[i+':'+fld]='no verified move'; continue
    ko=[o for o in m['obs'] if o['venue']=='Kalshi']
    if not ko: Q[i+':'+fld]='ok'; continue
    ts=ko[0]['ts']; per=60 if fld=='d1' else 1440
    c=get(f"https://api.elections.kalshi.com/trade-api/v2/series/{k[0]}/markets/{k[1]}/candlesticks?start_ts={ts-per*60-60}&end_ts={ts+60}&period_interval={per}").get('candlesticks') or []
    x=[y for y in c if y['end_period_ts']==ts]
    if not x: Q[i+':'+fld]='bad'; detail[i+':'+fld]='candle not found'; continue
    b,a=f((x[0].get('yes_bid') or {}).get('close_dollars')),f((x[0].get('yes_ask') or {}).get('close_dollars'))
    good=b is not None and a is not None and a-b<=0.10 and not (b==0 and a>=0.99)
    Q[i+':'+fld]='ok' if good else 'bad'; detail[i+':'+fld]=dict(bid=b,ask=a,vol=f(x[0].get('volume_fp')))
    time.sleep(0.12)
json.dump(Q,open('quality5.json','w')); json.dump(detail,open('quality5_detail.json','w'),indent=1)
import collections; print(collections.Counter(Q.values())); print({k:v for k,v in detail.items() if Q[k]=='bad'})
