import json,re,collections,datetime,itertools,statistics as st
M=json.load(open('table.json')); R={q['id']:q for q in M}
def pct(p):
    x=round(p*1000); return (x+5)//10
def nsubj(s):
    s=(s or '').lower().strip(); s=re.sub(r"^(the|president|us|u\.s\.) ",'',s)
    return {'trump':'donald trump','fed':'federal reserve','the fed':'federal reserve'}.get(s,s)
TODAY=datetime.date(2026,10,6)
MV=json.load(open('moves.json'))['moves']; STAT=collections.Counter()
for q in M:
    q['pp']=pct(q['p']); q['rn']=q['recog']/3; q['an']=q['appeal']/3; q['wn']=q['weight']/3
    q['Q']=q['rn']*(0.5*q['an']+0.3*q['wn']+0.2); q['subj']=nsubj(q['subject'])
    try: q['days']=(datetime.date.fromisoformat(q['deadline'])-TODAY).days
    except Exception: q['days']=9999
    m=MV.get(q['id'],{})
    for f in ('d1','w1','m1'): q[f]=m[f]['move'] if f in m else None
    q['on']=None
OKT=lambda q:q['tone'] in('light','neutral')
def fe(q): return q['domain']=='world_politics' and re.search(r'election|ballot|referendum',q['plain']+' '+q['text'],re.I) is not None
key=lambda q:(q['src'],q['ev'],q['name'])
seen_v3=set()
T3={q['id']:q for q in json.load(open('../v3/table.json'))}
for c in json.load(open('../v3/final3.json')):
    if c['type']=='movers': seen_v3|={key(T3[i]) for i in c['ids']}
T4={q['id']:q for q in json.load(open('../v4/table.json'))}
for c in json.load(open('../v4/final4.json')):
    if c['type'] in('movers','swing','newfav'): seen_v3|={key(T4[i]) for i in c['ids']}
T5={q['id']:q for q in json.load(open('../v5/table.json'))}
for q in json.load(open('../v5/extra_claims.json')): T5[q['id']]=q
seen_v3|={key(T5[i]) for c in json.load(open('../v5/final5.json')) for i in c['ids']}
NDATE=collections.Counter(q['fam'] for q in M if q['kind']=='date')
E=[q for q in M if q['recog']>=2 and OKT(q) and not fe(q)]
EB=[q for q in E if key(q) not in seen_v3]
C=[]
def add(t,mem,score,**kw): C.append(dict(type=t,ids=[m['id'] for m in mem],score=round(score,4),**kw))
def jac(a,b):
    A=set(re.findall(r'[a-z0-9]+',a['plain'].lower())); B=set(re.findall(r'[a-z0-9]+',b['plain'].lower())); return len(A&B)/max(1,len(A|B))
def valid(q,f):
    v=q[f]
    if v is None or not (0<=q['p']-v<=1) or not (3<=q['pp']<=97) or key(q) in seen_v3: return False
    if v<0 and q['kind']=='date' and (q['days']<=30 or NDATE[q['fam']]>1): return False      # a deadline running out, or one window of a 'when' question, is not news
    return True
THEMES={'':None,'Washington':('us_politics',),'Tech and business':('tech_ai','business','economy'),'The world':('world_politics','war_security'),'Culture and sport':('entertainment','celebrity','sports'),'Science and space':('science_space',)}
def movers(f,thr,title,spanword,sign=0,themes=THEMES):
    pool0=[q for q in E if valid(q,f) and abs(q[f])>=thr and (sign==0 or q[f]*sign>0)]
    for th,doms in themes.items():
        pool=sorted([q for q in pool0 if doms is None or q['domain'] in doms],key=lambda q:-abs(q[f])*q['Q']); out=[]
        for q in pool:
            if any(q['subj']==o['subj'] or q['fam']==o['fam'] or jac(q,o)>=0.6 for o in out): continue
            if doms is None and sum(1 for o in out if o['domain']==q['domain'])>=2: continue
            out.append(q)
            if len(out)==4: break
        if len(out)>=3:
            out=sorted(out,key=lambda q:-abs(q[f]))
            add('movers',out,st.mean(abs(q[f])*q['Q'] for q in out)*(1.1 if doms is None else 1),title=title,tag=th or None,prev=[pct(q['p']-q[f]) for q in out],span=spanword,field=f,sign=sign)
movers('d1',0.05,'Moves since yesterday','since yesterday')
movers('w1',0.08,'Moves this week','a week')
movers('w1',0.08,'Climbers this week','a week',+1,{'':None})
movers('w1',0.08,'Fallers this week','a week',-1,{'':None})
movers('m1',0.15,'Moves this month','a month')
# ---------- the swing and new favorite: inside one question
fam=collections.defaultdict(list)
for q in M:
    if q['kind']=='named': fam[q['fam']].append(q)
def frame(plains):
    A=[p.split() for p in plains]; n=min(map(len,A)); i=0
    while i<n and len({a[i] for a in A})==1: i+=1
    j=0
    while j<n-i and len({a[-1-j] for a in A})==1: j+=1
    pre=' '.join(A[0][:i]); suf=' '.join(A[0][len(A[0])-j:]) if j else ''
    return (pre+' ____ '+suf).strip(), [' '.join(a[i:len(a)-j] if j else a[i:]) for a in A]
for f,ms in fam.items():
    ms=[q for q in ms if OKT(q) and not fe(q)]
    for fld,span in (('d1','since yesterday'),('w1','a week'),('m1','a month')):
        xs=[q for q in ms if q[fld] is not None and 0<=q['p']-q[fld]<=1]
        if len(xs)<2 or max(q['recog'] for q in xs)<2: continue
        up=max(xs,key=lambda q:q[fld]); dn=min(xs,key=lambda q:q[fld])
        if up[fld]>=0.06 and dn[fld]<=-0.06 and psum<=1.15 if (psum:=sum(q['p'] for q in ms)) else False:
            t,names=frame([up['plain'],dn['plain']])
            if len(t.split())>=4 and all(names) and max(len(n.split()) for n in names)<=5:
                add('swing',[up,dn],(up[fld]-dn[fld])*max(up['Q'],dn['Q']),title=t,names=names,prev=[pct(up['p']-up[fld]),pct(dn['p']-dn[fld])],span=span,field=fld)
        now=max(xs,key=lambda q:q['p']); then=max(xs,key=lambda q:q['p']-q[fld])
        if now is not then and now['p']-then['p']>=0.03 and psum<=1.15:
            t,names=frame([now['plain'],then['plain']])
            if len(t.split())>=4 and all(names) and max(len(n.split()) for n in names)<=5:
                add('newfav',[now,then],(now[fld]-then[fld])*max(now['Q'],then['Q'])*1.2,title=t,names=names,prev=[pct(now['p']-now[fld]),pct(then['p']-then[fld])],span=span,field=fld)
# ---------- trading places: two unrelated famous claims that swapped order
for fld,span in (('d1','since yesterday'),('w1','a week'),('m1','a month')):
    xs=[q for q in E if valid(q,fld) and q['recog']==3 and abs(q[fld])>=0.05]
    for a,b in itertools.permutations(xs,2):
        if a['fam']==b['fam'] or a['subj']==b['subj'] or a['domain']==b['domain']: continue
        pa,pb=a['p']-a[fld],b['p']-b[fld]
        if a[fld]>0 and b[fld]<0 and pa<pb-0.03 and a['p']>b['p']+0.03:
            add('trading',[a,b],min(a[fld],-b[fld])*a['Q']*b['Q']*(1.2 if fld=='w1' else 1),title='',prev=[pct(pa),pct(pb)],span=span,field=fld)
# ---------- the checklist: several outcomes of one question can all happen
for f,ms in fam.items():
    ms=sorted([q for q in ms if OKT(q) and not fe(q)],key=lambda q:-q['p'])
    if len(ms)<3 or sum(q['p'] for q in ms)<1.25 or max(q['recog'] for q in ms)<2: continue
    t,names=frame([q['plain'] for q in ms])
    if len(t.replace('____','').split())<2 or not all(names): continue
    add('checklist',ms[:5],st.mean(q['Q'] for q in ms[:5])*(1+0.1*len(ms[:5]))*(0.6+(ms[0]['p']-ms[-1]['p'])),title=t,names=names[:5])
# ---------- same odds
BANDS=((0.10,'About 1 in 10'),(0.15,'About 1 in 7'),(0.20,'About 1 in 5'),(0.40,'About 2 in 5'),(0.50,'A coin flip'),(0.60,'About 3 in 5'),(0.75,'About 3 in 4'),(0.80,'About 4 in 5'),(0.90,'About 9 in 10'))
shown=set()
for c in json.load(open('../v3/final3.json')):
    if c['type']=='band': shown|={key(T3[i]) for i in c['ids']}
for cc,name in BANDS:
    pool=sorted([q for q in EB if abs(q['p']-cc)<=0.016 and q['appeal']>=2 and key(q) not in shown and (q['kind']!='date' or q['days']>20)],key=lambda q:-q['Q']); out=[]
    for q in pool:
        if any(q['subj']==o['subj'] or q['fam']==o['fam'] for o in out) or sum(1 for o in out if o['domain']==q['domain'])>=2: continue
        out.append(q)
        if len(out)==4: break
    if len(out)==4 and len({o['domain'] for o in out})>=3: add('band',sorted(out,key=lambda q:-q['p']),st.mean(q['Q'] for q in out),title=name)
bt=collections.defaultdict(list)
for c in C: bt[c['type']].append(c)
for t,l in bt.items():
    l.sort(key=lambda c:-c['score'])
    for r,c in enumerate(l): c['rank']=r+1
    print('=====',t,len(l))
    for c in l[:8]: print('  %.3f %s | %s | %s'%(c['score'],c['title'],c.get('tag') or '',' / '.join('%d %s'%(R[i]['pp'],R[i]['plain'][:34]) for i in c['ids'])),c.get('prev') or '',c.get('names') or '')
json.dump(C,open('cands5m.json','w'))

print(dict(STAT))
