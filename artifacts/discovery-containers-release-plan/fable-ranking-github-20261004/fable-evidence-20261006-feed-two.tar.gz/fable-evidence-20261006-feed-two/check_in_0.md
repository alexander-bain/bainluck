
## y00 — type: roundup — headline: Division Series: who is likely to advance — tag: MLB playoffs
- id s3 | 86% | kind named | deadline 2026-10-31 | venue K | shown as: was 52% yesterday | row name: White Sox over the Guardians
  SENTENCE: The Chicago White Sox win their 2026 American League Division Series against the Cleveland Guardians
  VENUE WORDING: Series Winner: Chicago WS vs Cleveland — Chicago WS
  RULES EXCERPT: If Chicago WS wins the Chicago WS vs Cleveland Division Series in the 2026 Pro Baseball Playoffs, then the market resolves to Yes.
- id s1 | 84% | kind named | deadline 2026-10-31 | venue K | shown as: was 64% yesterday | row name: Rays over the Yankees
  SENTENCE: The Tampa Bay Rays win their 2026 American League Division Series against the New York Yankees
  VENUE WORDING: Series Winner: New York Y vs Tampa Bay — Tampa Bay
  RULES EXCERPT: If Tampa Bay wins the New York Y vs Tampa Bay Division Series in the 2026 Pro Baseball Playoffs, then the market resolves to Yes.
- id s0 | 88% | kind named | deadline 2026-11-01 | venue K | shown as: was 89% yesterday | row name: Brewers over the Padres
  SENTENCE: The Milwaukee Brewers win their 2026 National League Division Series against the San Diego Padres
  VENUE WORDING: Series Winner: San Diego vs Milwaukee — Milwaukee
  RULES EXCERPT: If Milwaukee wins the San Diego vs Milwaukee Division Series in the 2026 Pro Baseball Playoffs, then the market resolves to Yes.
- id s2 | 61% | kind named | deadline 2026-10-31 | venue K | shown as: was 61% yesterday | row name: Dodgers over the Braves
  SENTENCE: The Los Angeles Dodgers win their 2026 National League Division Series against the Atlanta Braves
  VENUE WORDING: Series Winner: Atlanta vs Los Angeles D — Los Angeles D
  RULES EXCERPT: If Los Angeles D wins the Atlanta vs Los Angeles D Division Series in the 2026 Pro Baseball Playoffs, then the market resolves to Yes.

## y01 — type: roundup — headline: The closest Senate races — tag: Midterms
- id t0488 | 64% | kind named | deadline 2027-11-03 | venue K/P | row name: Kansas: Republican
  SENTENCE: A Republican is sworn in as US Senator from Kansas for the term starting in 2027
  VENUE WORDING: Kansas Senate winner? — Roger Marshall
  RULES EXCERPT: If a representative of the Republican party is sworn in as a Senator of Kansas for the term beginning in 2027, then the market resolves to Yes.
- id t0469 | 62% | kind named | deadline 2027-11-03 | venue K/P | row name: Ohio: Democrat
  SENTENCE: A Democrat is sworn in as US Senator from Ohio for the term starting in 2027
  VENUE WORDING: Ohio Senate winner? — Sherrod Brown
  RULES EXCERPT: If a representative of the Democratic party is sworn in as a Senator of Ohio for the term beginning in 2027, then the market resolves to Yes.
- id t0485 | 58% | kind named | deadline 2027-11-03 | venue K/P | row name: Maine: Democrat
  SENTENCE: A Democrat is sworn in as US Senator from Maine for the term starting in 2027
  VENUE WORDING: Maine Senate winner? — Troy Jackson
  RULES EXCERPT: If a representative of the Democratic party is sworn in as a Senator of Maine for the term beginning in 2027, then the market resolves to Yes.
- id t0492 | 56% | kind named | deadline 2027-11-03 | venue K/P | row name: Iowa: Republican
  SENTENCE: A Republican is sworn in as US Senator from Iowa for the term starting in 2027
  VENUE WORDING: Iowa Senate winner? — Ashley Hinson
  RULES EXCERPT: If a representative of the Republican party is sworn in as a Senator of Iowa for the term beginning in 2027, then the market resolves to Yes.

## y02 — type: roundup — headline: Oscar front-runners — tag: Oscars 2027
- id t0136 | 52% | kind named | deadline 2027-12-31 | venue K | row name: Best Picture: The Odyssey
  SENTENCE: Christopher Nolan's The Odyssey wins Best Picture at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Picture — The Odyssey
  RULES EXCERPT: If The Odyssey has won Best Picture at the 99th Academy Awards, then the market resolves to Yes.
- id t0140 | 67% | kind named | deadline 2027-12-31 | venue K | row name: Best Director: Christopher Nolan
  SENTENCE: Christopher Nolan wins Best Director at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Director — Christopher Nolan
  RULES EXCERPT: If Christopher Nolan has won Best Director at the 99th Academy Awards, then the market resolves to Yes.
- id t0144 | 40% | kind named | deadline 2027-12-31 | venue K | row name: Best Actor: John Malkovich
  SENTENCE: John Malkovich wins Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Actor — John Malkovich
  RULES EXCERPT: If John Malkovich has won Best Actor at the 99th Academy Awards, then the market resolves to Yes.
- id t0143 | 65% | kind named | deadline 2027-12-31 | venue K | row name: Best Actress: Julianne Moore
  SENTENCE: Julianne Moore wins Best Actress at the 2027 Oscars
  VENUE WORDING: Oscar winner: Best Actress — Julianne Moore
  RULES EXCERPT: If Julianne Moore has won Best Actress at the 99th Academy Awards, then the market resolves to Yes.
- id t0134 | 53% | kind named | deadline 2027-12-31 | venue K | row name: Best Supporting Actress: Anne Hathaway
  SENTENCE: Anne Hathaway wins Best Supporting Actress at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Supporting Actress — Anne Hathaway
  RULES EXCERPT: If Anne Hathaway has won Best Supporting Actress at the 99th Academy Awards, then the market resolves to Yes.

## y03 — type: roundup — headline: The Fed's next meetings: the likeliest decision — tag: Interest rates
- id t0866 | 84% | kind named | deadline 2026-10-28 | venue K | row name: October 2026: no change
  SENTENCE: The Federal Reserve leaves interest rates unchanged at its October 28, 2026 meeting
  VENUE WORDING: Fed decision in Oct 2026? — Fed maintains rate
  RULES EXCERPT: If the Federal Reserve does a Hike of 0bps on October 28, 2026, then the market resolves to Yes.
- id t0791 | 72% | kind named | deadline 2026-12-09 | venue K | row name: December 2026: a rate rise
  SENTENCE: The Federal Reserve raises interest rates by a quarter point on December 9, 2026
  VENUE WORDING: Fed decision in Dec 2026? — Hike 25bps
  RULES EXCERPT: If the Federal Reserve does a Hike of 25bps on December 09, 2026, then the market resolves to Yes.
- id t0328 | 63% | kind named | deadline 2027-01-27 | venue K | row name: January 2027: no change
  SENTENCE: The Federal Reserve leaves interest rates unchanged at its January 27, 2027 meeting
  VENUE WORDING: Fed decision in Jan 2027? — Fed maintains rate
  RULES EXCERPT: If the Federal Reserve does a Hike of 0bps on January 27, 2027, then the market resolves to Yes.

## y04 — type: roundup — headline: NFL awards: the front-runners — tag: NFL
- id t0276 | 27% | kind named | deadline 2028-02-08 | venue K | row name: Defensive Player of the Year: Will Anderson Jr.
  SENTENCE: Will Anderson Jr. wins NFL Defensive Player of the Year for the 2026-27 season
  VENUE WORDING: Defensive Player of the Year Winner? — Will Anderson Jr.
  RULES EXCERPT: If Will Anderson Jr. wins the Pro Football AP Defensive Player Of The Year in the 2026-27 season, then the market resolves to Yes.
- id t0263 | 65% | kind named | deadline 2028-02-21 | venue K | row name: Comeback Player of the Year: Patrick Mahomes
  SENTENCE: Patrick Mahomes wins NFL Comeback Player of the Year for the 2026-27 season
  VENUE WORDING: Comeback Player of the Year Winner? — Patrick Mahomes
  RULES EXCERPT: If Patrick Mahomes wins the Pro Football AP Comeback Player of the Year in the 2026-27 season, then the market resolves to Yes.
- id t0251 | 32% | kind named | deadline 2028-02-28 | venue K | row name: Offensive Rookie of the Year: Jeremiyah Love
  SENTENCE: Jeremiyah Love wins NFL Offensive Rookie of the Year for the 2026-27 season
  VENUE WORDING: Offensive Rookie of the Year Winner? — Jeremiyah Love
  RULES EXCERPT: If Jeremiyah Love wins the Pro Football AP Offensive Rookie of the Year in the 2026-27 season, then the market resolves to Yes.
- id t0258 | 35% | kind named | deadline 2028-02-28 | venue K | row name: Defensive Rookie of the Year: Jacob Rodriguez
  SENTENCE: Jacob Rodriguez wins NFL Defensive Rookie of the Year for the 2026-27 season
  VENUE WORDING: Defensive Rookie of the Year Winner? — Jacob Rodriguez
  RULES EXCERPT: If Jacob Rodriguez wins the Pro Football AP Defensive Rookie of the Year in the 2026-27 season, then the market resolves to Yes.

## y05 — type: movers — headline: Moves this month
- id t0747 | 76% | kind named | deadline 2026-12-31 | venue K | shown as: was 35% a month ago
  SENTENCE: Tyreek Hill joins the Kansas City Chiefs as his next team before December 31, 2026
  VENUE WORDING: Tyreek Hill's Next Team — Kansas City
  RULES EXCERPT: If Tyreek Hill's next team is Kansas City before Dec 31, 2026, then the market resolves to Yes.
- id t0783 | 74% | kind named | deadline 2026-12-29 | venue K | shown as: was 36% a month ago
  SENTENCE: Alabama makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Alabama
  RULES EXCERPT: If Alabama is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.
- id t1381 | 81% | kind date | deadline 2026-12-31 | venue P | shown as: was 57% a month ago
  SENTENCE: Donald Trump meets Vladimir Putin in person by December 31, 2026
  VENUE WORDING: Trump meets with Putin by...? — December 31
  RULES EXCERPT: This market will resolve to "Yes" if Donald Trump meets with Vladimir Putin between market creation and the listed date, 11:59 PM ET. Otherwise, this market will resolve to "No".

A meeting is defined as any encounter where both Trump and Putin are present and interact with each other in person.

An

## y06 — type: movers — headline: Moves this week
- id t0116 | 80% | kind named | deadline 2028-12-31 | venue K | shown as: was 56% a week ago
  SENTENCE: Chuck Schumer wins the next election for Senate Democratic leader
  VENUE WORDING: Next Senate Democratic Leader? — Chuck Schumer
  RULES EXCERPT: If Chuck Schumer wins the next Senate Democratic Leader election, then the market resolves to Yes.
- id t0600 | 40% | kind date | deadline 2027-01-01 | venue K | shown as: was 22% a week ago
  SENTENCE: SpaceX's Starship launches from Florida before 2027
  VENUE WORDING: When will SpaceX's Starship launch from Florida? — Before 2027
  RULES EXCERPT: If the SpaceX Starship has launched from Florida before Jan 1, 2027, then the market resolves to Yes.
- id t0342 | 57% | kind named | deadline 2027-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Robert Pattinson is nominated for Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar nominees: Best Actor — Robert Pattinson
  RULES EXCERPT: If Robert Pattinson has been nominated for Best Actor at the 99th Academy Awards, then the market resolves to Yes.

## y07 — type: movers — headline: Moves this month — tag: Tech and business
- id t0556 | 16% | kind named | deadline 2027-01-01 | venue K | shown as: was 38% a month ago
  SENTENCE: OpenAI has a number-one ranked AI model at some point before 2027
  VENUE WORDING: Which companies will have a top-ranked AI model this year? — OpenAI
  RULES EXCERPT: If OpenAI has a #1 ranked AI model before Jan 1, 2027, then the market resolves to Yes.
- id t1542 | 18% | kind date | deadline 2026-12-01 | venue P | shown as: was 1% a month ago
  SENTENCE: Anthropic's shares begin trading on a public stock exchange in December 2026
  VENUE WORDING: In which month will Anthropic IPO? — December 2026
  RULES EXCERPT: This market will resolve based on the calendar month (ET) in which Anthropic's initial public offering (IPO) occurs. The resolving month will be the calendar month (ET) containing the first day on which Anthropic shares are listed and open for regular-way trading on a public securities exchange.

An
- id t0615 | 8% | kind named | deadline 2027-01-01 | venue K | shown as: was 23% a month ago
  SENTENCE: Elon Musk is confirmed as the next CEO of X, formerly Twitter, before 2027
  VENUE WORDING: Who will be the next CEO of X? — Elon Musk
  RULES EXCERPT: If Elon Musk is confirmed as CEO for X before Jan 1, 2027, then the market resolves to Yes.

## y08 — type: movers — headline: Moves this week — tag: Tech and business
- id t0649 | 71% | kind date | deadline 2026-10-16 | venue K | shown as: was 58% a week ago
  SENTENCE: Google releases Gemini 4 before October 16, 2026
  VENUE WORDING: When will Google release Gemini 4? — Before Oct 16, 2026
  RULES EXCERPT: If Google releases Gemini 4 before Oct 16, 2026, then the market resolves to Yes.
- id t0883 | 20% | kind date | deadline 2027-01-01 | venue K | shown as: was 8% a week ago
  SENTENCE: Jerome Powell announces he is leaving the Federal Reserve Board, or leaves it, before 2027
  VENUE WORDING: Jerome Powell departure as Fed Governor announced? — Before Jan 1, 2027
  RULES EXCERPT: If Jerome Powell has either officially announced their intention to leave as member of the Board of Governors of the Federal Reserve System or has actually left as member of the Board of Governors of the Federal Reserve System before Jan 1, 2027, then the market resolves to Yes.
- id t0830 | 6% | kind binary | deadline 2026-11-03 | venue K | shown as: was 16% a week ago
  SENTENCE: A US ban on diesel exports takes effect before November 3, 2026
  VENUE WORDING: Will the US ban diesel exports before Election Day?
  RULES EXCERPT: If the United States has imposed a ban on exports of diesel that has gone into effect after Issuance and before Nov 3, 2026, then the market resolves to Yes.

## y09 — type: movers — headline: Moves since yesterday — tag: Culture and sport
- id t0376 | 25% | kind named | deadline 2027-01-25 | venue K | shown as: was 39% yesterday
  SENTENCE: The New Orleans Saints win the NFC South division in the 2026 NFL season
  VENUE WORDING: NFC South Division Winner — New Orleans
  RULES EXCERPT: If New Orleans wins the Pro Football NFC South Division, then the market resolves to Yes.
- id t0857 | 6% | kind named | deadline 2028-10-31 | venue K/P | shown as: was 19% yesterday
  SENTENCE: The Cleveland Guardians win the 2026 American League title and advance to the World Series
  VENUE WORDING: American League Champion — Cleveland
  RULES EXCERPT: If Cleveland win the 2026 Pro Baseball American League Championship, then the market resolves to Yes.
- id t0287 | 40% | kind named | deadline 2027-02-15 | venue K | shown as: was 45% yesterday
  SENTENCE: Jay-Z is announced to headline the February 2027 Super Bowl halftime show
  VENUE WORDING: Pro Football Championship Halftime Show: Headliner(s) — JAY-Z
  RULES EXCERPT: If JAY-Z is announced to headline the Pro Football Championship Halftime Show before Feb 15, 2027, then the market resolves to Yes.
- id t1278 | 6% | kind named | deadline 2027-02-15 | venue P | shown as: was 12% yesterday
  SENTENCE: Lamar Jackson wins the NFL Most Valuable Player award for the 2026 season
  VENUE WORDING: Pro Football: 2026 MVP Winner — Lamar Jackson
  RULES EXCERPT: This market will resolve to the player who wins the 2026 NFL Most Valuable Player award for the 2026-27 NFL season.

In the event of a tie, this market will resolve according to the official winner as determined by NFL rules. If multiple winners are announced then this market will resolve to the pla

## y10 — type: newfav — headline: ____ has 2026's second-biggest opening weekend at the US and Canada box office
- id t1478 | 62% | kind named | deadline 2027-01-01 | venue P | shown as: was 44% a month ago | row name: Avengers: Doomsday
  SENTENCE: Avengers: Doomsday has 2026's second-biggest opening weekend at the US and Canada box office
  VENUE WORDING: Which movie has 2nd biggest opening weekend in 2026? — Avengers: Doomsday
  RULES EXCERPT: This market will resolve according to the title of the movie which grosses the second-most domestically on its opening weekend among all movies in 2026. The "Weekend Box Office Performance" table on the page for the relevant movie on https://www.the-numbers.com/movies/year/2026 will be used to resol
- id t1477 | 39% | kind named | deadline 2027-01-01 | venue P | shown as: was 54% a month ago | row name: Spider-Man: Brand New Day
  SENTENCE: Spider-Man: Brand New Day has 2026's second-biggest opening weekend at the US and Canada box office
  VENUE WORDING: Which movie has 2nd biggest opening weekend in 2026? — Spider-Man: Brand New Day
  RULES EXCERPT: This market will resolve according to the title of the movie which grosses the second-most domestically on its opening weekend among all movies in 2026. The "Weekend Box Office Performance" table on the page for the relevant movie on https://www.the-numbers.com/movies/year/2026 will be used to resol

## y11 — type: newfav — headline: A ____ is inaugurated as Nevada's governor following the 2026 election
- id t0558 | 53% | kind named | deadline 2027-11-03 | venue K/P | shown as: was 40% a month ago | row name: Democrat
  SENTENCE: A Democrat is inaugurated as Nevada's governor following the 2026 election
  VENUE WORDING: Nevada Governor winner? — Aaron Ford
  RULES EXCERPT: If a representative of the Democratic party is inaugurated as the governor of Nevada pursuant to the 2026 election, then the market resolves to Yes.
- id t0559 | 47% | kind named | deadline 2027-11-03 | venue K/P | shown as: was 61% a month ago | row name: Republican
  SENTENCE: A Republican is inaugurated as Nevada's governor following the 2026 election
  VENUE WORDING: Nevada Governor winner? — Joe Lombardo
  RULES EXCERPT: If a representative of the Republican party is inaugurated as the governor of Nevada pursuant to the 2026 election, then the market resolves to Yes.

## y12 — type: newfav — headline: ____ and JD Vance are the Democratic and Republican nominees for president in 2028
- id t0099 | 16% | kind named | deadline 2028-11-07 | venue K | shown as: was 9% a month ago | row name: Gavin Newsom
  SENTENCE: Gavin Newsom and JD Vance are the Democratic and Republican nominees for president in 2028
  VENUE WORDING: 2028 Presidential matchup — Gavin Newsom v. JD Vance
  RULES EXCERPT: If Gavin Newsom (D) and JD Vance (R) are the nominees for the 2028 presidential election, then the market resolves to Yes.
- id t0100 | 10% | kind named | deadline 2028-11-07 | venue K | shown as: was 14% a month ago | row name: Alexandria Ocasio-Cortez
  SENTENCE: Alexandria Ocasio-Cortez and JD Vance are the Democratic and Republican nominees for president in 2028
  VENUE WORDING: 2028 Presidential matchup — AOC v. JD Vance
  RULES EXCERPT: If Alexandria Ocasio-Cortez (D) and JD Vance (R) are the nominees for the 2028 presidential election, then the market resolves to Yes.
