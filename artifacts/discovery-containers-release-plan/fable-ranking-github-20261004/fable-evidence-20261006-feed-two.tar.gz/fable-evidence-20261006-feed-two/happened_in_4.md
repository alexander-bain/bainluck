# Claims to check. Today is Tuesday, October 6, 2026.

- id t0068 | shown at 12% | venue deadline 2029-01-20
  SENTENCE: The United States purchases at least part of Greenland from Denmark before January 20, 2029
  VENUE WORDING: Will Trump buy at least part of Greenland? — Before January 20, 2029
  RULES EXCERPT: If the United States purchases at least part of Greenland from Denmark before January 20, 2029, then the market resolves to Yes.

- id t1549 | shown at 60% | venue deadline 2026-10-31
  SENTENCE: Official representatives of Russia and Ukraine hold a diplomatic meeting by October 31, 2026
  VENUE WORDING: Russia x Ukraine any diplomatic meeting by...? — October 31
  RULES EXCERPT: This market will resolve to "Yes" if there is a diplomatic meeting between representatives of Russia and Ukraine by the listed date, 11:59 PM ET. Otherwise, this market will resolve to “No”.

A diplomatic meeting refers to a deliberate meeting between representatives of the listed countries who are 

- id t0903 | shown at 50% | venue deadline 2026-11-01
  SENTENCE: A new official GTA VI trailer, at least 30 seconds long, is released before November 2026
  VENUE WORDING: Grand Theft Auto VI: New trailer release date — Before November 2026
  RULES EXCERPT: If a new (at least 30 second) GTA VI trailer is publicly and officially released before Nov 1, 2026, then the market resolves to Yes.

- id t1539 | shown at 9% | venue deadline 2026-10-31
  SENTENCE: The US and Canada announce an official agreement to lower US tariffs on Canada by October 31, 2026
  VENUE WORDING: US-Canada diplomatic agreement to lower tariffs by...? — October 31
  RULES EXCERPT: This market will resolve to “Yes” if a diplomatic agreement between the United States and Canada to lower US tariffs on Canada is announced by October 31, 2026, 11:59 PM ET.

A diplomatic agreement to lower US tariffs on Canada refers to an official agreement, treaty, deal, or substantially similar 

- id t0412 | shown at 4% | venue deadline 2026-11-01
  SENTENCE: Kash Patel leaves his job as FBI Director before November 1, 2026
  VENUE WORDING: Kash Patel out as FBI Director? — Before Nov 1, 2026
  RULES EXCERPT: If Kash Patel leaves as FBI Director before Nov 1, 2026, then the market resolves to Yes.

- id t0033 | shown at 26% | venue deadline 2029-01-21
  SENTENCE: The United States gains control of any new territory outside its current sovereignty before January 21, 2029
  VENUE WORDING: Will the US acquire any new territory? — Before Jan 21, 2029
  RULES EXCERPT: If the United States gains control of any territory outside its sovereignty as of Issuance before Jan 21, 2029, then the market resolves to Yes.

- id t0670 | shown at 26% | venue deadline 2028-01-01
  SENTENCE: Legislation making Daylight Saving Time permanent becomes law before 2028
  VENUE WORDING: Will Daylight Saving Time become permanent? — Before Jan 1, 2028
  RULES EXCERPT: If legislation establishing permanent Daylight Saving Time has become law after Issuance and before Jan 1, 2028, then the market resolves to Yes.

- id t0015 | shown at 24% | venue deadline 2030-01-01
  SENTENCE: SpaceX successfully lands anything on Mars before 2030
  VENUE WORDING: Will SpaceX land anything successfully on Mars before 2030?
  RULES EXCERPT: If SpaceX lands anything on Mars before Jan 1, 2030, then the market resolves to Yes.

- id t0981 | shown at 35% | venue deadline 2028-11-08
  SENTENCE: The Republican candidate wins the 2028 US presidential election
  VENUE WORDING: Which party wins 2028 US Presidential Election? — Republican
  RULES EXCERPT: The 2028 United States presidential election will be held on Tuesday, November 7, 2028.

This market will resolve to the political party whose candidate is elected the next President of the United States in the 2028 election.

The resolution source for this market is the Associated Press, Fox News, 

- id t0082 | shown at 33% | venue deadline 2028-11-07
  SENTENCE: The 2028 Republican ticket is JD Vance for president and Marco Rubio for vice president
  VENUE WORDING: 2028 Republican Presidential ticket — JD Vance and Marco Rubio
  RULES EXCERPT: If the Republican presidential nominee is JD Vance AND the Republican vice presidential nominee is Marco Rubio in the 2028 presidential election, then the market resolves to Yes.

- id t0178 | shown at 32% | venue deadline 2028-06-30
  SENTENCE: Victor Wembanyama wins NBA Most Valuable Player for the 2026-27 season
  VENUE WORDING: Pro Basketball MVP Winner — Victor Wembanyama
  RULES EXCERPT: If Victor Wembanyama wins the Pro Basketball Most Valuable Player in the 2026-27 season, then the market resolves to Yes.

- id t0861 | shown at 28% | venue deadline 2028-10-31
  SENTENCE: The Los Angeles Dodgers win the 2026 World Series
  VENUE WORDING: Pro Baseball Champion — Los Angeles D
  RULES EXCERPT: If Los Angeles D wins the 2026 Pro Baseball Championship, then the market resolves to Yes.

- id t0200 | shown at 26% | venue deadline 2027-06-19
  SENTENCE: Barcelona wins the 2026-27 UEFA Champions League
  VENUE WORDING: Champions League Winner — Barcelona
  RULES EXCERPT: If Barcelona is the 2026-27 Champions League winner, then the market resolves to Yes.

- id t1218 | shown at 22% | venue deadline 2027-01-01
  SENTENCE: The Vancouver Whitecaps win the 2026 MLS Cup
  VENUE WORDING: MLS Cup Winner 2026 — Vancouver Whitecaps FC
  RULES EXCERPT: This market will resolve according to the team that wins the 2026 MLS Cup. 

If at any point it becomes impossible for a listed team to win the 2026 MLS Cup per the rules of MLS (e.g. they are mathematically eliminated), the corresponding market will resolve to “No”.

If the 2026 MLS season is cance
