# Claims to check. Today is Tuesday, October 6, 2026.

- id t0785 | shown at 47% | venue deadline 2026-12-29
  SENTENCE: Utah makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Utah
  RULES EXCERPT: If Utah is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.

- id t0782 | shown at 46% | venue deadline 2026-12-29
  SENTENCE: LSU makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — LSU
  RULES EXCERPT: If LSU is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.

- id t0784 | shown at 36% | venue deadline 2026-12-29
  SENTENCE: Ole Miss makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Ole Miss
  RULES EXCERPT: If Ole Miss is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.

- id t0952 | shown at 12% | venue deadline 2027-01-01
  SENTENCE: OpenAI announces that it has achieved artificial general intelligence (AGI) by the end of 2026
  VENUE WORDING: When will OpenAI achieve AGI? — Before 2027
  RULES EXCERPT: If OpenAI announces that they have attained AGI by Dec 31, 2026, then the market resolves to Yes.

- id t0953 | shown at 45% | venue deadline 2028-01-01
  SENTENCE: OpenAI announces that it has achieved artificial general intelligence (AGI) by the end of 2027
  VENUE WORDING: When will OpenAI achieve AGI? — Before 2028
  RULES EXCERPT: If OpenAI announces that they have attained AGI by Dec 31, 2027, then the market resolves to Yes.

- id t0954 | shown at 65% | venue deadline 2030-01-01
  SENTENCE: OpenAI announces that it has achieved artificial general intelligence (AGI) by the end of 2029
  VENUE WORDING: When will OpenAI achieve AGI? — Before 2030
  RULES EXCERPT: If OpenAI announces that they have attained AGI by Dec 31, 2029, then the market resolves to Yes.

- id t0055 | shown at 42% | venue deadline 2029-01-20
  SENTENCE: Zelenskyy and Putin meet before January 20, 2029
  VENUE WORDING: Will Zelenskyy and Putin speak? — Before Jan 20, 2029
  RULES EXCERPT: If Volodymyr Zelenskyy and Vladimir Putin  meet before Jan 20, 2029, then the market resolves to Yes.

- id t0052 | shown at 23% | venue deadline 2029-01-21
  SENTENCE: The United States acquires any part of Greenland before January 21, 2029
  VENUE WORDING: Will the US take control of any part of Greenland? — Before January 21, 2029
  RULES EXCERPT: If the United States acquires any part of Greenland before Jan 21, 2029, then the market resolves to Yes.

- id t0034 | shown at 18% | venue deadline 2029-01-21
  SENTENCE: Donald Trump resigns as president before his term ends in January 2029
  VENUE WORDING: Will Trump resign during his term?
  RULES EXCERPT: If the President of the United States elected for the 2025-2029 term resigns the office, then the market resolves to Yes.

- id t0053 | shown at 11% | venue deadline 2029-01-21
  SENTENCE: The United States acquires any part of Canada before January 21, 2029
  VENUE WORDING: Will the US take control of any part of Canada?
  RULES EXCERPT: If the United States acquires any part of Canada before Jan 21, 2029, then the market resolves to Yes.

- id t0069 | shown at 5% | venue deadline 2029-01-20
  SENTENCE: A bill abolishing the Federal Reserve and its reserve banks becomes law before January 20, 2029
  VENUE WORDING: Will Trump end the Federal Reserve?
  RULES EXCERPT: If a bill has become law which has abolished or dissolved the Federal Reserve Board of Governors and its constituent reserve banks before January 20, 2029, then the market resolves to Yes.

- id t1538 | shown at 39% | venue deadline 2026-12-31
  SENTENCE: The US and Canada announce an official agreement to lower US tariffs on Canada by December 31, 2026
  VENUE WORDING: US-Canada diplomatic agreement to lower tariffs by...? — December 31
  RULES EXCERPT: This market will resolve to “Yes” if a diplomatic agreement between the United States and Canada to lower US tariffs on Canada is announced by December 31, 2026, 11:59 PM ET.

A diplomatic agreement to lower US tariffs on Canada refers to an official agreement, treaty, deal, or substantially similar

- id t0913 | shown at 12% | venue deadline 2027-01-01
  SENTENCE: The Senate confirms a new Supreme Court justice by December 31, 2026
  VENUE WORDING: New Supreme Court justice confirmed? — Before 2027
  RULES EXCERPT: If the Senate confirms a new justice to the Supreme Court between Issuance and December 31, 2026, then the market resolves to Yes.

- id t1110 | shown at 7% | venue deadline 2027-01-01
  SENTENCE: Trump, Putin and Zelensky are photographed or filmed together in the same frame before 2027
  VENUE WORDING: Trump, Putin, and Zelensky seen together before 2027?
  RULES EXCERPT: This market will resolve to "Yes" if Donald Trump, Vladimir Putin, and Volodymyr Zelensky are photographed or videotaped together, in the same frame, between this market's creation and December 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No".

For this market to resolve to "Yes," 
