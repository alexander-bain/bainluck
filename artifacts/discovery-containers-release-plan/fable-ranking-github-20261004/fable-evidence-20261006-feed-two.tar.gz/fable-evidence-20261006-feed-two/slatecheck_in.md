# Cards that may be shown together in one feed

## y00 — type: roundup — headline: Division Series: who is likely to advance — tag: MLB playoffs
- id s3 | 86% | kind named | deadline 2026-10-31 | venue K | shown as: was 52% yesterday | row name: White Sox over the Guardians
  SENTENCE: The Chicago White Sox win their 2026 American League Division Series against the Cleveland Guardians
  VENUE WORDING: Series Winner: Chicago WS vs Cleveland — Chicago WS
- id s1 | 84% | kind named | deadline 2026-10-31 | venue K | shown as: was 64% yesterday | row name: Rays over the Yankees
  SENTENCE: The Tampa Bay Rays win their 2026 American League Division Series against the New York Yankees
  VENUE WORDING: Series Winner: New York Y vs Tampa Bay — Tampa Bay
- id s0 | 88% | kind named | deadline 2026-11-01 | venue K | shown as: was 89% yesterday | row name: Brewers over the Padres
  SENTENCE: The Milwaukee Brewers win their 2026 National League Division Series against the San Diego Padres
  VENUE WORDING: Series Winner: San Diego vs Milwaukee — Milwaukee
- id s2 | 61% | kind named | deadline 2026-10-31 | venue K | shown as: was 61% yesterday | row name: Dodgers over the Braves
  SENTENCE: The Los Angeles Dodgers win their 2026 National League Division Series against the Atlanta Braves
  VENUE WORDING: Series Winner: Atlanta vs Los Angeles D — Los Angeles D

## y01 — type: roundup — headline: The closest Senate races — tag: Midterms
- id t0488 | 64% | kind named | deadline 2027-11-03 | venue K/P | row name: Kansas: Republican
  SENTENCE: A Republican is sworn in as US Senator from Kansas for the term starting in 2027
  VENUE WORDING: Kansas Senate winner? — Roger Marshall
- id t0469 | 62% | kind named | deadline 2027-11-03 | venue K/P | row name: Ohio: Democrat
  SENTENCE: A Democrat is sworn in as US Senator from Ohio for the term starting in 2027
  VENUE WORDING: Ohio Senate winner? — Sherrod Brown
- id t0485 | 58% | kind named | deadline 2027-11-03 | venue K/P | row name: Maine: Democrat
  SENTENCE: A Democrat is sworn in as US Senator from Maine for the term starting in 2027
  VENUE WORDING: Maine Senate winner? — Troy Jackson
- id t0492 | 56% | kind named | deadline 2027-11-03 | venue K/P | row name: Iowa: Republican
  SENTENCE: A Republican is sworn in as US Senator from Iowa for the term starting in 2027
  VENUE WORDING: Iowa Senate winner? — Ashley Hinson

## y02 — type: roundup — headline: Oscar front-runners — tag: Oscars 2027
- id t0136 | 52% | kind named | deadline 2027-12-31 | venue K | row name: Best Picture: The Odyssey
  SENTENCE: Christopher Nolan's The Odyssey wins Best Picture at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Picture — The Odyssey
- id t0140 | 67% | kind named | deadline 2027-12-31 | venue K | row name: Best Director: Christopher Nolan
  SENTENCE: Christopher Nolan wins Best Director at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Director — Christopher Nolan
- id t0144 | 40% | kind named | deadline 2027-12-31 | venue K | row name: Best Actor: John Malkovich
  SENTENCE: John Malkovich wins Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Actor — John Malkovich
- id t0143 | 65% | kind named | deadline 2027-12-31 | venue K | row name: Best Actress: Julianne Moore
  SENTENCE: Julianne Moore wins Best Actress at the 2027 Oscars
  VENUE WORDING: Oscar winner: Best Actress — Julianne Moore
- id t0134 | 53% | kind named | deadline 2027-12-31 | venue K | row name: Best Supporting Actress: Anne Hathaway
  SENTENCE: Anne Hathaway wins Best Supporting Actress at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Supporting Actress — Anne Hathaway

## y03 — type: roundup — headline: The Fed's next meetings: the likeliest decision — tag: Interest rates
- id t0866 | 84% | kind named | deadline 2026-10-28 | venue K | row name: October 2026: no change
  SENTENCE: The Federal Reserve leaves interest rates unchanged at its October 28, 2026 meeting
  VENUE WORDING: Fed decision in Oct 2026? — Fed maintains rate
- id t0791 | 72% | kind named | deadline 2026-12-09 | venue K | row name: December 2026: a rate rise
  SENTENCE: The Federal Reserve raises interest rates by a quarter point on December 9, 2026
  VENUE WORDING: Fed decision in Dec 2026? — Hike 25bps
- id t0328 | 63% | kind named | deadline 2027-01-27 | venue K | row name: January 2027: no change
  SENTENCE: The Federal Reserve leaves interest rates unchanged at its January 27, 2027 meeting
  VENUE WORDING: Fed decision in Jan 2027? — Fed maintains rate

## y04 — type: roundup — headline: NFL awards: the front-runners — tag: NFL
- id t0276 | 27% | kind named | deadline 2028-02-08 | venue K | row name: Defensive Player of the Year: Will Anderson Jr.
  SENTENCE: Will Anderson Jr. wins NFL Defensive Player of the Year for the 2026-27 season
  VENUE WORDING: Defensive Player of the Year Winner? — Will Anderson Jr.
- id t0263 | 65% | kind named | deadline 2028-02-21 | venue K | row name: Comeback Player of the Year: Patrick Mahomes
  SENTENCE: Patrick Mahomes wins NFL Comeback Player of the Year for the 2026-27 season
  VENUE WORDING: Comeback Player of the Year Winner? — Patrick Mahomes
- id t0251 | 32% | kind named | deadline 2028-02-28 | venue K | row name: Offensive Rookie of the Year: Jeremiyah Love
  SENTENCE: Jeremiyah Love wins NFL Offensive Rookie of the Year for the 2026-27 season
  VENUE WORDING: Offensive Rookie of the Year Winner? — Jeremiyah Love
- id t0258 | 35% | kind named | deadline 2028-02-28 | venue K | row name: Defensive Rookie of the Year: Jacob Rodriguez
  SENTENCE: Jacob Rodriguez wins NFL Defensive Rookie of the Year for the 2026-27 season
  VENUE WORDING: Defensive Rookie of the Year Winner? — Jacob Rodriguez

## y05 — type: movers — headline: Moves this month
- id t0747 | 76% | kind named | deadline 2026-12-31 | venue K | shown as: was 35% a month ago
  SENTENCE: Tyreek Hill joins the Kansas City Chiefs as his next team before December 31, 2026
  VENUE WORDING: Tyreek Hill's Next Team — Kansas City
- id t0783 | 74% | kind named | deadline 2026-12-29 | venue K | shown as: was 36% a month ago
  SENTENCE: Alabama makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Alabama
- id t1381 | 81% | kind date | deadline 2026-12-31 | venue P | shown as: was 57% a month ago
  SENTENCE: Donald Trump meets Vladimir Putin in person by December 31, 2026
  VENUE WORDING: Trump meets with Putin by...? — December 31

## y06 — type: movers — headline: Moves this week
- id t0116 | 80% | kind named | deadline 2028-12-31 | venue K | shown as: was 56% a week ago
  SENTENCE: Chuck Schumer wins the next election for Senate Democratic leader
  VENUE WORDING: Next Senate Democratic Leader? — Chuck Schumer
- id t0600 | 40% | kind date | deadline 2027-01-01 | venue K | shown as: was 22% a week ago
  SENTENCE: SpaceX's Starship launches from Florida before 2027
  VENUE WORDING: When will SpaceX's Starship launch from Florida? — Before 2027
- id t0342 | 57% | kind named | deadline 2027-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Robert Pattinson is nominated for Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar nominees: Best Actor — Robert Pattinson

## y07 — type: movers — headline: Moves this month — tag: Tech and business
- id t0556 | 16% | kind named | deadline 2027-01-01 | venue K | shown as: was 38% a month ago
  SENTENCE: OpenAI has a number-one ranked AI model at some point before 2027
  VENUE WORDING: Which companies will have a top-ranked AI model this year? — OpenAI
- id t1542 | 18% | kind date | deadline 2026-12-01 | venue P | shown as: was 1% a month ago
  SENTENCE: Anthropic's shares begin trading on a public stock exchange in December 2026
  VENUE WORDING: In which month will Anthropic IPO? — December 2026
- id t0615 | 8% | kind named | deadline 2027-01-01 | venue K | shown as: was 23% a month ago
  SENTENCE: Elon Musk is confirmed as the next CEO of X, formerly Twitter, before 2027
  VENUE WORDING: Who will be the next CEO of X? — Elon Musk

## y08 — type: movers — headline: Moves this week — tag: Tech and business
- id t0649 | 71% | kind date | deadline 2026-10-16 | venue K | shown as: was 58% a week ago
  SENTENCE: Google releases Gemini 4 before October 16, 2026
  VENUE WORDING: When will Google release Gemini 4? — Before Oct 16, 2026
- id t0883 | 20% | kind date | deadline 2027-01-01 | venue K | shown as: was 8% a week ago
  SENTENCE: Jerome Powell announces he is leaving the Federal Reserve Board, or leaves it, before 2027
  VENUE WORDING: Jerome Powell departure as Fed Governor announced? — Before Jan 1, 2027
- id t0830 | 6% | kind binary | deadline 2026-11-03 | venue K | shown as: was 16% a week ago
  SENTENCE: A US ban on diesel exports takes effect before November 3, 2026
  VENUE WORDING: Will the US ban diesel exports before Election Day?

## y09 — type: movers — headline: Moves since yesterday — tag: Culture and sport
- id t0376 | 25% | kind named | deadline 2027-01-25 | venue K | shown as: was 39% yesterday
  SENTENCE: The New Orleans Saints win the NFC South division in the 2026 NFL season
  VENUE WORDING: NFC South Division Winner — New Orleans
- id t0857 | 6% | kind named | deadline 2028-10-31 | venue K/P | shown as: was 19% yesterday
  SENTENCE: The Cleveland Guardians win the 2026 American League title and advance to the World Series
  VENUE WORDING: American League Champion — Cleveland
- id t0287 | 40% | kind named | deadline 2027-02-15 | venue K | shown as: was 45% yesterday
  SENTENCE: Jay-Z is announced to headline the February 2027 Super Bowl halftime show
  VENUE WORDING: Pro Football Championship Halftime Show: Headliner(s) — JAY-Z
- id t1278 | 6% | kind named | deadline 2027-02-15 | venue P | shown as: was 12% yesterday
  SENTENCE: Lamar Jackson wins the NFL Most Valuable Player award for the 2026 season
  VENUE WORDING: Pro Football: 2026 MVP Winner — Lamar Jackson

## y10 — type: newfav — headline: ____ has 2026's second-biggest opening weekend at the US and Canada box office
- id t1478 | 62% | kind named | deadline 2027-01-01 | venue P | shown as: was 44% a month ago | row name: Avengers: Doomsday
  SENTENCE: Avengers: Doomsday has 2026's second-biggest opening weekend at the US and Canada box office
  VENUE WORDING: Which movie has 2nd biggest opening weekend in 2026? — Avengers: Doomsday
- id t1477 | 39% | kind named | deadline 2027-01-01 | venue P | shown as: was 54% a month ago | row name: Spider-Man: Brand New Day
  SENTENCE: Spider-Man: Brand New Day has 2026's second-biggest opening weekend at the US and Canada box office
  VENUE WORDING: Which movie has 2nd biggest opening weekend in 2026? — Spider-Man: Brand New Day

## y11 — type: newfav — headline: A ____ is inaugurated as Nevada's governor following the 2026 election
- id t0558 | 53% | kind named | deadline 2027-11-03 | venue K/P | shown as: was 40% a month ago | row name: Democrat
  SENTENCE: A Democrat is inaugurated as Nevada's governor following the 2026 election
  VENUE WORDING: Nevada Governor winner? — Aaron Ford
- id t0559 | 47% | kind named | deadline 2027-11-03 | venue K/P | shown as: was 61% a month ago | row name: Republican
  SENTENCE: A Republican is inaugurated as Nevada's governor following the 2026 election
  VENUE WORDING: Nevada Governor winner? — Joe Lombardo

## y12 — type: newfav — headline: ____ and JD Vance are the Democratic and Republican nominees for president in 2028
- id t0099 | 16% | kind named | deadline 2028-11-07 | venue K | shown as: was 9% a month ago | row name: Gavin Newsom
  SENTENCE: Gavin Newsom and JD Vance are the Democratic and Republican nominees for president in 2028
  VENUE WORDING: 2028 Presidential matchup — Gavin Newsom v. JD Vance
- id t0100 | 10% | kind named | deadline 2028-11-07 | venue K | shown as: was 14% a month ago | row name: Alexandria Ocasio-Cortez
  SENTENCE: Alexandria Ocasio-Cortez and JD Vance are the Democratic and Republican nominees for president in 2028
  VENUE WORDING: 2028 Presidential matchup — AOC v. JD Vance

## y13 — type: swing — headline: The ____ win the AFC West division in the 2026 NFL season
- id t0388 | 64% | kind named | deadline 2027-01-25 | venue K | shown as: was 34% a month ago | row name: Kansas City Chiefs
  SENTENCE: The Kansas City Chiefs win the AFC West division in the 2026 NFL season
  VENUE WORDING: AFC West Division Winner — Kansas City
- id t0389 | 24% | kind named | deadline 2027-01-25 | venue K | shown as: was 33% a month ago | row name: Denver Broncos
  SENTENCE: The Denver Broncos win the AFC West division in the 2026 NFL season
  VENUE WORDING: AFC West Division Winner — Denver

## y14 — type: swing — headline: ____ win control of the US House in the 2026 midterm elections
- id t0324 | 91% | kind named | deadline 2027-02-01 | venue K | shown as: was 85% a month ago | row name: Democrats
  SENTENCE: Democrats win control of the US House in the 2026 midterm elections
  VENUE WORDING: Which party will win the U.S. House? — Democratic Party
- id t0325 | 9% | kind named | deadline 2027-02-01 | venue K | shown as: was 17% a month ago | row name: Republicans
  SENTENCE: Republicans win control of the US House in the 2026 midterm elections
  VENUE WORDING: Which party will win the U.S. House? — Republican Party

## y15 — type: swing — headline: ____ wins Spain's LALIGA soccer title for the 2026-27 season
- id t1441 | 81% | kind named | deadline 2027-06-15 | venue P | shown as: was 67% a month ago | row name: Barcelona
  SENTENCE: Barcelona wins Spain's LALIGA soccer title for the 2026-27 season
  VENUE WORDING: LALIGA: 2027 Champion — Barcelona
- id t1442 | 17% | kind named | deadline 2027-06-15 | venue P | shown as: was 32% a month ago | row name: Real Madrid
  SENTENCE: Real Madrid wins Spain's LALIGA soccer title for the 2026-27 season
  VENUE WORDING: LALIGA: 2027 Champion — Real Madrid

## y16 — type: deadheat — headline: ____ win the NBA's Eastern Conference Finals in the 2026-27 season
- id t0197 | 24% | kind named | deadline 2029-06-29 | venue K | row name: The Philadelphia 76ers
  SENTENCE: The Philadelphia 76ers win the NBA's Eastern Conference Finals in the 2026-27 season
  VENUE WORDING: Pro Basketball Eastern Conference Champion — Philadelphia
- id t0196 | 21% | kind named | deadline 2029-06-29 | venue K | row name: The New York Knicks
  SENTENCE: The New York Knicks win the NBA's Eastern Conference Finals in the 2026-27 season
  VENUE WORDING: Pro Basketball Eastern Conference Champion — New York

## y17 — type: when — headline: Will Trump be impeached?
- id t0943 | 3% | kind date | deadline 2027-01-01 | venue K/P
  SENTENCE: President Trump is impeached by the House before 2027
  VENUE WORDING: Will Trump be impeached? — Before Jan 1, 2027
- id t0944 | 31% | kind date | deadline 2027-03-01 | venue K
  SENTENCE: President Trump is impeached by the House before March 1, 2027
  VENUE WORDING: Will Trump be impeached? — Before Mar 1, 2027
- id t0945 | 67% | kind date | deadline 2028-01-01 | venue K | marked: first date likelier than not
  SENTENCE: President Trump is impeached by the House before 2028
  VENUE WORDING: Will Trump be impeached? — Before Jan 1, 2028

## y18 — type: board — headline: Before Trump's term ends
- id t0916 | 39% | kind date | deadline 2029-01-21 | venue K
  SENTENCE: A ban on members of Congress trading stocks becomes law by January 20, 2029
  VENUE WORDING: Will members of Congress be banned from trading stocks? — Before Jan 21, 2029
- id t0077 | 34% | kind binary | deadline 2029-01-20 | venue K
  SENTENCE: Israel and Saudi Arabia normalize diplomatic relations before January 20, 2029
  VENUE WORDING: Will Israel and Saudi Arabia normalize relations during Trump's term?
- id t0695 | 23% | kind date | deadline 2029-01-20 | venue K
  SENTENCE: The US government definitively states that alien life or technology exists before January 20, 2029
  VENUE WORDING: Will the U.S. confirm that aliens exist? — Before Jan 20, 2029
- id t0068 | 12% | kind date | deadline 2029-01-20 | venue K
  SENTENCE: The United States purchases at least part of Greenland from Denmark before January 20, 2029
  VENUE WORDING: Will Trump buy at least part of Greenland? — Before January 20, 2029

## y19 — type: board — headline: By the end of October
- id t1549 | 60% | kind date | deadline 2026-10-31 | venue P
  SENTENCE: Official representatives of Russia and Ukraine hold a diplomatic meeting by October 31, 2026
  VENUE WORDING: Russia x Ukraine any diplomatic meeting by...? — October 31
- id t0903 | 50% | kind date | deadline 2026-11-01 | venue K
  SENTENCE: A new official GTA VI trailer, at least 30 seconds long, is released before November 2026
  VENUE WORDING: Grand Theft Auto VI: New trailer release date — Before November 2026
- id t1539 | 9% | kind date | deadline 2026-10-31 | venue P
  SENTENCE: The US and Canada announce an official agreement to lower US tariffs on Canada by October 31, 2026
  VENUE WORDING: US-Canada diplomatic agreement to lower tariffs by...? — October 31
- id t0412 | 4% | kind date | deadline 2026-11-01 | venue K
  SENTENCE: Kash Patel leaves his job as FBI Director before November 1, 2026
  VENUE WORDING: Kash Patel out as FBI Director? — Before Nov 1, 2026

## y20 — type: band — headline: About 1 in 4
- id t0033 | 26% | kind date | deadline 2029-01-21 | venue K
  SENTENCE: The United States gains control of any new territory outside its current sovereignty before January 21, 2029
  VENUE WORDING: Will the US acquire any new territory? — Before Jan 21, 2029
- id t0670 | 26% | kind date | deadline 2028-01-01 | venue K
  SENTENCE: Legislation making Daylight Saving Time permanent becomes law before 2028
  VENUE WORDING: Will Daylight Saving Time become permanent? — Before Jan 1, 2028
- id t0015 | 24% | kind binary | deadline 2030-01-01 | venue K
  SENTENCE: SpaceX successfully lands anything on Mars before 2030
  VENUE WORDING: Will SpaceX land anything successfully on Mars before 2030?

## y21 — type: band — headline: About 1 in 3
- id t0981 | 35% | kind named | deadline 2028-11-08 | venue P
  SENTENCE: The Republican candidate wins the 2028 US presidential election
  VENUE WORDING: Which party wins 2028 US Presidential Election? — Republican
- id t0082 | 33% | kind named | deadline 2028-11-07 | venue K
  SENTENCE: The 2028 Republican ticket is JD Vance for president and Marco Rubio for vice president
  VENUE WORDING: 2028 Republican Presidential ticket — JD Vance and Marco Rubio
- id t0178 | 32% | kind named | deadline 2028-06-30 | venue K
  SENTENCE: Victor Wembanyama wins NBA Most Valuable Player for the 2026-27 season
  VENUE WORDING: Pro Basketball MVP Winner — Victor Wembanyama

## y22 — type: roundup — headline: The favorite for each title — tag: Sports
- id t0861 | 28% | kind named | deadline 2028-10-31 | venue K | row name: World Series: Dodgers
  SENTENCE: The Los Angeles Dodgers win the 2026 World Series
  VENUE WORDING: Pro Baseball Champion — Los Angeles D
- id t0200 | 26% | kind named | deadline 2027-06-19 | venue K | row name: Champions League: Barcelona
  SENTENCE: Barcelona wins the 2026-27 UEFA Champions League
  VENUE WORDING: Champions League Winner — Barcelona
- id t1218 | 22% | kind named | deadline 2027-01-01 | venue P | row name: MLS Cup: Whitecaps
  SENTENCE: The Vancouver Whitecaps win the 2026 MLS Cup
  VENUE WORDING: MLS Cup Winner 2026 — Vancouver Whitecaps FC

## y23 — type: roundup — headline: The tightest NFL division races — tag: NFL
- id t0382 | 44% | kind named | deadline 2027-01-25 | venue K | row name: NFC East: Cowboys
  SENTENCE: The Dallas Cowboys win the NFC East division in the 2026 NFL season
  VENUE WORDING: NFC East Division Winner — Dallas
- id t0371 | 41% | kind named | deadline 2027-01-25 | venue K | row name: NFC West: 49ers
  SENTENCE: The San Francisco 49ers win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — San Francisco
- id t0380 | 38% | kind named | deadline 2027-01-25 | venue K | row name: NFC North: Vikings
  SENTENCE: The Minnesota Vikings win the NFC North division in the 2026 NFL season
  VENUE WORDING: NFC North Division Winner — Minnesota
- id t0374 | 35% | kind named | deadline 2027-01-25 | venue K | row name: NFC South: Falcons
  SENTENCE: The Atlanta Falcons win the NFC South division in the 2026 NFL season
  VENUE WORDING: NFC South Division Winner — Atlanta

## y24 — type: movers — headline: Moves this month — tag: Culture and sport
- id t0747 | 76% | kind named | deadline 2026-12-31 | venue K | shown as: was 35% a month ago
  SENTENCE: Tyreek Hill joins the Kansas City Chiefs as his next team before December 31, 2026
  VENUE WORDING: Tyreek Hill's Next Team — Kansas City
- id t0783 | 74% | kind named | deadline 2026-12-29 | venue K | shown as: was 36% a month ago
  SENTENCE: Alabama makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Alabama
- id t0198 | 30% | kind named | deadline 2027-06-21 | venue K | shown as: was 4% a month ago
  SENTENCE: Manchester City is relegated from England's Premier League in the 2026-27 season
  VENUE WORDING: EPL Relegation — Manchester City
- id t0740 | 8% | kind named | deadline 2027-01-01 | venue K | shown as: was 26% a month ago
  SENTENCE: Bad Bunny is named People magazine's Sexiest Man Alive for 2026
  VENUE WORDING: People's Sexiest Man Alive for 2026 — Bad Bunny

## y25 — type: movers — headline: Climbers this week
- id t0747 | 76% | kind named | deadline 2026-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Tyreek Hill joins the Kansas City Chiefs as his next team before December 31, 2026
  VENUE WORDING: Tyreek Hill's Next Team — Kansas City
- id t0116 | 80% | kind named | deadline 2028-12-31 | venue K | shown as: was 56% a week ago
  SENTENCE: Chuck Schumer wins the next election for Senate Democratic leader
  VENUE WORDING: Next Senate Democratic Leader? — Chuck Schumer
- id t0600 | 40% | kind date | deadline 2027-01-01 | venue K | shown as: was 22% a week ago
  SENTENCE: SpaceX's Starship launches from Florida before 2027
  VENUE WORDING: When will SpaceX's Starship launch from Florida? — Before 2027
- id t0342 | 57% | kind named | deadline 2027-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Robert Pattinson is nominated for Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar nominees: Best Actor — Robert Pattinson

## y26 — type: movers — headline: Moves this week — tag: Culture and sport
- id t0747 | 76% | kind named | deadline 2026-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Tyreek Hill joins the Kansas City Chiefs as his next team before December 31, 2026
  VENUE WORDING: Tyreek Hill's Next Team — Kansas City
- id t0859 | 33% | kind named | deadline 2028-10-31 | venue K | shown as: was 11% a week ago
  SENTENCE: The Chicago White Sox win the 2026 American League title and advance to the World Series
  VENUE WORDING: American League Champion — Chicago WS
- id t0783 | 74% | kind named | deadline 2026-12-29 | venue K | shown as: was 55% a week ago
  SENTENCE: Alabama makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Alabama
- id t0342 | 57% | kind named | deadline 2027-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Robert Pattinson is nominated for Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar nominees: Best Actor — Robert Pattinson

## y27 — type: movers — headline: Moves this month — tag: Washington
- id t0116 | 80% | kind named | deadline 2028-12-31 | venue K | shown as: was 51% a month ago
  SENTENCE: Chuck Schumer wins the next election for Senate Democratic leader
  VENUE WORDING: Next Senate Democratic Leader? — Chuck Schumer
- id t0897 | 42% | kind named | deadline 2027-06-02 | venue K | shown as: was 65% a month ago
  SENTENCE: Karen Bass wins the 2026 Los Angeles mayoral election
  VENUE WORDING: Los Angeles Mayor winner? — Karen Bass
- id t0488 | 64% | kind named | deadline 2027-11-03 | venue K/P | shown as: was 83% a month ago
  SENTENCE: A Republican is sworn in as US Senator from Kansas for the term starting in 2027
  VENUE WORDING: Kansas Senate winner? — Roger Marshall
- id t0884 | 46% | kind named | deadline 2027-07-07 | venue K | shown as: was 31% a month ago
  SENTENCE: Susan Collins wins the 2026 US Senate election in Maine
  VENUE WORDING: Maine Senate winner? (Person) — Susan Collins

## y28 — type: movers — headline: Moves this week — tag: Washington
- id t0116 | 80% | kind named | deadline 2028-12-31 | venue K | shown as: was 56% a week ago
  SENTENCE: Chuck Schumer wins the next election for Senate Democratic leader
  VENUE WORDING: Next Senate Democratic Leader? — Chuck Schumer
- id t0072 | 24% | kind named | deadline 2029-01-20 | venue K | shown as: was 13% a week ago
  SENTENCE: Pete Hegseth is the next member of Trump's Cabinet to leave or announce he is leaving
  VENUE WORDING: Who will leave Trump's Cabinet next? — Pete Hegseth
- id t0344 | 72% | kind named | deadline 2027-11-03 | venue K/P | shown as: was 80% a week ago
  SENTENCE: A Republican is inaugurated as governor of Texas following the 2026 election
  VENUE WORDING: Texas Governor winner? — Greg Abbott

## y29 — type: newfav — headline: The ____ win the AFC South division in the 2026 NFL season
- id t0393 | 66% | kind named | deadline 2027-01-25 | venue K | shown as: was 29% a month ago | row name: Jacksonville Jaguars
  SENTENCE: The Jacksonville Jaguars win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Jacksonville
- id t0391 | 14% | kind named | deadline 2027-01-25 | venue K | shown as: was 49% a month ago | row name: Houston Texans
  SENTENCE: The Houston Texans win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Houston

## y30 — type: newfav — headline: The ____ win the NFC West division in the 2026 NFL season
- id t0371 | 41% | kind named | deadline 2027-01-25 | venue K | shown as: was 22% a month ago | row name: San Francisco 49ers
  SENTENCE: The San Francisco 49ers win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — San Francisco
- id t0370 | 28% | kind named | deadline 2027-01-25 | venue K | shown as: was 47% a month ago | row name: Los Angeles Rams
  SENTENCE: The Los Angeles Rams win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — Los Angeles R

## y31 — type: swing — headline: The ____ win the AFC South division in the 2026 NFL season
- id t0393 | 66% | kind named | deadline 2027-01-25 | venue K | shown as: was 29% a month ago | row name: Jacksonville Jaguars
  SENTENCE: The Jacksonville Jaguars win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Jacksonville
- id t0391 | 14% | kind named | deadline 2027-01-25 | venue K | shown as: was 49% a month ago | row name: Houston Texans
  SENTENCE: The Houston Texans win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Houston

## y32 — type: swing — headline: The ____ win the NFC West division in the 2026 NFL season
- id t0371 | 41% | kind named | deadline 2027-01-25 | venue K | shown as: was 22% a month ago | row name: San Francisco 49ers
  SENTENCE: The San Francisco 49ers win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — San Francisco
- id t0370 | 28% | kind named | deadline 2027-01-25 | venue K | shown as: was 47% a month ago | row name: Los Angeles Rams
  SENTENCE: The Los Angeles Rams win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — Los Angeles R

## y33 — type: checklist — headline: ____ makes the College Football Playoff for the 2026 season
- id t0783 | 74% | kind named | deadline 2026-12-29 | venue K | row name: Alabama
  SENTENCE: Alabama makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Alabama
- id t0785 | 47% | kind named | deadline 2026-12-29 | venue K | row name: Utah
  SENTENCE: Utah makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Utah
- id t0782 | 46% | kind named | deadline 2026-12-29 | venue K | row name: LSU
  SENTENCE: LSU makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — LSU
- id t0784 | 36% | kind named | deadline 2026-12-29 | venue K | row name: Ole Miss
  SENTENCE: Ole Miss makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Ole Miss

## y34 — type: when — headline: When will OpenAI achieve AGI?
- id t0952 | 12% | kind date | deadline 2027-01-01 | venue K
  SENTENCE: OpenAI announces that it has achieved artificial general intelligence (AGI) by the end of 2026
  VENUE WORDING: When will OpenAI achieve AGI? — Before 2027
- id t0953 | 45% | kind date | deadline 2028-01-01 | venue K
  SENTENCE: OpenAI announces that it has achieved artificial general intelligence (AGI) by the end of 2027
  VENUE WORDING: When will OpenAI achieve AGI? — Before 2028
- id t0954 | 65% | kind date | deadline 2030-01-01 | venue K | marked: first date likelier than not
  SENTENCE: OpenAI announces that it has achieved artificial general intelligence (AGI) by the end of 2029
  VENUE WORDING: When will OpenAI achieve AGI? — Before 2030

## y35 — type: board — headline: Before Trump's term ends
- id t0055 | 42% | kind date | deadline 2029-01-20 | venue K
  SENTENCE: Zelenskyy and Putin meet before January 20, 2029
  VENUE WORDING: Will Zelenskyy and Putin speak? — Before Jan 20, 2029
- id t0052 | 23% | kind date | deadline 2029-01-21 | venue K
  SENTENCE: The United States acquires any part of Greenland before January 21, 2029
  VENUE WORDING: Will the US take control of any part of Greenland? — Before January 21, 2029
- id t0034 | 18% | kind binary | deadline 2029-01-21 | venue K
  SENTENCE: Donald Trump resigns as president before his term ends in January 2029
  VENUE WORDING: Will Trump resign during his term?
- id t0053 | 11% | kind binary | deadline 2029-01-21 | venue K
  SENTENCE: The United States acquires any part of Canada before January 21, 2029
  VENUE WORDING: Will the US take control of any part of Canada?
- id t0069 | 5% | kind binary | deadline 2029-01-20 | venue K
  SENTENCE: A bill abolishing the Federal Reserve and its reserve banks becomes law before January 20, 2029
  VENUE WORDING: Will Trump end the Federal Reserve?

## y36 — type: board — headline: By the end of 2026
- id t1381 | 81% | kind date | deadline 2026-12-31 | venue P
  SENTENCE: Donald Trump meets Vladimir Putin in person by December 31, 2026
  VENUE WORDING: Trump meets with Putin by...? — December 31
- id t1538 | 39% | kind date | deadline 2026-12-31 | venue P
  SENTENCE: The US and Canada announce an official agreement to lower US tariffs on Canada by December 31, 2026
  VENUE WORDING: US-Canada diplomatic agreement to lower tariffs by...? — December 31
- id t0913 | 12% | kind date | deadline 2027-01-01 | venue K
  SENTENCE: The Senate confirms a new Supreme Court justice by December 31, 2026
  VENUE WORDING: New Supreme Court justice confirmed? — Before 2027
- id t1110 | 7% | kind binary | deadline 2027-01-01 | venue P
  SENTENCE: Trump, Putin and Zelensky are photographed or filmed together in the same frame before 2027
  VENUE WORDING: Trump, Putin, and Zelensky seen together before 2027?
- id t0067 | 3% | kind date | deadline 2027-01-01 | venue K
  SENTENCE: The United States purchases at least part of Greenland from Denmark before 2027
  VENUE WORDING: Will Trump buy at least part of Greenland? — Before 2027

## y37 — type: band — headline: About 1 in 20
- id t1082 | 6% | kind date | deadline 2026-12-31 | venue P
  SENTENCE: The AI industry enters a downturn, meeting at least three set measures, by December 31, 2026
  VENUE WORDING: AI bubble burst by...? — December 31, 2026
- id t0057 | 5% | kind named | deadline 2029-01-20 | venue K
  SENTENCE: Any part of Cuba becomes the 51st US state before January 20, 2029
  VENUE WORDING: What will be the 51st state in Trump's term? — Cuba
- id t0582 | 4% | kind date | deadline 2027-01-01 | venue K
  SENTENCE: Donald Trump leaves office as president before 2027, for a reason other than death
  VENUE WORDING: Donald Trump announces departure as President? (Excluding death) — Before 2027
- id t0693 | 4% | kind date | deadline 2027-01-01 | venue K/P
  SENTENCE: The US government definitively states that alien life or technology exists before January 1, 2027
  VENUE WORDING: Will the U.S. confirm that aliens exist? — Before Jan 1, 2027

## y38 — type: band — headline: About 9 in 10
- id t0821 | 92% | kind named | deadline 2026-12-01 | venue K
  SENTENCE: Aaron Rodgers joins the Pittsburgh Steelers as his next team before December 1, 2026
  VENUE WORDING: Aaron Rodgers's Next Team — Pittsburgh
- id t0324 | 91% | kind named | deadline 2027-02-01 | venue K
  SENTENCE: Democrats win control of the US House in the 2026 midterm elections
  VENUE WORDING: Which party will win the U.S. House? — Democratic Party
- id t0829 | 89% | kind binary | deadline 2026-11-10 | venue K
  SENTENCE: US House elections are held on schedule in all 50 states on Election Day 2026
  VENUE WORDING: Will the midterms happen on time?
- id t0564 | 89% | kind named | deadline 2028-01-01 | venue K
  SENTENCE: Ryan Reynolds appears or is announced as Deadpool in Avengers: Doomsday
  VENUE WORDING: Avengers: Doomsday: Cast — Ryan Reynolds as Deadpool?
