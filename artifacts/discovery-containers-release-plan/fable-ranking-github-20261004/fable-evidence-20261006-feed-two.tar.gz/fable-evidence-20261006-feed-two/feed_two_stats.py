"""Prints every number quoted in FABLE-FEED-TWO-20261006.md from the files in this folder only."""
import json,glob,collections
T=json.load(open('table.json')); M={q['id']:q for q in T}
for q in json.load(open('extra_claims.json')): M[q['id']]=q
C=json.load(open('cand_slate5.json')); F=json.load(open('final5.json')); K=json.load(open('cards5.json'))
print('claims in table:',len(T))
mv=json.load(open('moves.json'))['moves']
for f,t in (('d1',.05),('w1',.08),('m1',.15)): print('verified moves over bar',f,sum(1 for v in mv.values() if f in v and abs(v[f]['move'])>=t))
print('candidate cards checked:',len(C),'| distinct claims in them:',len({i for c in C for i in c['ids']}))
V=[v for f in sorted(glob.glob('check_out_*.json')) for v in json.load(open(f))]
print('truth checker verdicts:',dict(collections.Counter(v['verdict'] for v in V)))
S=json.load(open('slatecheck_out.json')); print('whole-feed checker: contradictions',len(S['contradictions']),'duplicates',len(S['duplicates']),'misleading',len(S['misleading']))
H=[v for f in sorted(glob.glob('happened_out_*.json')) for v in json.load(open(f))]
print('already-happened check: claims',len(H),dict(collections.Counter(h['status'] for h in H)))
for h in H:
    if h['status']!='open': print('   ',h['id'],h['status'],'|',M[h['id']]['plain'],'|',h['note'],'|',h['source'])
print('quote-quality gate:',dict(collections.Counter(json.load(open('quality5.json')).values())))
print('cards dropped whole after checks:',len(json.load(open('drops5.json'))),json.load(open('drops5.json')))
print('final cards:',len(F),dict(collections.Counter(c['type'] for c in F)))
ids=[i for c in F for i in c['ids']]; print('claims shown:',len(ids),'| distinct:',len(set(ids)),'| distinct venue events:',len({M[i]['fam'] for i in ids}),'| repeated venue events across cards:',sum(1 for f,n in collections.Counter(f for c in F for f in {M[i]['fam'] for i in c['ids']}).items() if n>1))
print('cards with a chart:',[c['n'] for c in K if c.get('viz')],'| chart-eligible without:',[c['n'] for c in K if c.get('viz_eligible') and not c.get('viz')])
print('round-ups:',[(c['n'],c['headline']) for c in K if c['type']=='roundup'])
for c in K: print(c['n'],c['cid'],c['type'],'|',c['headline'],'|',[(r['text'][:28],r['num'],r.get('prev')) for r in c['rows']])
