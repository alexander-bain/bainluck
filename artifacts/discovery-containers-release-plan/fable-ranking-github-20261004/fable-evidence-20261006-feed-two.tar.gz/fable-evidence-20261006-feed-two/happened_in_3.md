# Claims to check. Today is Tuesday, October 6, 2026.

- id t0388 | shown at 64% | venue deadline 2027-01-25
  SENTENCE: The Kansas City Chiefs win the AFC West division in the 2026 NFL season
  VENUE WORDING: AFC West Division Winner — Kansas City
  RULES EXCERPT: If Kansas City wins the Pro Football AFC West Division, then the market resolves to Yes.

- id t0389 | shown at 24% | venue deadline 2027-01-25
  SENTENCE: The Denver Broncos win the AFC West division in the 2026 NFL season
  VENUE WORDING: AFC West Division Winner — Denver
  RULES EXCERPT: If Denver wins the Pro Football AFC West Division, then the market resolves to Yes.

- id t0324 | shown at 91% | venue deadline 2027-02-01
  SENTENCE: Democrats win control of the US House in the 2026 midterm elections
  VENUE WORDING: Which party will win the U.S. House? — Democratic Party
  RULES EXCERPT: If the Democratic Party has won control of the House in 2026, then the market resolves to Yes.

- id t0325 | shown at 9% | venue deadline 2027-02-01
  SENTENCE: Republicans win control of the US House in the 2026 midterm elections
  VENUE WORDING: Which party will win the U.S. House? — Republican Party
  RULES EXCERPT: If the Republican Party has won control of the House in 2026, then the market resolves to Yes.

- id t1441 | shown at 81% | venue deadline 2027-06-15
  SENTENCE: Barcelona wins Spain's LALIGA soccer title for the 2026-27 season
  VENUE WORDING: LALIGA: 2027 Champion — Barcelona
  RULES EXCERPT: This market will resolve according to the team that wins the 2026-27 LALIGA Championship.

If at any point it becomes impossible for a listed team to win the 2026-27 LALIGA Championship per the rules of LALIGA (e.g., they are eliminated in the playoffs), the corresponding market will resolve to "No"

- id t1442 | shown at 17% | venue deadline 2027-06-15
  SENTENCE: Real Madrid wins Spain's LALIGA soccer title for the 2026-27 season
  VENUE WORDING: LALIGA: 2027 Champion — Real Madrid
  RULES EXCERPT: This market will resolve according to the team that wins the 2026-27 LALIGA Championship.

If at any point it becomes impossible for a listed team to win the 2026-27 LALIGA Championship per the rules of LALIGA (e.g., they are eliminated in the playoffs), the corresponding market will resolve to "No"

- id t0197 | shown at 24% | venue deadline 2029-06-29
  SENTENCE: The Philadelphia 76ers win the NBA's Eastern Conference Finals in the 2026-27 season
  VENUE WORDING: Pro Basketball Eastern Conference Champion — Philadelphia
  RULES EXCERPT: If Philadelphia wins the Pro Basketball Eastern Conference Finals in the 2026-27 season, then the market resolves to Yes.

- id t0196 | shown at 21% | venue deadline 2029-06-29
  SENTENCE: The New York Knicks win the NBA's Eastern Conference Finals in the 2026-27 season
  VENUE WORDING: Pro Basketball Eastern Conference Champion — New York
  RULES EXCERPT: If New York wins the Pro Basketball Eastern Conference Finals in the 2026-27 season, then the market resolves to Yes.

- id t0943 | shown at 3% | venue deadline 2027-01-01
  SENTENCE: President Trump is impeached by the House before 2027
  VENUE WORDING: Will Trump be impeached? — Before Jan 1, 2027
  RULES EXCERPT: If the President of the United States has been impeached before Jan 1, 2027, then the market resolves to Yes.

- id t0944 | shown at 31% | venue deadline 2027-03-01
  SENTENCE: President Trump is impeached by the House before March 1, 2027
  VENUE WORDING: Will Trump be impeached? — Before Mar 1, 2027
  RULES EXCERPT: If the President of the United States has been impeached before Mar 1, 2027, then the market resolves to Yes.

- id t0945 | shown at 67% | venue deadline 2028-01-01
  SENTENCE: President Trump is impeached by the House before 2028
  VENUE WORDING: Will Trump be impeached? — Before Jan 1, 2028
  RULES EXCERPT: If the President of the United States has been impeached before Jan 1, 2028, then the market resolves to Yes.

- id t0916 | shown at 39% | venue deadline 2029-01-21
  SENTENCE: A ban on members of Congress trading stocks becomes law by January 20, 2029
  VENUE WORDING: Will members of Congress be banned from trading stocks? — Before Jan 21, 2029
  RULES EXCERPT: If a Congressional stock trading ban becomes law between Issuance and January 20, 2029, then the market resolves to Yes.

- id t0077 | shown at 34% | venue deadline 2029-01-20
  SENTENCE: Israel and Saudi Arabia normalize diplomatic relations before January 20, 2029
  VENUE WORDING: Will Israel and Saudi Arabia normalize relations during Trump's term?
  RULES EXCERPT: If Israel and Saudi Arabia normalize diplomatic relations before Jan 20, 2029, then the market resolves to Yes.

- id t0695 | shown at 23% | venue deadline 2029-01-20
  SENTENCE: The US government definitively states that alien life or technology exists before January 20, 2029
  VENUE WORDING: Will the U.S. confirm that aliens exist? — Before Jan 20, 2029
  RULES EXCERPT: If the President, any member of the Cabinet, any member of the Joint Chiefs of Staff, or any US federal agency definitively states that extraterrestrial life or technology exists before Jan 20, 2029, then the market resolves to Yes.
