# Claims to check. Today is Tuesday, October 6, 2026.

- id t0791 | shown at 72% | venue deadline 2026-12-09
  SENTENCE: The Federal Reserve raises interest rates by a quarter point on December 9, 2026
  VENUE WORDING: Fed decision in Dec 2026? — Hike 25bps
  RULES EXCERPT: If the Federal Reserve does a Hike of 25bps on December 09, 2026, then the market resolves to Yes.

- id t0328 | shown at 63% | venue deadline 2027-01-27
  SENTENCE: The Federal Reserve leaves interest rates unchanged at its January 27, 2027 meeting
  VENUE WORDING: Fed decision in Jan 2027? — Fed maintains rate
  RULES EXCERPT: If the Federal Reserve does a Hike of 0bps on January 27, 2027, then the market resolves to Yes.

- id t0276 | shown at 27% | venue deadline 2028-02-08
  SENTENCE: Will Anderson Jr. wins NFL Defensive Player of the Year for the 2026-27 season
  VENUE WORDING: Defensive Player of the Year Winner? — Will Anderson Jr.
  RULES EXCERPT: If Will Anderson Jr. wins the Pro Football AP Defensive Player Of The Year in the 2026-27 season, then the market resolves to Yes.

- id t0263 | shown at 65% | venue deadline 2028-02-21
  SENTENCE: Patrick Mahomes wins NFL Comeback Player of the Year for the 2026-27 season
  VENUE WORDING: Comeback Player of the Year Winner? — Patrick Mahomes
  RULES EXCERPT: If Patrick Mahomes wins the Pro Football AP Comeback Player of the Year in the 2026-27 season, then the market resolves to Yes.

- id t0251 | shown at 32% | venue deadline 2028-02-28
  SENTENCE: Jeremiyah Love wins NFL Offensive Rookie of the Year for the 2026-27 season
  VENUE WORDING: Offensive Rookie of the Year Winner? — Jeremiyah Love
  RULES EXCERPT: If Jeremiyah Love wins the Pro Football AP Offensive Rookie of the Year in the 2026-27 season, then the market resolves to Yes.

- id t0258 | shown at 35% | venue deadline 2028-02-28
  SENTENCE: Jacob Rodriguez wins NFL Defensive Rookie of the Year for the 2026-27 season
  VENUE WORDING: Defensive Rookie of the Year Winner? — Jacob Rodriguez
  RULES EXCERPT: If Jacob Rodriguez wins the Pro Football AP Defensive Rookie of the Year in the 2026-27 season, then the market resolves to Yes.

- id t0747 | shown at 76% | venue deadline 2026-12-31
  SENTENCE: Tyreek Hill joins the Kansas City Chiefs as his next team before December 31, 2026
  VENUE WORDING: Tyreek Hill's Next Team — Kansas City
  RULES EXCERPT: If Tyreek Hill's next team is Kansas City before Dec 31, 2026, then the market resolves to Yes.

- id t0783 | shown at 74% | venue deadline 2026-12-29
  SENTENCE: Alabama makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Alabama
  RULES EXCERPT: If Alabama is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.

- id t1381 | shown at 81% | venue deadline 2026-12-31
  SENTENCE: Donald Trump meets Vladimir Putin in person by December 31, 2026
  VENUE WORDING: Trump meets with Putin by...? — December 31
  RULES EXCERPT: This market will resolve to "Yes" if Donald Trump meets with Vladimir Putin between market creation and the listed date, 11:59 PM ET. Otherwise, this market will resolve to "No".

A meeting is defined as any encounter where both Trump and Putin are present and interact with each other in person.

An

- id t0116 | shown at 80% | venue deadline 2028-12-31
  SENTENCE: Chuck Schumer wins the next election for Senate Democratic leader
  VENUE WORDING: Next Senate Democratic Leader? — Chuck Schumer
  RULES EXCERPT: If Chuck Schumer wins the next Senate Democratic Leader election, then the market resolves to Yes.

- id t0600 | shown at 40% | venue deadline 2027-01-01
  SENTENCE: SpaceX's Starship launches from Florida before 2027
  VENUE WORDING: When will SpaceX's Starship launch from Florida? — Before 2027
  RULES EXCERPT: If the SpaceX Starship has launched from Florida before Jan 1, 2027, then the market resolves to Yes.

- id t0342 | shown at 57% | venue deadline 2027-12-31
  SENTENCE: Robert Pattinson is nominated for Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar nominees: Best Actor — Robert Pattinson
  RULES EXCERPT: If Robert Pattinson has been nominated for Best Actor at the 99th Academy Awards, then the market resolves to Yes.

- id t0556 | shown at 16% | venue deadline 2027-01-01
  SENTENCE: OpenAI has a number-one ranked AI model at some point before 2027
  VENUE WORDING: Which companies will have a top-ranked AI model this year? — OpenAI
  RULES EXCERPT: If OpenAI has a #1 ranked AI model before Jan 1, 2027, then the market resolves to Yes.

- id t1542 | shown at 18% | venue deadline 2026-12-01
  SENTENCE: Anthropic's shares begin trading on a public stock exchange in December 2026
  VENUE WORDING: In which month will Anthropic IPO? — December 2026
  RULES EXCERPT: This market will resolve based on the calendar month (ET) in which Anthropic's initial public offering (IPO) occurs. The resolving month will be the calendar month (ET) containing the first day on which Anthropic shares are listed and open for regular-way trading on a public securities exchange.

An
