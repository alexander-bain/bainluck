# Claims to check. Today is Tuesday, October 6, 2026.

- id t0382 | shown at 44% | venue deadline 2027-01-25
  SENTENCE: The Dallas Cowboys win the NFC East division in the 2026 NFL season
  VENUE WORDING: NFC East Division Winner — Dallas
  RULES EXCERPT: If Dallas wins the Pro Football NFC East Division, then the market resolves to Yes.

- id t0371 | shown at 41% | venue deadline 2027-01-25
  SENTENCE: The San Francisco 49ers win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — San Francisco
  RULES EXCERPT: If San Francisco wins the Pro Football NFC West Division, then the market resolves to Yes.

- id t0380 | shown at 38% | venue deadline 2027-01-25
  SENTENCE: The Minnesota Vikings win the NFC North division in the 2026 NFL season
  VENUE WORDING: NFC North Division Winner — Minnesota
  RULES EXCERPT: If Minnesota wins the Pro Football NFC North Division, then the market resolves to Yes.

- id t0374 | shown at 35% | venue deadline 2027-01-25
  SENTENCE: The Atlanta Falcons win the NFC South division in the 2026 NFL season
  VENUE WORDING: NFC South Division Winner — Atlanta
  RULES EXCERPT: If Atlanta wins the Pro Football NFC South Division, then the market resolves to Yes.

- id t0198 | shown at 30% | venue deadline 2027-06-21
  SENTENCE: Manchester City is relegated from England's Premier League in the 2026-27 season
  VENUE WORDING: EPL Relegation — Manchester City
  RULES EXCERPT: If Manchester City is relegated from the EPL in 2026-27 season, then the market resolves to Yes.

- id t0740 | shown at 8% | venue deadline 2027-01-01
  SENTENCE: Bad Bunny is named People magazine's Sexiest Man Alive for 2026
  VENUE WORDING: People's Sexiest Man Alive for 2026 — Bad Bunny
  RULES EXCERPT: If Bad Bunny is People's Sexiest Man Alive in 2026, then the market resolves to Yes.

- id t0859 | shown at 33% | venue deadline 2028-10-31
  SENTENCE: The Chicago White Sox win the 2026 American League title and advance to the World Series
  VENUE WORDING: American League Champion — Chicago WS
  RULES EXCERPT: If Chicago WS win the 2026 Pro Baseball American League Championship, then the market resolves to Yes.

- id t0897 | shown at 42% | venue deadline 2027-06-02
  SENTENCE: Karen Bass wins the 2026 Los Angeles mayoral election
  VENUE WORDING: Los Angeles Mayor winner? — Karen Bass
  RULES EXCERPT: If Karen Bass wins the 2026 Los Angeles Mayoral Election, then the market resolves to Yes.

- id t0884 | shown at 46% | venue deadline 2027-07-07
  SENTENCE: Susan Collins wins the 2026 US Senate election in Maine
  VENUE WORDING: Maine Senate winner? (Person) — Susan Collins
  RULES EXCERPT: If Susan Collins wins the 2026 Maine Senate election, then the market resolves to Yes.

- id t0072 | shown at 24% | venue deadline 2029-01-20
  SENTENCE: Pete Hegseth is the next member of Trump's Cabinet to leave or announce he is leaving
  VENUE WORDING: Who will leave Trump's Cabinet next? — Pete Hegseth
  RULES EXCERPT: If Pete Hegseth is the first member of the Cabinet of Donald Trump to leave or announce they will leave (such as by quitting, being fired, or being impeached) after May 22, 2026, then the market resolves to Yes.

- id t0344 | shown at 72% | venue deadline 2027-11-03
  SENTENCE: A Republican is inaugurated as governor of Texas following the 2026 election
  VENUE WORDING: Texas Governor winner? — Greg Abbott
  RULES EXCERPT: If a representative of the Republican party is inaugurated as the governor of Texas pursuant to the 2026 election, then the market resolves to Yes.

- id t0393 | shown at 66% | venue deadline 2027-01-25
  SENTENCE: The Jacksonville Jaguars win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Jacksonville
  RULES EXCERPT: If Jacksonville wins the Pro Football AFC South Division, then the market resolves to Yes.

- id t0391 | shown at 14% | venue deadline 2027-01-25
  SENTENCE: The Houston Texans win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Houston
  RULES EXCERPT: If Houston wins the Pro Football AFC South Division, then the market resolves to Yes.

- id t0370 | shown at 28% | venue deadline 2027-01-25
  SENTENCE: The Los Angeles Rams win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — Los Angeles R
  RULES EXCERPT: If Los Angeles R wins the Pro Football NFC West Division, then the market resolves to Yes.
