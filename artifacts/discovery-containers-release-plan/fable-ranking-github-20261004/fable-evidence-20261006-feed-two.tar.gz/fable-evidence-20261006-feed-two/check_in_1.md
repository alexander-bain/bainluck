
## y13 — type: swing — headline: The ____ win the AFC West division in the 2026 NFL season
- id t0388 | 64% | kind named | deadline 2027-01-25 | venue K | shown as: was 34% a month ago | row name: Kansas City Chiefs
  SENTENCE: The Kansas City Chiefs win the AFC West division in the 2026 NFL season
  VENUE WORDING: AFC West Division Winner — Kansas City
  RULES EXCERPT: If Kansas City wins the Pro Football AFC West Division, then the market resolves to Yes.
- id t0389 | 24% | kind named | deadline 2027-01-25 | venue K | shown as: was 33% a month ago | row name: Denver Broncos
  SENTENCE: The Denver Broncos win the AFC West division in the 2026 NFL season
  VENUE WORDING: AFC West Division Winner — Denver
  RULES EXCERPT: If Denver wins the Pro Football AFC West Division, then the market resolves to Yes.

## y14 — type: swing — headline: ____ win control of the US House in the 2026 midterm elections
- id t0324 | 91% | kind named | deadline 2027-02-01 | venue K | shown as: was 85% a month ago | row name: Democrats
  SENTENCE: Democrats win control of the US House in the 2026 midterm elections
  VENUE WORDING: Which party will win the U.S. House? — Democratic Party
  RULES EXCERPT: If the Democratic Party has won control of the House in 2026, then the market resolves to Yes.
- id t0325 | 9% | kind named | deadline 2027-02-01 | venue K | shown as: was 17% a month ago | row name: Republicans
  SENTENCE: Republicans win control of the US House in the 2026 midterm elections
  VENUE WORDING: Which party will win the U.S. House? — Republican Party
  RULES EXCERPT: If the Republican Party has won control of the House in 2026, then the market resolves to Yes.

## y15 — type: swing — headline: ____ wins Spain's LALIGA soccer title for the 2026-27 season
- id t1441 | 81% | kind named | deadline 2027-06-15 | venue P | shown as: was 67% a month ago | row name: Barcelona
  SENTENCE: Barcelona wins Spain's LALIGA soccer title for the 2026-27 season
  VENUE WORDING: LALIGA: 2027 Champion — Barcelona
  RULES EXCERPT: This market will resolve according to the team that wins the 2026-27 LALIGA Championship.

If at any point it becomes impossible for a listed team to win the 2026-27 LALIGA Championship per the rules of LALIGA (e.g., they are eliminated in the playoffs), the corresponding market will resolve to "No"
- id t1442 | 17% | kind named | deadline 2027-06-15 | venue P | shown as: was 32% a month ago | row name: Real Madrid
  SENTENCE: Real Madrid wins Spain's LALIGA soccer title for the 2026-27 season
  VENUE WORDING: LALIGA: 2027 Champion — Real Madrid
  RULES EXCERPT: This market will resolve according to the team that wins the 2026-27 LALIGA Championship.

If at any point it becomes impossible for a listed team to win the 2026-27 LALIGA Championship per the rules of LALIGA (e.g., they are eliminated in the playoffs), the corresponding market will resolve to "No"

## y16 — type: deadheat — headline: ____ win the NBA's Eastern Conference Finals in the 2026-27 season
- id t0197 | 24% | kind named | deadline 2029-06-29 | venue K | row name: The Philadelphia 76ers
  SENTENCE: The Philadelphia 76ers win the NBA's Eastern Conference Finals in the 2026-27 season
  VENUE WORDING: Pro Basketball Eastern Conference Champion — Philadelphia
  RULES EXCERPT: If Philadelphia wins the Pro Basketball Eastern Conference Finals in the 2026-27 season, then the market resolves to Yes.
- id t0196 | 21% | kind named | deadline 2029-06-29 | venue K | row name: The New York Knicks
  SENTENCE: The New York Knicks win the NBA's Eastern Conference Finals in the 2026-27 season
  VENUE WORDING: Pro Basketball Eastern Conference Champion — New York
  RULES EXCERPT: If New York wins the Pro Basketball Eastern Conference Finals in the 2026-27 season, then the market resolves to Yes.

## y17 — type: when — headline: Will Trump be impeached?
- id t0943 | 3% | kind date | deadline 2027-01-01 | venue K/P
  SENTENCE: President Trump is impeached by the House before 2027
  VENUE WORDING: Will Trump be impeached? — Before Jan 1, 2027
  RULES EXCERPT: If the President of the United States has been impeached before Jan 1, 2027, then the market resolves to Yes.
- id t0944 | 31% | kind date | deadline 2027-03-01 | venue K
  SENTENCE: President Trump is impeached by the House before March 1, 2027
  VENUE WORDING: Will Trump be impeached? — Before Mar 1, 2027
  RULES EXCERPT: If the President of the United States has been impeached before Mar 1, 2027, then the market resolves to Yes.
- id t0945 | 67% | kind date | deadline 2028-01-01 | venue K | marked: first date likelier than not
  SENTENCE: President Trump is impeached by the House before 2028
  VENUE WORDING: Will Trump be impeached? — Before Jan 1, 2028
  RULES EXCERPT: If the President of the United States has been impeached before Jan 1, 2028, then the market resolves to Yes.

## y18 — type: board — headline: Before Trump's term ends
- id t0916 | 39% | kind date | deadline 2029-01-21 | venue K
  SENTENCE: A ban on members of Congress trading stocks becomes law by January 20, 2029
  VENUE WORDING: Will members of Congress be banned from trading stocks? — Before Jan 21, 2029
  RULES EXCERPT: If a Congressional stock trading ban becomes law between Issuance and January 20, 2029, then the market resolves to Yes.
- id t0077 | 34% | kind binary | deadline 2029-01-20 | venue K
  SENTENCE: Israel and Saudi Arabia normalize diplomatic relations before January 20, 2029
  VENUE WORDING: Will Israel and Saudi Arabia normalize relations during Trump's term?
  RULES EXCERPT: If Israel and Saudi Arabia normalize diplomatic relations before Jan 20, 2029, then the market resolves to Yes.
- id t0695 | 23% | kind date | deadline 2029-01-20 | venue K
  SENTENCE: The US government definitively states that alien life or technology exists before January 20, 2029
  VENUE WORDING: Will the U.S. confirm that aliens exist? — Before Jan 20, 2029
  RULES EXCERPT: If the President, any member of the Cabinet, any member of the Joint Chiefs of Staff, or any US federal agency definitively states that extraterrestrial life or technology exists before Jan 20, 2029, then the market resolves to Yes.
- id t0068 | 12% | kind date | deadline 2029-01-20 | venue K
  SENTENCE: The United States purchases at least part of Greenland from Denmark before January 20, 2029
  VENUE WORDING: Will Trump buy at least part of Greenland? — Before January 20, 2029
  RULES EXCERPT: If the United States purchases at least part of Greenland from Denmark before January 20, 2029, then the market resolves to Yes.

## y19 — type: board — headline: By the end of October
- id t1549 | 60% | kind date | deadline 2026-10-31 | venue P
  SENTENCE: Official representatives of Russia and Ukraine hold a diplomatic meeting by October 31, 2026
  VENUE WORDING: Russia x Ukraine any diplomatic meeting by...? — October 31
  RULES EXCERPT: This market will resolve to "Yes" if there is a diplomatic meeting between representatives of Russia and Ukraine by the listed date, 11:59 PM ET. Otherwise, this market will resolve to “No”.

A diplomatic meeting refers to a deliberate meeting between representatives of the listed countries who are 
- id t0903 | 50% | kind date | deadline 2026-11-01 | venue K
  SENTENCE: A new official GTA VI trailer, at least 30 seconds long, is released before November 2026
  VENUE WORDING: Grand Theft Auto VI: New trailer release date — Before November 2026
  RULES EXCERPT: If a new (at least 30 second) GTA VI trailer is publicly and officially released before Nov 1, 2026, then the market resolves to Yes.
- id t1539 | 9% | kind date | deadline 2026-10-31 | venue P
  SENTENCE: The US and Canada announce an official agreement to lower US tariffs on Canada by October 31, 2026
  VENUE WORDING: US-Canada diplomatic agreement to lower tariffs by...? — October 31
  RULES EXCERPT: This market will resolve to “Yes” if a diplomatic agreement between the United States and Canada to lower US tariffs on Canada is announced by October 31, 2026, 11:59 PM ET.

A diplomatic agreement to lower US tariffs on Canada refers to an official agreement, treaty, deal, or substantially similar 
- id t0412 | 4% | kind date | deadline 2026-11-01 | venue K
  SENTENCE: Kash Patel leaves his job as FBI Director before November 1, 2026
  VENUE WORDING: Kash Patel out as FBI Director? — Before Nov 1, 2026
  RULES EXCERPT: If Kash Patel leaves as FBI Director before Nov 1, 2026, then the market resolves to Yes.

## y20 — type: band — headline: About 1 in 4
- id t0033 | 26% | kind date | deadline 2029-01-21 | venue K
  SENTENCE: The United States gains control of any new territory outside its current sovereignty before January 21, 2029
  VENUE WORDING: Will the US acquire any new territory? — Before Jan 21, 2029
  RULES EXCERPT: If the United States gains control of any territory outside its sovereignty as of Issuance before Jan 21, 2029, then the market resolves to Yes.
- id t0670 | 26% | kind date | deadline 2028-01-01 | venue K
  SENTENCE: Legislation making Daylight Saving Time permanent becomes law before 2028
  VENUE WORDING: Will Daylight Saving Time become permanent? — Before Jan 1, 2028
  RULES EXCERPT: If legislation establishing permanent Daylight Saving Time has become law after Issuance and before Jan 1, 2028, then the market resolves to Yes.
- id t0015 | 24% | kind binary | deadline 2030-01-01 | venue K
  SENTENCE: SpaceX successfully lands anything on Mars before 2030
  VENUE WORDING: Will SpaceX land anything successfully on Mars before 2030?
  RULES EXCERPT: If SpaceX lands anything on Mars before Jan 1, 2030, then the market resolves to Yes.

## y21 — type: band — headline: About 1 in 3
- id t0981 | 35% | kind named | deadline 2028-11-08 | venue P
  SENTENCE: The Republican candidate wins the 2028 US presidential election
  VENUE WORDING: Which party wins 2028 US Presidential Election? — Republican
  RULES EXCERPT: The 2028 United States presidential election will be held on Tuesday, November 7, 2028.

This market will resolve to the political party whose candidate is elected the next President of the United States in the 2028 election.

The resolution source for this market is the Associated Press, Fox News, 
- id t0082 | 33% | kind named | deadline 2028-11-07 | venue K
  SENTENCE: The 2028 Republican ticket is JD Vance for president and Marco Rubio for vice president
  VENUE WORDING: 2028 Republican Presidential ticket — JD Vance and Marco Rubio
  RULES EXCERPT: If the Republican presidential nominee is JD Vance AND the Republican vice presidential nominee is Marco Rubio in the 2028 presidential election, then the market resolves to Yes.
- id t0178 | 32% | kind named | deadline 2028-06-30 | venue K
  SENTENCE: Victor Wembanyama wins NBA Most Valuable Player for the 2026-27 season
  VENUE WORDING: Pro Basketball MVP Winner — Victor Wembanyama
  RULES EXCERPT: If Victor Wembanyama wins the Pro Basketball Most Valuable Player in the 2026-27 season, then the market resolves to Yes.

## y22 — type: roundup — headline: The favorite for each title — tag: Sports
- id t0861 | 28% | kind named | deadline 2028-10-31 | venue K | row name: World Series: Dodgers
  SENTENCE: The Los Angeles Dodgers win the 2026 World Series
  VENUE WORDING: Pro Baseball Champion — Los Angeles D
  RULES EXCERPT: If Los Angeles D wins the 2026 Pro Baseball Championship, then the market resolves to Yes.
- id t0200 | 26% | kind named | deadline 2027-06-19 | venue K | row name: Champions League: Barcelona
  SENTENCE: Barcelona wins the 2026-27 UEFA Champions League
  VENUE WORDING: Champions League Winner — Barcelona
  RULES EXCERPT: If Barcelona is the 2026-27 Champions League winner, then the market resolves to Yes.
- id t1218 | 22% | kind named | deadline 2027-01-01 | venue P | row name: MLS Cup: Whitecaps
  SENTENCE: The Vancouver Whitecaps win the 2026 MLS Cup
  VENUE WORDING: MLS Cup Winner 2026 — Vancouver Whitecaps FC
  RULES EXCERPT: This market will resolve according to the team that wins the 2026 MLS Cup. 

If at any point it becomes impossible for a listed team to win the 2026 MLS Cup per the rules of MLS (e.g. they are mathematically eliminated), the corresponding market will resolve to “No”.

If the 2026 MLS season is cance

## y23 — type: roundup — headline: The tightest NFL division races — tag: NFL
- id t0382 | 44% | kind named | deadline 2027-01-25 | venue K | row name: NFC East: Cowboys
  SENTENCE: The Dallas Cowboys win the NFC East division in the 2026 NFL season
  VENUE WORDING: NFC East Division Winner — Dallas
  RULES EXCERPT: If Dallas wins the Pro Football NFC East Division, then the market resolves to Yes.
- id t0371 | 41% | kind named | deadline 2027-01-25 | venue K | row name: NFC West: 49ers
  SENTENCE: The San Francisco 49ers win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — San Francisco
  RULES EXCERPT: If San Francisco wins the Pro Football NFC West Division, then the market resolves to Yes.
- id t0380 | 38% | kind named | deadline 2027-01-25 | venue K | row name: NFC North: Vikings
  SENTENCE: The Minnesota Vikings win the NFC North division in the 2026 NFL season
  VENUE WORDING: NFC North Division Winner — Minnesota
  RULES EXCERPT: If Minnesota wins the Pro Football NFC North Division, then the market resolves to Yes.
- id t0374 | 35% | kind named | deadline 2027-01-25 | venue K | row name: NFC South: Falcons
  SENTENCE: The Atlanta Falcons win the NFC South division in the 2026 NFL season
  VENUE WORDING: NFC South Division Winner — Atlanta
  RULES EXCERPT: If Atlanta wins the Pro Football NFC South Division, then the market resolves to Yes.

## y24 — type: movers — headline: Moves this month — tag: Culture and sport
- id t0747 | 76% | kind named | deadline 2026-12-31 | venue K | shown as: was 35% a month ago
  SENTENCE: Tyreek Hill joins the Kansas City Chiefs as his next team before December 31, 2026
  VENUE WORDING: Tyreek Hill's Next Team — Kansas City
  RULES EXCERPT: If Tyreek Hill's next team is Kansas City before Dec 31, 2026, then the market resolves to Yes.
- id t0783 | 74% | kind named | deadline 2026-12-29 | venue K | shown as: was 36% a month ago
  SENTENCE: Alabama makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Alabama
  RULES EXCERPT: If Alabama is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.
- id t0198 | 30% | kind named | deadline 2027-06-21 | venue K | shown as: was 4% a month ago
  SENTENCE: Manchester City is relegated from England's Premier League in the 2026-27 season
  VENUE WORDING: EPL Relegation — Manchester City
  RULES EXCERPT: If Manchester City is relegated from the EPL in 2026-27 season, then the market resolves to Yes.
- id t0740 | 8% | kind named | deadline 2027-01-01 | venue K | shown as: was 26% a month ago
  SENTENCE: Bad Bunny is named People magazine's Sexiest Man Alive for 2026
  VENUE WORDING: People's Sexiest Man Alive for 2026 — Bad Bunny
  RULES EXCERPT: If Bad Bunny is People's Sexiest Man Alive in 2026, then the market resolves to Yes.

## y25 — type: movers — headline: Climbers this week
- id t0747 | 76% | kind named | deadline 2026-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Tyreek Hill joins the Kansas City Chiefs as his next team before December 31, 2026
  VENUE WORDING: Tyreek Hill's Next Team — Kansas City
  RULES EXCERPT: If Tyreek Hill's next team is Kansas City before Dec 31, 2026, then the market resolves to Yes.
- id t0116 | 80% | kind named | deadline 2028-12-31 | venue K | shown as: was 56% a week ago
  SENTENCE: Chuck Schumer wins the next election for Senate Democratic leader
  VENUE WORDING: Next Senate Democratic Leader? — Chuck Schumer
  RULES EXCERPT: If Chuck Schumer wins the next Senate Democratic Leader election, then the market resolves to Yes.
- id t0600 | 40% | kind date | deadline 2027-01-01 | venue K | shown as: was 22% a week ago
  SENTENCE: SpaceX's Starship launches from Florida before 2027
  VENUE WORDING: When will SpaceX's Starship launch from Florida? — Before 2027
  RULES EXCERPT: If the SpaceX Starship has launched from Florida before Jan 1, 2027, then the market resolves to Yes.
- id t0342 | 57% | kind named | deadline 2027-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Robert Pattinson is nominated for Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar nominees: Best Actor — Robert Pattinson
  RULES EXCERPT: If Robert Pattinson has been nominated for Best Actor at the 99th Academy Awards, then the market resolves to Yes.
