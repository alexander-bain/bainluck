# Claims to check. Today is Tuesday, October 6, 2026.

- id s3 | shown at 86% | venue deadline 2026-10-31
  SENTENCE: The Chicago White Sox win their 2026 American League Division Series against the Cleveland Guardians
  VENUE WORDING: Series Winner: Chicago WS vs Cleveland — Chicago WS
  RULES EXCERPT: If Chicago WS wins the Chicago WS vs Cleveland Division Series in the 2026 Pro Baseball Playoffs, then the market resolves to Yes.

- id s1 | shown at 84% | venue deadline 2026-10-31
  SENTENCE: The Tampa Bay Rays win their 2026 American League Division Series against the New York Yankees
  VENUE WORDING: Series Winner: New York Y vs Tampa Bay — Tampa Bay
  RULES EXCERPT: If Tampa Bay wins the New York Y vs Tampa Bay Division Series in the 2026 Pro Baseball Playoffs, then the market resolves to Yes.

- id s0 | shown at 88% | venue deadline 2026-11-01
  SENTENCE: The Milwaukee Brewers win their 2026 National League Division Series against the San Diego Padres
  VENUE WORDING: Series Winner: San Diego vs Milwaukee — Milwaukee
  RULES EXCERPT: If Milwaukee wins the San Diego vs Milwaukee Division Series in the 2026 Pro Baseball Playoffs, then the market resolves to Yes.

- id s2 | shown at 61% | venue deadline 2026-10-31
  SENTENCE: The Los Angeles Dodgers win their 2026 National League Division Series against the Atlanta Braves
  VENUE WORDING: Series Winner: Atlanta vs Los Angeles D — Los Angeles D
  RULES EXCERPT: If Los Angeles D wins the Atlanta vs Los Angeles D Division Series in the 2026 Pro Baseball Playoffs, then the market resolves to Yes.

- id t0488 | shown at 64% | venue deadline 2027-11-03
  SENTENCE: A Republican is sworn in as US Senator from Kansas for the term starting in 2027
  VENUE WORDING: Kansas Senate winner? — Roger Marshall
  RULES EXCERPT: If a representative of the Republican party is sworn in as a Senator of Kansas for the term beginning in 2027, then the market resolves to Yes.

- id t0469 | shown at 62% | venue deadline 2027-11-03
  SENTENCE: A Democrat is sworn in as US Senator from Ohio for the term starting in 2027
  VENUE WORDING: Ohio Senate winner? — Sherrod Brown
  RULES EXCERPT: If a representative of the Democratic party is sworn in as a Senator of Ohio for the term beginning in 2027, then the market resolves to Yes.

- id t0485 | shown at 58% | venue deadline 2027-11-03
  SENTENCE: A Democrat is sworn in as US Senator from Maine for the term starting in 2027
  VENUE WORDING: Maine Senate winner? — Troy Jackson
  RULES EXCERPT: If a representative of the Democratic party is sworn in as a Senator of Maine for the term beginning in 2027, then the market resolves to Yes.

- id t0492 | shown at 56% | venue deadline 2027-11-03
  SENTENCE: A Republican is sworn in as US Senator from Iowa for the term starting in 2027
  VENUE WORDING: Iowa Senate winner? — Ashley Hinson
  RULES EXCERPT: If a representative of the Republican party is sworn in as a Senator of Iowa for the term beginning in 2027, then the market resolves to Yes.

- id t0136 | shown at 52% | venue deadline 2027-12-31
  SENTENCE: Christopher Nolan's The Odyssey wins Best Picture at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Picture — The Odyssey
  RULES EXCERPT: If The Odyssey has won Best Picture at the 99th Academy Awards, then the market resolves to Yes.

- id t0140 | shown at 67% | venue deadline 2027-12-31
  SENTENCE: Christopher Nolan wins Best Director at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Director — Christopher Nolan
  RULES EXCERPT: If Christopher Nolan has won Best Director at the 99th Academy Awards, then the market resolves to Yes.

- id t0144 | shown at 40% | venue deadline 2027-12-31
  SENTENCE: John Malkovich wins Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Actor — John Malkovich
  RULES EXCERPT: If John Malkovich has won Best Actor at the 99th Academy Awards, then the market resolves to Yes.

- id t0143 | shown at 65% | venue deadline 2027-12-31
  SENTENCE: Julianne Moore wins Best Actress at the 2027 Oscars
  VENUE WORDING: Oscar winner: Best Actress — Julianne Moore
  RULES EXCERPT: If Julianne Moore has won Best Actress at the 99th Academy Awards, then the market resolves to Yes.

- id t0134 | shown at 53% | venue deadline 2027-12-31
  SENTENCE: Anne Hathaway wins Best Supporting Actress at the 2027 Oscars
  VENUE WORDING: Oscar Winner: Best Supporting Actress — Anne Hathaway
  RULES EXCERPT: If Anne Hathaway has won Best Supporting Actress at the 99th Academy Awards, then the market resolves to Yes.

- id t0866 | shown at 84% | venue deadline 2026-10-28
  SENTENCE: The Federal Reserve leaves interest rates unchanged at its October 28, 2026 meeting
  VENUE WORDING: Fed decision in Oct 2026? — Fed maintains rate
  RULES EXCERPT: If the Federal Reserve does a Hike of 0bps on October 28, 2026, then the market resolves to Yes.
