# Claims to check. Today is Tuesday, October 6, 2026.

- id t0615 | shown at 8% | venue deadline 2027-01-01
  SENTENCE: Elon Musk is confirmed as the next CEO of X, formerly Twitter, before 2027
  VENUE WORDING: Who will be the next CEO of X? — Elon Musk
  RULES EXCERPT: If Elon Musk is confirmed as CEO for X before Jan 1, 2027, then the market resolves to Yes.

- id t0649 | shown at 71% | venue deadline 2026-10-16
  SENTENCE: Google releases Gemini 4 before October 16, 2026
  VENUE WORDING: When will Google release Gemini 4? — Before Oct 16, 2026
  RULES EXCERPT: If Google releases Gemini 4 before Oct 16, 2026, then the market resolves to Yes.

- id t0883 | shown at 20% | venue deadline 2027-01-01
  SENTENCE: Jerome Powell announces he is leaving the Federal Reserve Board, or leaves it, before 2027
  VENUE WORDING: Jerome Powell departure as Fed Governor announced? — Before Jan 1, 2027
  RULES EXCERPT: If Jerome Powell has either officially announced their intention to leave as member of the Board of Governors of the Federal Reserve System or has actually left as member of the Board of Governors of the Federal Reserve System before Jan 1, 2027, then the market resolves to Yes.

- id t0830 | shown at 6% | venue deadline 2026-11-03
  SENTENCE: A US ban on diesel exports takes effect before November 3, 2026
  VENUE WORDING: Will the US ban diesel exports before Election Day?
  RULES EXCERPT: If the United States has imposed a ban on exports of diesel that has gone into effect after Issuance and before Nov 3, 2026, then the market resolves to Yes.

- id t0376 | shown at 25% | venue deadline 2027-01-25
  SENTENCE: The New Orleans Saints win the NFC South division in the 2026 NFL season
  VENUE WORDING: NFC South Division Winner — New Orleans
  RULES EXCERPT: If New Orleans wins the Pro Football NFC South Division, then the market resolves to Yes.

- id t0857 | shown at 6% | venue deadline 2028-10-31
  SENTENCE: The Cleveland Guardians win the 2026 American League title and advance to the World Series
  VENUE WORDING: American League Champion — Cleveland
  RULES EXCERPT: If Cleveland win the 2026 Pro Baseball American League Championship, then the market resolves to Yes.

- id t0287 | shown at 40% | venue deadline 2027-02-15
  SENTENCE: Jay-Z is announced to headline the February 2027 Super Bowl halftime show
  VENUE WORDING: Pro Football Championship Halftime Show: Headliner(s) — JAY-Z
  RULES EXCERPT: If JAY-Z is announced to headline the Pro Football Championship Halftime Show before Feb 15, 2027, then the market resolves to Yes.

- id t1278 | shown at 6% | venue deadline 2027-02-15
  SENTENCE: Lamar Jackson wins the NFL Most Valuable Player award for the 2026 season
  VENUE WORDING: Pro Football: 2026 MVP Winner — Lamar Jackson
  RULES EXCERPT: This market will resolve to the player who wins the 2026 NFL Most Valuable Player award for the 2026-27 NFL season.

In the event of a tie, this market will resolve according to the official winner as determined by NFL rules. If multiple winners are announced then this market will resolve to the pla

- id t1478 | shown at 62% | venue deadline 2027-01-01
  SENTENCE: Avengers: Doomsday has 2026's second-biggest opening weekend at the US and Canada box office
  VENUE WORDING: Which movie has 2nd biggest opening weekend in 2026? — Avengers: Doomsday
  RULES EXCERPT: This market will resolve according to the title of the movie which grosses the second-most domestically on its opening weekend among all movies in 2026. The "Weekend Box Office Performance" table on the page for the relevant movie on https://www.the-numbers.com/movies/year/2026 will be used to resol

- id t1477 | shown at 39% | venue deadline 2027-01-01
  SENTENCE: Spider-Man: Brand New Day has 2026's second-biggest opening weekend at the US and Canada box office
  VENUE WORDING: Which movie has 2nd biggest opening weekend in 2026? — Spider-Man: Brand New Day
  RULES EXCERPT: This market will resolve according to the title of the movie which grosses the second-most domestically on its opening weekend among all movies in 2026. The "Weekend Box Office Performance" table on the page for the relevant movie on https://www.the-numbers.com/movies/year/2026 will be used to resol

- id t0558 | shown at 53% | venue deadline 2027-11-03
  SENTENCE: A Democrat is inaugurated as Nevada's governor following the 2026 election
  VENUE WORDING: Nevada Governor winner? — Aaron Ford
  RULES EXCERPT: If a representative of the Democratic party is inaugurated as the governor of Nevada pursuant to the 2026 election, then the market resolves to Yes.

- id t0559 | shown at 47% | venue deadline 2027-11-03
  SENTENCE: A Republican is inaugurated as Nevada's governor following the 2026 election
  VENUE WORDING: Nevada Governor winner? — Joe Lombardo
  RULES EXCERPT: If a representative of the Republican party is inaugurated as the governor of Nevada pursuant to the 2026 election, then the market resolves to Yes.

- id t0099 | shown at 16% | venue deadline 2028-11-07
  SENTENCE: Gavin Newsom and JD Vance are the Democratic and Republican nominees for president in 2028
  VENUE WORDING: 2028 Presidential matchup — Gavin Newsom v. JD Vance
  RULES EXCERPT: If Gavin Newsom (D) and JD Vance (R) are the nominees for the 2028 presidential election, then the market resolves to Yes.

- id t0100 | shown at 10% | venue deadline 2028-11-07
  SENTENCE: Alexandria Ocasio-Cortez and JD Vance are the Democratic and Republican nominees for president in 2028
  VENUE WORDING: 2028 Presidential matchup — AOC v. JD Vance
  RULES EXCERPT: If Alexandria Ocasio-Cortez (D) and JD Vance (R) are the nominees for the 2028 presidential election, then the market resolves to Yes.
