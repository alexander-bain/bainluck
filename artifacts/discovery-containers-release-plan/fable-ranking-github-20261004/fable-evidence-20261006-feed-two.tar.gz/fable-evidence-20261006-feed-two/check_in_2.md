
## y26 — type: movers — headline: Moves this week — tag: Culture and sport
- id t0747 | 76% | kind named | deadline 2026-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Tyreek Hill joins the Kansas City Chiefs as his next team before December 31, 2026
  VENUE WORDING: Tyreek Hill's Next Team — Kansas City
  RULES EXCERPT: If Tyreek Hill's next team is Kansas City before Dec 31, 2026, then the market resolves to Yes.
- id t0859 | 33% | kind named | deadline 2028-10-31 | venue K | shown as: was 11% a week ago
  SENTENCE: The Chicago White Sox win the 2026 American League title and advance to the World Series
  VENUE WORDING: American League Champion — Chicago WS
  RULES EXCERPT: If Chicago WS win the 2026 Pro Baseball American League Championship, then the market resolves to Yes.
- id t0783 | 74% | kind named | deadline 2026-12-29 | venue K | shown as: was 55% a week ago
  SENTENCE: Alabama makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Alabama
  RULES EXCERPT: If Alabama is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.
- id t0342 | 57% | kind named | deadline 2027-12-31 | venue K | shown as: was 41% a week ago
  SENTENCE: Robert Pattinson is nominated for Best Actor at the 2027 Oscars
  VENUE WORDING: Oscar nominees: Best Actor — Robert Pattinson
  RULES EXCERPT: If Robert Pattinson has been nominated for Best Actor at the 99th Academy Awards, then the market resolves to Yes.

## y27 — type: movers — headline: Moves this month — tag: Washington
- id t0116 | 80% | kind named | deadline 2028-12-31 | venue K | shown as: was 51% a month ago
  SENTENCE: Chuck Schumer wins the next election for Senate Democratic leader
  VENUE WORDING: Next Senate Democratic Leader? — Chuck Schumer
  RULES EXCERPT: If Chuck Schumer wins the next Senate Democratic Leader election, then the market resolves to Yes.
- id t0897 | 42% | kind named | deadline 2027-06-02 | venue K | shown as: was 65% a month ago
  SENTENCE: Karen Bass wins the 2026 Los Angeles mayoral election
  VENUE WORDING: Los Angeles Mayor winner? — Karen Bass
  RULES EXCERPT: If Karen Bass wins the 2026 Los Angeles Mayoral Election, then the market resolves to Yes.
- id t0488 | 64% | kind named | deadline 2027-11-03 | venue K/P | shown as: was 83% a month ago
  SENTENCE: A Republican is sworn in as US Senator from Kansas for the term starting in 2027
  VENUE WORDING: Kansas Senate winner? — Roger Marshall
  RULES EXCERPT: If a representative of the Republican party is sworn in as a Senator of Kansas for the term beginning in 2027, then the market resolves to Yes.
- id t0884 | 46% | kind named | deadline 2027-07-07 | venue K | shown as: was 31% a month ago
  SENTENCE: Susan Collins wins the 2026 US Senate election in Maine
  VENUE WORDING: Maine Senate winner? (Person) — Susan Collins
  RULES EXCERPT: If Susan Collins wins the 2026 Maine Senate election, then the market resolves to Yes.

## y28 — type: movers — headline: Moves this week — tag: Washington
- id t0116 | 80% | kind named | deadline 2028-12-31 | venue K | shown as: was 56% a week ago
  SENTENCE: Chuck Schumer wins the next election for Senate Democratic leader
  VENUE WORDING: Next Senate Democratic Leader? — Chuck Schumer
  RULES EXCERPT: If Chuck Schumer wins the next Senate Democratic Leader election, then the market resolves to Yes.
- id t0072 | 24% | kind named | deadline 2029-01-20 | venue K | shown as: was 13% a week ago
  SENTENCE: Pete Hegseth is the next member of Trump's Cabinet to leave or announce he is leaving
  VENUE WORDING: Who will leave Trump's Cabinet next? — Pete Hegseth
  RULES EXCERPT: If Pete Hegseth is the first member of the Cabinet of Donald Trump to leave or announce they will leave (such as by quitting, being fired, or being impeached) after May 22, 2026, then the market resolves to Yes.
- id t0344 | 72% | kind named | deadline 2027-11-03 | venue K/P | shown as: was 80% a week ago
  SENTENCE: A Republican is inaugurated as governor of Texas following the 2026 election
  VENUE WORDING: Texas Governor winner? — Greg Abbott
  RULES EXCERPT: If a representative of the Republican party is inaugurated as the governor of Texas pursuant to the 2026 election, then the market resolves to Yes.

## y29 — type: newfav — headline: The ____ win the AFC South division in the 2026 NFL season
- id t0393 | 66% | kind named | deadline 2027-01-25 | venue K | shown as: was 29% a month ago | row name: Jacksonville Jaguars
  SENTENCE: The Jacksonville Jaguars win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Jacksonville
  RULES EXCERPT: If Jacksonville wins the Pro Football AFC South Division, then the market resolves to Yes.
- id t0391 | 14% | kind named | deadline 2027-01-25 | venue K | shown as: was 49% a month ago | row name: Houston Texans
  SENTENCE: The Houston Texans win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Houston
  RULES EXCERPT: If Houston wins the Pro Football AFC South Division, then the market resolves to Yes.

## y30 — type: newfav — headline: The ____ win the NFC West division in the 2026 NFL season
- id t0371 | 41% | kind named | deadline 2027-01-25 | venue K | shown as: was 22% a month ago | row name: San Francisco 49ers
  SENTENCE: The San Francisco 49ers win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — San Francisco
  RULES EXCERPT: If San Francisco wins the Pro Football NFC West Division, then the market resolves to Yes.
- id t0370 | 28% | kind named | deadline 2027-01-25 | venue K | shown as: was 47% a month ago | row name: Los Angeles Rams
  SENTENCE: The Los Angeles Rams win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — Los Angeles R
  RULES EXCERPT: If Los Angeles R wins the Pro Football NFC West Division, then the market resolves to Yes.

## y31 — type: swing — headline: The ____ win the AFC South division in the 2026 NFL season
- id t0393 | 66% | kind named | deadline 2027-01-25 | venue K | shown as: was 29% a month ago | row name: Jacksonville Jaguars
  SENTENCE: The Jacksonville Jaguars win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Jacksonville
  RULES EXCERPT: If Jacksonville wins the Pro Football AFC South Division, then the market resolves to Yes.
- id t0391 | 14% | kind named | deadline 2027-01-25 | venue K | shown as: was 49% a month ago | row name: Houston Texans
  SENTENCE: The Houston Texans win the AFC South division in the 2026 NFL season
  VENUE WORDING: AFC South Division Winner — Houston
  RULES EXCERPT: If Houston wins the Pro Football AFC South Division, then the market resolves to Yes.

## y32 — type: swing — headline: The ____ win the NFC West division in the 2026 NFL season
- id t0371 | 41% | kind named | deadline 2027-01-25 | venue K | shown as: was 22% a month ago | row name: San Francisco 49ers
  SENTENCE: The San Francisco 49ers win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — San Francisco
  RULES EXCERPT: If San Francisco wins the Pro Football NFC West Division, then the market resolves to Yes.
- id t0370 | 28% | kind named | deadline 2027-01-25 | venue K | shown as: was 47% a month ago | row name: Los Angeles Rams
  SENTENCE: The Los Angeles Rams win the NFC West division in the 2026 NFL season
  VENUE WORDING: NFC West Division Winner — Los Angeles R
  RULES EXCERPT: If Los Angeles R wins the Pro Football NFC West Division, then the market resolves to Yes.

## y33 — type: checklist — headline: ____ makes the College Football Playoff for the 2026 season
- id t0783 | 74% | kind named | deadline 2026-12-29 | venue K | row name: Alabama
  SENTENCE: Alabama makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Alabama
  RULES EXCERPT: If Alabama is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.
- id t0785 | 47% | kind named | deadline 2026-12-29 | venue K | row name: Utah
  SENTENCE: Utah makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Utah
  RULES EXCERPT: If Utah is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.
- id t0782 | 46% | kind named | deadline 2026-12-29 | venue K | row name: LSU
  SENTENCE: LSU makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — LSU
  RULES EXCERPT: If LSU is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.
- id t0784 | 36% | kind named | deadline 2026-12-29 | venue K | row name: Ole Miss
  SENTENCE: Ole Miss makes the College Football Playoff for the 2026 season
  VENUE WORDING: College Football Playoff Qualifiers — Ole Miss
  RULES EXCERPT: If Ole Miss is one of the teams to qualify for the College Football Playoffs, then the market resolves to Yes.

## y34 — type: when — headline: When will OpenAI achieve AGI?
- id t0952 | 12% | kind date | deadline 2027-01-01 | venue K
  SENTENCE: OpenAI announces that it has achieved artificial general intelligence (AGI) by the end of 2026
  VENUE WORDING: When will OpenAI achieve AGI? — Before 2027
  RULES EXCERPT: If OpenAI announces that they have attained AGI by Dec 31, 2026, then the market resolves to Yes.
- id t0953 | 45% | kind date | deadline 2028-01-01 | venue K
  SENTENCE: OpenAI announces that it has achieved artificial general intelligence (AGI) by the end of 2027
  VENUE WORDING: When will OpenAI achieve AGI? — Before 2028
  RULES EXCERPT: If OpenAI announces that they have attained AGI by Dec 31, 2027, then the market resolves to Yes.
- id t0954 | 65% | kind date | deadline 2030-01-01 | venue K | marked: first date likelier than not
  SENTENCE: OpenAI announces that it has achieved artificial general intelligence (AGI) by the end of 2029
  VENUE WORDING: When will OpenAI achieve AGI? — Before 2030
  RULES EXCERPT: If OpenAI announces that they have attained AGI by Dec 31, 2029, then the market resolves to Yes.

## y35 — type: board — headline: Before Trump's term ends
- id t0055 | 42% | kind date | deadline 2029-01-20 | venue K
  SENTENCE: Zelenskyy and Putin meet before January 20, 2029
  VENUE WORDING: Will Zelenskyy and Putin speak? — Before Jan 20, 2029
  RULES EXCERPT: If Volodymyr Zelenskyy and Vladimir Putin  meet before Jan 20, 2029, then the market resolves to Yes.
- id t0052 | 23% | kind date | deadline 2029-01-21 | venue K
  SENTENCE: The United States acquires any part of Greenland before January 21, 2029
  VENUE WORDING: Will the US take control of any part of Greenland? — Before January 21, 2029
  RULES EXCERPT: If the United States acquires any part of Greenland before Jan 21, 2029, then the market resolves to Yes.
- id t0034 | 18% | kind binary | deadline 2029-01-21 | venue K
  SENTENCE: Donald Trump resigns as president before his term ends in January 2029
  VENUE WORDING: Will Trump resign during his term?
  RULES EXCERPT: If the President of the United States elected for the 2025-2029 term resigns the office, then the market resolves to Yes.
- id t0053 | 11% | kind binary | deadline 2029-01-21 | venue K
  SENTENCE: The United States acquires any part of Canada before January 21, 2029
  VENUE WORDING: Will the US take control of any part of Canada?
  RULES EXCERPT: If the United States acquires any part of Canada before Jan 21, 2029, then the market resolves to Yes.
- id t0069 | 5% | kind binary | deadline 2029-01-20 | venue K
  SENTENCE: A bill abolishing the Federal Reserve and its reserve banks becomes law before January 20, 2029
  VENUE WORDING: Will Trump end the Federal Reserve?
  RULES EXCERPT: If a bill has become law which has abolished or dissolved the Federal Reserve Board of Governors and its constituent reserve banks before January 20, 2029, then the market resolves to Yes.

## y36 — type: board — headline: By the end of 2026
- id t1381 | 81% | kind date | deadline 2026-12-31 | venue P
  SENTENCE: Donald Trump meets Vladimir Putin in person by December 31, 2026
  VENUE WORDING: Trump meets with Putin by...? — December 31
  RULES EXCERPT: This market will resolve to "Yes" if Donald Trump meets with Vladimir Putin between market creation and the listed date, 11:59 PM ET. Otherwise, this market will resolve to "No".

A meeting is defined as any encounter where both Trump and Putin are present and interact with each other in person.

An
- id t1538 | 39% | kind date | deadline 2026-12-31 | venue P
  SENTENCE: The US and Canada announce an official agreement to lower US tariffs on Canada by December 31, 2026
  VENUE WORDING: US-Canada diplomatic agreement to lower tariffs by...? — December 31
  RULES EXCERPT: This market will resolve to “Yes” if a diplomatic agreement between the United States and Canada to lower US tariffs on Canada is announced by December 31, 2026, 11:59 PM ET.

A diplomatic agreement to lower US tariffs on Canada refers to an official agreement, treaty, deal, or substantially similar
- id t0913 | 12% | kind date | deadline 2027-01-01 | venue K
  SENTENCE: The Senate confirms a new Supreme Court justice by December 31, 2026
  VENUE WORDING: New Supreme Court justice confirmed? — Before 2027
  RULES EXCERPT: If the Senate confirms a new justice to the Supreme Court between Issuance and December 31, 2026, then the market resolves to Yes.
- id t1110 | 7% | kind binary | deadline 2027-01-01 | venue P
  SENTENCE: Trump, Putin and Zelensky are photographed or filmed together in the same frame before 2027
  VENUE WORDING: Trump, Putin, and Zelensky seen together before 2027?
  RULES EXCERPT: This market will resolve to "Yes" if Donald Trump, Vladimir Putin, and Volodymyr Zelensky are photographed or videotaped together, in the same frame, between this market's creation and December 31, 2026, 11:59 PM ET. Otherwise, this market will resolve to "No".

For this market to resolve to "Yes," 
- id t0067 | 3% | kind date | deadline 2027-01-01 | venue K
  SENTENCE: The United States purchases at least part of Greenland from Denmark before 2027
  VENUE WORDING: Will Trump buy at least part of Greenland? — Before 2027
  RULES EXCERPT: If the United States purchases at least part of Greenland from Denmark before Jan 1, 2027, then the market resolves to Yes.

## y37 — type: band — headline: About 1 in 20
- id t1082 | 6% | kind date | deadline 2026-12-31 | venue P
  SENTENCE: The AI industry enters a downturn, meeting at least three set measures, by December 31, 2026
  VENUE WORDING: AI bubble burst by...? — December 31, 2026
  RULES EXCERPT: This market will resolve to "Yes" if the AI industry experiences an industry downturn by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No".

For the purposes of this market, the AI industry will be considered to have experienced an industry downturn once at least three of 
- id t0057 | 5% | kind named | deadline 2029-01-20 | venue K
  SENTENCE: Any part of Cuba becomes the 51st US state before January 20, 2029
  VENUE WORDING: What will be the 51st state in Trump's term? — Cuba
  RULES EXCERPT: If the 51st state is any part of Cuba before Jan 20, 2029, then the market resolves to Yes.
- id t0582 | 4% | kind date | deadline 2027-01-01 | venue K
  SENTENCE: Donald Trump leaves office as president before 2027, for a reason other than death
  VENUE WORDING: Donald Trump announces departure as President? (Excluding death) — Before 2027
  RULES EXCERPT: If Donald Trump leaves office before Jan 1, 2027, then the market resolves to Yes.
- id t0693 | 4% | kind date | deadline 2027-01-01 | venue K/P
  SENTENCE: The US government definitively states that alien life or technology exists before January 1, 2027
  VENUE WORDING: Will the U.S. confirm that aliens exist? — Before Jan 1, 2027
  RULES EXCERPT: If the President, any member of the Cabinet, any member of the Joint Chiefs of Staff, or any US federal agency definitively states that extraterrestrial life or technology exists before Jan 1, 2027, then the market resolves to Yes.

## y38 — type: band — headline: About 9 in 10
- id t0821 | 92% | kind named | deadline 2026-12-01 | venue K
  SENTENCE: Aaron Rodgers joins the Pittsburgh Steelers as his next team before December 1, 2026
  VENUE WORDING: Aaron Rodgers's Next Team — Pittsburgh
  RULES EXCERPT: If Aaron Rodgers's next team is Pittsburgh before Dec 1, 2026, then the market resolves to Yes.
- id t0324 | 91% | kind named | deadline 2027-02-01 | venue K
  SENTENCE: Democrats win control of the US House in the 2026 midterm elections
  VENUE WORDING: Which party will win the U.S. House? — Democratic Party
  RULES EXCERPT: If the Democratic Party has won control of the House in 2026, then the market resolves to Yes.
- id t0829 | 89% | kind binary | deadline 2026-11-10 | venue K
  SENTENCE: US House elections are held on schedule in all 50 states on Election Day 2026
  VENUE WORDING: Will the midterms happen on time?
  RULES EXCERPT: If the regularly scheduled biennial federal general election for the U.S. House of Representatives is conducted on time in all 50 U.S. states on the federally prescribed Election Day for 2026, then the market resolves to Yes.
- id t0564 | 89% | kind named | deadline 2028-01-01 | venue K
  SENTENCE: Ryan Reynolds appears or is announced as Deadpool in Avengers: Doomsday
  VENUE WORDING: Avengers: Doomsday: Cast — Ryan Reynolds as Deadpool?
  RULES EXCERPT: If Ryan Reynolds performs / is announced as Deadpool in Avengers: Doomsday, then the market resolves to Yes.
