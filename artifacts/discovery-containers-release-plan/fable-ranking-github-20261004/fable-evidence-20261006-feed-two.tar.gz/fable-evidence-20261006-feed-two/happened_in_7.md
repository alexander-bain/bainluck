# Claims to check. Today is Tuesday, October 6, 2026.

- id t0067 | shown at 3% | venue deadline 2027-01-01
  SENTENCE: The United States purchases at least part of Greenland from Denmark before 2027
  VENUE WORDING: Will Trump buy at least part of Greenland? — Before 2027
  RULES EXCERPT: If the United States purchases at least part of Greenland from Denmark before Jan 1, 2027, then the market resolves to Yes.

- id t1082 | shown at 6% | venue deadline 2026-12-31
  SENTENCE: The AI industry enters a downturn, meeting at least three set measures, by December 31, 2026
  VENUE WORDING: AI bubble burst by...? — December 31, 2026
  RULES EXCERPT: This market will resolve to "Yes" if the AI industry experiences an industry downturn by the specified date, 11:59 PM ET. Otherwise, this market will resolve to "No".

For the purposes of this market, the AI industry will be considered to have experienced an industry downturn once at least three of 

- id t0057 | shown at 5% | venue deadline 2029-01-20
  SENTENCE: Any part of Cuba becomes the 51st US state before January 20, 2029
  VENUE WORDING: What will be the 51st state in Trump's term? — Cuba
  RULES EXCERPT: If the 51st state is any part of Cuba before Jan 20, 2029, then the market resolves to Yes.

- id t0582 | shown at 4% | venue deadline 2027-01-01
  SENTENCE: Donald Trump leaves office as president before 2027, for a reason other than death
  VENUE WORDING: Donald Trump announces departure as President? (Excluding death) — Before 2027
  RULES EXCERPT: If Donald Trump leaves office before Jan 1, 2027, then the market resolves to Yes.

- id t0693 | shown at 4% | venue deadline 2027-01-01
  SENTENCE: The US government definitively states that alien life or technology exists before January 1, 2027
  VENUE WORDING: Will the U.S. confirm that aliens exist? — Before Jan 1, 2027
  RULES EXCERPT: If the President, any member of the Cabinet, any member of the Joint Chiefs of Staff, or any US federal agency definitively states that extraterrestrial life or technology exists before Jan 1, 2027, then the market resolves to Yes.

- id t0821 | shown at 92% | venue deadline 2026-12-01
  SENTENCE: Aaron Rodgers joins the Pittsburgh Steelers as his next team before December 1, 2026
  VENUE WORDING: Aaron Rodgers's Next Team — Pittsburgh
  RULES EXCERPT: If Aaron Rodgers's next team is Pittsburgh before Dec 1, 2026, then the market resolves to Yes.

- id t0829 | shown at 89% | venue deadline 2026-11-10
  SENTENCE: US House elections are held on schedule in all 50 states on Election Day 2026
  VENUE WORDING: Will the midterms happen on time?
  RULES EXCERPT: If the regularly scheduled biennial federal general election for the U.S. House of Representatives is conducted on time in all 50 U.S. states on the federally prescribed Election Day for 2026, then the market resolves to Yes.

- id t0564 | shown at 89% | venue deadline 2028-01-01
  SENTENCE: Ryan Reynolds appears or is announced as Deadpool in Avengers: Doomsday
  VENUE WORDING: Avengers: Doomsday: Cast — Ryan Reynolds as Deadpool?
  RULES EXCERPT: If Ryan Reynolds performs / is announced as Deadpool in Avengers: Doomsday, then the market resolves to Yes.
