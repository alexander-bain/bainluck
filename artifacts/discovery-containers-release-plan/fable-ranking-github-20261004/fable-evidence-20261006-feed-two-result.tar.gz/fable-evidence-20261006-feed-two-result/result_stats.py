"""Prints every number quoted about the Feed Two run from signals/*.json, meta/run.json and cards5.json only."""
import json,glob,csv,statistics as st,collections,os
here=os.path.dirname(os.path.abspath(__file__))
K={c['cid']:c for c in json.load(open(os.path.join(here,'cards5.json')))}
rows=[]
for f in sorted(glob.glob(os.path.join(here,'signals','*.json'))):
    d=json.load(open(f)); d=d.get('data',d); d['cid']=os.path.basename(f)[:-5]; d['head']=K[d['cid']]['headline']; rows.append(d)
rows.sort(key=lambda r:r['n'])
m=json.load(open(os.path.join(here,'meta','run.json'))); m=m.get('data',m); print('meta',m)
with open(os.path.join(here,'feed-two-signals.csv'),'w',newline='') as fh:
    w=csv.writer(fh); cols=['n','cid','type','head','rows','chars','viz','viz_eligible','impressions','visits','dwell_ms','first_visit_ms','liked','shared','notforme','details_opens','first_seen_order','at']
    w.writerow(cols)
    for r in rows: w.writerow([r.get(c) for c in cols])
N=len(rows); print('cards with a record',N,'| seen (impressions>0)',sum(1 for r in rows if r['impressions']>0))
print('liked',sum(r['liked'] for r in rows),'| shared',sum(r['shared'] for r in rows),'| not for me',sum(r['notforme'] for r in rows),'| no reaction',sum(1 for r in rows if not(r['liked'] or r['shared'] or r['notforme'])),'| details opened on',sum(1 for r in rows if r['details_opens']))
print('liked and shared',sum(1 for r in rows if r['liked'] and r['shared']),'| shared not liked',sum(1 for r in rows if r['shared'] and not r['liked']))
bt=collections.defaultdict(list)
for r in rows: bt[r['type']].append(r)
for t,l in sorted(bt.items(),key=lambda kv:-len(kv[1])):
    print(f"  {t:9} n={len(l)} liked={sum(r['liked'] for r in l)} shared={sum(r['shared'] for r in l)} notforme={sum(r['notforme'] for r in l)} median first-visit s={st.median([(r['first_visit_ms'] or 0)/1000 for r in l]):.1f}")
dw=[r['dwell_ms']/1000 for r in rows]; fv=[(r['first_visit_ms'] or 0)/1000 for r in rows]
print('reading time s: total',round(sum(dw),1),'min',min(dw),'median',st.median(dw),'max',max(dw),'| zero',sum(1 for x in dw if x==0),'| first-visit null',sum(1 for r in rows if r['first_visit_ms'] is None),'| cards with more than one visit',sum(1 for r in rows if r['visits']>1))
def rank(v):
    o=sorted(range(len(v)),key=lambda i:v[i]); r=[0]*len(v); i=0
    while i<len(o):
        j=i
        while j+1<len(o) and v[o[j+1]]==v[o[i]]: j+=1
        for k in range(i,j+1): r[o[k]]=(i+j)/2+1
        i=j+1
    return r
def sp(a,b):
    ra,rb=rank(a),rank(b); ma,mb=st.mean(ra),st.mean(rb)
    den=(sum((x-ma)**2 for x in ra)*sum((y-mb)**2 for y in rb))**.5
    return round(sum((x-ma)*(y-mb) for x,y in zip(ra,rb))/den,2) if den else None
score=[(1 if r['liked'] else 0)+(1 if r['shared'] else 0)-(1 if r['notforme'] else 0) for r in rows]
print('Spearman (average ranks): first-visit time vs chars',sp(fv,[r['chars'] for r in rows]),'| first-visit time vs reaction score',sp(fv,score),'| total time vs chars',sp(dw,[r['chars'] for r in rows]),'| total time vs reaction score',sp(dw,score),'| chars vs reaction score',sp([r['chars'] for r in rows],score))
for lab,f in (('liked',lambda r:r['liked']),('not for me',lambda r:r['notforme']),('no reaction',lambda r:not(r['liked'] or r['shared'] or r['notforme']))):
    x=[(r['first_visit_ms'] or 0)/1000 for r in rows if f(r)]
    if x: print(' median first-visit s,',lab,':',st.median(x),'n',len(x))
print('chart cards:',[(r['n'],r['liked'],r['shared'],r['notforme']) for r in rows if r['viz']],'| eligible without:',[(r['n'],r['liked'],r['shared'],r['notforme']) for r in rows if r['viz_eligible'] and not r['viz']],'| other two-outcome:',[(r['n'],r['liked'],r['shared'],r['notforme']) for r in rows if r['type'] in('swing','newfav') and not r['viz_eligible']])
print()
for r in rows: print(f"{r['n']:>2} {r['type']:9} {'LIKE ' if r['liked'] else '     '}{'SHARE ' if r['shared'] else '      '}{'NOTME ' if r['notforme'] else '      '}det={r['details_opens']} vis={r['visits']} first={((r['first_visit_ms'] or 0)/1000):5.1f}s total={r['dwell_ms']/1000:5.1f}s chars={r['chars']:3} order={r['first_seen_order']} | {r['head'][:60]}")
print()
mid=[r for r in rows if r['n'] not in (1,N)]
fv2=[(r['first_visit_ms'] or 0)/1000 for r in mid]; sc2=[(1 if r['liked'] else 0)+(1 if r['shared'] else 0)-(1 if r['notforme'] else 0) for r in mid]
print('excluding the first and last card (n=%d): first-visit time vs reaction score'%len(mid),sp(fv2,sc2),'| vs chars',sp(fv2,[r['chars'] for r in mid]),'| median first-visit s liked',st.median([x for x,r in zip(fv2,mid) if r['liked']]),'not for me',st.median([x for x,r in zip(fv2,mid) if r['notforme']]))
import datetime as dt
ts=sorted(dt.datetime.fromisoformat(r['at'].replace('Z','+00:00')) for r in rows); s0=dt.datetime.fromisoformat(m['started_at'].replace('Z','+00:00'))
PT=dt.timezone(dt.timedelta(hours=-7)); print('run started',s0.astimezone(PT).strftime('%-I:%M%p PT'),'| last record',ts[-1].astimezone(PT).strftime('%-I:%M%p PT'),'| elapsed min',round((ts[-1]-s0).total_seconds()/60,1))
print('not for me cards:',[(r['n'],r['type'],r['head'][:50]) for r in rows if r['notforme']])
print('shared cards:',[(r['n'],r['type'],r['head'][:50]) for r in rows if r['shared']])
